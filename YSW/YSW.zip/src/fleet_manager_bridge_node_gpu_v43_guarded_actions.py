#!/usr/bin/env python3
import json
import os
import time
import uuid
import threading
from pathlib import Path
from typing import Dict, Optional, Tuple

import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from rclpy.action import ActionServer

from cobot3_interfaces.action import ManageWorkstation
try:
    from cobot3_interfaces.action import MovePackage
except Exception:
    MovePackage = None


BRIDGE_QUEUE_DIR = Path('/home/rokey/isaaclab_ws/isaac_aruco/amr/bridge_queue')
COMMAND_DIR = BRIDGE_QUEUE_DIR / 'commands'
STATUS_DIR = BRIDGE_QUEUE_DIR / 'status'
RESULT_DIR = BRIDGE_QUEUE_DIR / 'results'
CANCEL_DIR = BRIDGE_QUEUE_DIR / 'cancel'
DONE_DIR = BRIDGE_QUEUE_DIR / 'done'

ACTION_NAME = 'manage_workstation'
MOVE_PACKAGE_ACTION_NAME = 'move_package'
FEEDBACK_PERIOD_SEC = 0.25
TASK_TIMEOUT_SEC = 300.0
BRIDGE_EXECUTOR_THREADS = max(1, int(os.environ.get('AMR_BRIDGE_EXECUTOR_THREADS', '2')))

# Bridge-side admission guard.
# This does not replace the IsaacSim controller planner. It prevents obviously
# impossible fleet commands before they enter the IsaacSim queue:
#   - same workstation already active
#   - same target slot/location already active
#   - same preferred AMR already active when require_preferred_amr=True
# Disable only for emergency testing: AMR_BRIDGE_ADMISSION_GUARD=0
ADMISSION_GUARD_ENABLED = os.environ.get('AMR_BRIDGE_ADMISSION_GUARD', '1').lower() not in {'0', 'false', 'no', 'off'}


def ensure_dirs():
    for d in [COMMAND_DIR, STATUS_DIR, RESULT_DIR, CANCEL_DIR, DONE_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def safe_write_json(path: Path, data: Dict):
    tmp = path.with_suffix(path.suffix + f'.{uuid.uuid4().hex}.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)


def safe_read_json(path: Path) -> Optional[Dict]:
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def goal_to_command_dict(command_id: str, goal) -> Dict:
    data = {
        'command_id': command_id,
        'workstation_id': str(getattr(goal, 'workstation_id', '') or ''),
        'start_location': str(getattr(goal, 'start_location', '') or ''),
        'target_location': str(getattr(goal, 'target_location', '') or ''),
        'workstation_qr_id': str(getattr(goal, 'workstation_qr_id', '') or ''),
        'target_qr_id': str(getattr(goal, 'target_qr_id', '') or ''),
        'target_x': float(getattr(goal, 'target_x', 0.0) or 0.0) if hasattr(goal, 'target_x') else None,
        'target_y': float(getattr(goal, 'target_y', 0.0) or 0.0) if hasattr(goal, 'target_y') else None,
        'target_yaw': float(getattr(goal, 'target_yaw', 0.0) or 0.0) if hasattr(goal, 'target_yaw') else 0.0,
        'created_at': time.time(),
    }
    return data


def command_target_key(command: Dict) -> str:
    """Return a stable target key used for bridge-side duplicate detection."""
    target_location = str(command.get('target_location', '') or '').strip()
    if target_location:
        return f'location:{target_location}'

    target_qr_id = str(command.get('target_qr_id', '') or '').strip()
    if target_qr_id:
        return f'qr:{target_qr_id}'

    target_x = command.get('target_x')
    target_y = command.get('target_y')
    if target_x is not None and target_y is not None:
        try:
            return f'xy:{float(target_x):.3f},{float(target_y):.3f}'
        except Exception:
            pass

    return ''


def command_workstation_key(command: Dict) -> str:
    workstation_id = str(command.get('workstation_id', '') or '').strip()
    if workstation_id:
        return f'workstation:{workstation_id}'

    workstation_qr_id = str(command.get('workstation_qr_id', '') or '').strip()
    if workstation_qr_id:
        return f'workstation_qr:{workstation_qr_id}'

    return ''


def command_amr_key(command: Dict) -> str:
    if not bool(command.get('require_preferred_amr', False)):
        return ''
    amr = str(command.get('preferred_amr_name') or command.get('preferred_amr') or '').strip()
    if not amr:
        return ''
    return f'amr:{amr}'



class FleetManagerBridgeNode(Node):
    def __init__(self):
        super().__init__('fleet_manager_bridge_node')
        ensure_dirs()
        self._admission_lock = threading.Lock()
        self._active_commands: Dict[str, Dict] = {}
        self._active_workstations: Dict[str, str] = {}
        self._active_targets: Dict[str, str] = {}
        self._active_amrs: Dict[str, str] = {}
        # Global action server: /manage_workstation
        # This keeps compatibility with the original Control Tower bridge.
        self.action_server = ActionServer(
            self,
            ManageWorkstation,
            ACTION_NAME,
            lambda goal_handle: self.execute_manage_workstation_callback(goal_handle, None),
        )

        # Per-AMR action aliases:
        #   /amr_01/manage_workstation ... /amr_05/manage_workstation
        # Each alias writes preferred_amr_name + require_preferred_amr into the queue JSON
        # so the Isaac controller assigns the requested AMR instead of nearest available AMR.
        self.per_amr_action_servers = []
        for idx in range(1, 6):
            amr_name = f'AMR_{idx:02d}'
            amr_action_name = f'/amr_{idx:02d}/manage_workstation'
            self.per_amr_action_servers.append(
                ActionServer(
                    self,
                    ManageWorkstation,
                    amr_action_name,
                    self._make_per_amr_manage_callback(amr_name),
                )
            )
        self.move_package_action_server = None
        if MovePackage is not None:
            self.move_package_action_server = ActionServer(
                self,
                MovePackage,
                MOVE_PACKAGE_ACTION_NAME,
                self.execute_move_package_callback,
            )
        self.get_logger().info(f'AMR Fleet Bridge V42 ActionServer ready: /{ACTION_NAME}')
        for idx in range(1, 6):
            self.get_logger().info(f'AMR Fleet Bridge V42 ActionServer ready: /amr_{idx:02d}/manage_workstation -> preferred AMR_{idx:02d}')
        if MovePackage is not None:
            self.get_logger().info(f'AMR Fleet Bridge V18 ActionServer ready: /{MOVE_PACKAGE_ACTION_NAME}')
        else:
            self.get_logger().warn('MovePackage action interface not available. /move_package server not started.')
        self.get_logger().info(f'Bridge queue dir: {BRIDGE_QUEUE_DIR}')
        self.get_logger().info(f'Bridge executor threads: {BRIDGE_EXECUTOR_THREADS}')
        self.get_logger().info('Run Isaac Sim GPU controller inside Isaac Sim Script Editor.')

    def _validate_command_admission(self, command: Dict) -> Tuple[bool, str]:
        if not ADMISSION_GUARD_ENABLED:
            return True, ''

        workstation_key = command_workstation_key(command)
        target_key = command_target_key(command)
        amr_key = command_amr_key(command)

        with self._admission_lock:
            if workstation_key and workstation_key in self._active_workstations:
                owner = self._active_workstations[workstation_key]
                return False, f'DUPLICATE_WORKSTATION active_command={owner} key={workstation_key}'

            if target_key and target_key in self._active_targets:
                owner = self._active_targets[target_key]
                return False, f'DUPLICATE_TARGET active_command={owner} key={target_key}'

            if amr_key and amr_key in self._active_amrs:
                owner = self._active_amrs[amr_key]
                return False, f'DUPLICATE_AMR active_command={owner} key={amr_key}'

            return True, ''

    def _register_active_command(self, command: Dict):
        if not ADMISSION_GUARD_ENABLED:
            return

        command_id = str(command.get('command_id', '') or '')
        workstation_key = command_workstation_key(command)
        target_key = command_target_key(command)
        amr_key = command_amr_key(command)

        with self._admission_lock:
            self._active_commands[command_id] = {
                'workstation_key': workstation_key,
                'target_key': target_key,
                'amr_key': amr_key,
                'created_at': time.time(),
            }
            if workstation_key:
                self._active_workstations[workstation_key] = command_id
            if target_key:
                self._active_targets[target_key] = command_id
            if amr_key:
                self._active_amrs[amr_key] = command_id

    def _unregister_active_command(self, command_id: str):
        if not ADMISSION_GUARD_ENABLED:
            return

        with self._admission_lock:
            rec = self._active_commands.pop(command_id, None)
            if not rec:
                return

            workstation_key = rec.get('workstation_key') or ''
            target_key = rec.get('target_key') or ''
            amr_key = rec.get('amr_key') or ''

            if workstation_key and self._active_workstations.get(workstation_key) == command_id:
                self._active_workstations.pop(workstation_key, None)
            if target_key and self._active_targets.get(target_key) == command_id:
                self._active_targets.pop(target_key, None)
            if amr_key and self._active_amrs.get(amr_key) == command_id:
                self._active_amrs.pop(amr_key, None)

    def execute_move_package_callback(self, goal_handle):
        """Logical MovePackage action server.

        Current Isaac Sim stage controls AMRs and workstations. Package meshes are not
        modeled as physical carried objects in this stage, so this server acknowledges
        package transport commands and publishes progress/result for Control Tower
        integration compatibility.
        """
        goal = goal_handle.request
        command_id = f'PKG_{uuid.uuid4().hex[:12]}'
        package_id = str(getattr(goal, 'package_id', '') or '')
        customer_name = str(getattr(goal, 'customer_name', '') or '')
        destination_zone = str(getattr(goal, 'destination_zone', '') or '')
        package_qr_id = str(getattr(goal, 'package_qr_id', '') or '')

        self.get_logger().info(
            'MovePackage received | '
            f'command_id={command_id} '
            f'package_id={package_id} '
            f'customer={customer_name} '
            f'destination={destination_zone} '
            f'package_qr_id={package_qr_id}'
        )

        result_msg = MovePackage.Result()

        feedback_steps = [
            ('ACCEPTED', 0.0),
            ('ASSIGNED_TO_AMR_LOGICAL', 35.0),
            ('MOVING_TO_DESTINATION_LOGICAL', 75.0),
            ('COMPLETED', 100.0),
        ]
        for position, progress in feedback_steps:
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                if hasattr(result_msg, 'success'):
                    result_msg.success = False
                if hasattr(result_msg, 'error_msg'):
                    result_msg.error_msg = 'MovePackage canceled'
                self.get_logger().warn(f'MovePackage canceled | command_id={command_id}')
                return result_msg

            feedback_msg = MovePackage.Feedback()
            if hasattr(feedback_msg, 'current_position'):
                feedback_msg.current_position = position
            if hasattr(feedback_msg, 'progress'):
                feedback_msg.progress = float(progress)
            goal_handle.publish_feedback(feedback_msg)
            time.sleep(0.2)

        goal_handle.succeed()
        if hasattr(result_msg, 'success'):
            result_msg.success = True
        if hasattr(result_msg, 'error_msg'):
            result_msg.error_msg = ''
        self.get_logger().info(f'MovePackage completed | command_id={command_id}')
        return result_msg

    def _make_per_amr_manage_callback(self, preferred_amr_name: str):
        def _callback(goal_handle):
            return self.execute_manage_workstation_callback(goal_handle, preferred_amr_name)
        return _callback

    def execute_manage_workstation_callback(self, goal_handle, forced_amr_name: Optional[str] = None):
        goal = goal_handle.request
        command_id = f'CMD_{uuid.uuid4().hex[:12]}'
        command_path = COMMAND_DIR / f'{command_id}.json'
        status_path = STATUS_DIR / f'{command_id}.json'
        result_path = RESULT_DIR / f'{command_id}.json'
        cancel_path = CANCEL_DIR / f'{command_id}.json'

        command = goal_to_command_dict(command_id, goal)
        if forced_amr_name:
            command['preferred_amr_name'] = forced_amr_name
            command['preferred_amr'] = forced_amr_name
            command['require_preferred_amr'] = True
            command['source_action_name'] = f"/{forced_amr_name.lower()}/manage_workstation"

        ok, reject_reason = self._validate_command_admission(command)
        if not ok:
            result_msg = ManageWorkstation.Result()
            goal_handle.abort()
            if hasattr(result_msg, 'success'):
                result_msg.success = False
            if hasattr(result_msg, 'error_msg'):
                result_msg.error_msg = reject_reason
            self.get_logger().warn(
                'ManageWorkstation rejected by admission guard | '
                f"command_id={command_id} forced_amr={forced_amr_name or 'AUTO'} "
                f"workstation_id={command.get('workstation_id', '')} "
                f"target={command.get('target_location', '')} reason={reject_reason}"
            )
            return result_msg

        self.get_logger().info(
            'ManageWorkstation received | '
            f"command_id={command_id} "
            f"forced_amr={forced_amr_name or 'AUTO'} "
            f"workstation_id={command['workstation_id']} "
            f"start={command['start_location']} "
            f"target={command['target_location']}"
        )

        # Remove stale files if the same command id somehow exists.
        for p in [status_path, result_path, cancel_path]:
            try:
                p.unlink(missing_ok=True)
            except Exception:
                pass

        safe_write_json(command_path, command)
        self._register_active_command(command)

        result_msg = ManageWorkstation.Result()
        start_time = time.time()

        while rclpy.ok():
            if goal_handle.is_cancel_requested:
                safe_write_json(cancel_path, {
                    'command_id': command_id,
                    'cancel_requested_at': time.time(),
                })
                goal_handle.canceled()
                if hasattr(result_msg, 'success'):
                    result_msg.success = False
                self._unregister_active_command(command_id)
                self.get_logger().warn(f'ManageWorkstation canceled | command_id={command_id}')
                return result_msg

            result_data = safe_read_json(result_path)
            if result_data is not None:
                success = bool(result_data.get('success', False))
                status = str(result_data.get('status', 'UNKNOWN'))
                message = str(result_data.get('message', ''))

                if success:
                    goal_handle.succeed()
                    if hasattr(result_msg, 'success'):
                        result_msg.success = True
                    self._unregister_active_command(command_id)
                    self.get_logger().info(f'ManageWorkstation completed | command_id={command_id} status={status}')
                    return result_msg

                goal_handle.abort()
                if hasattr(result_msg, 'success'):
                    result_msg.success = False
                self._unregister_active_command(command_id)
                self.get_logger().error(f'ManageWorkstation failed | command_id={command_id} status={status} message={message}')
                return result_msg

            status_data = safe_read_json(status_path)
            feedback_msg = ManageWorkstation.Feedback()
            if status_data is not None:
                if hasattr(feedback_msg, 'distance_remaining'):
                    feedback_msg.distance_remaining = float(status_data.get('distance_remaining', 0.0) or 0.0)
                if hasattr(feedback_msg, 'status'):
                    feedback_msg.status = str(status_data.get('status', 'RUNNING'))
            else:
                if hasattr(feedback_msg, 'distance_remaining'):
                    feedback_msg.distance_remaining = 0.0
                if hasattr(feedback_msg, 'status'):
                    feedback_msg.status = 'WAITING_FOR_ISAAC_SIM'

            goal_handle.publish_feedback(feedback_msg)

            if time.time() - start_time > TASK_TIMEOUT_SEC:
                safe_write_json(cancel_path, {
                    'command_id': command_id,
                    'cancel_requested_at': time.time(),
                    'reason': 'timeout',
                })
                goal_handle.abort()
                if hasattr(result_msg, 'success'):
                    result_msg.success = False
                self._unregister_active_command(command_id)
                self.get_logger().error(f'ManageWorkstation timeout | command_id={command_id}')
                return result_msg

            time.sleep(FEEDBACK_PERIOD_SEC)

        self._unregister_active_command(command_id)
        goal_handle.abort()
        if hasattr(result_msg, 'success'):
            result_msg.success = False
        return result_msg


def main(args=None):
    rclpy.init(args=args)
    node = FleetManagerBridgeNode()
    executor = MultiThreadedExecutor(num_threads=BRIDGE_EXECUTOR_THREADS)
    executor.add_node(node)

    try:
        executor.spin()
    except KeyboardInterrupt:
        node.get_logger().info('AMR Fleet Bridge shutting down...')
    finally:
        executor.shutdown()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
