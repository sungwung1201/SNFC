"""
Isaac Sim Script Editor controller.

Purpose
- Use an already-open Isaac Sim/Nucleus Live stage.
- Control existing prims:
  /World/defaultPrim/finalfac/finalfac/World3/AMR_01~05
  /World/defaultPrim/finalfac/finalfac/World3/RACK_01~10
- Read Control Tower bridge commands from:
  /home/rokey/isaaclab_ws/isaac_aruco/amr/bridge_queue/commands
- Execute previous-style AMR logic:
  8-way Time A* + reservation-table future path planning + global move arbiter + lookahead2
  Rack-zone 4-way-only traversal + dynamic visual-front movement-direction yaw alignment
- QR localization stage added:
  read downward camera images with OpenCV QRCodeDetector, map QR ID to grid cell, then feed the existing planner.
- Write bridge results/status back for fleet_manager_bridge_node.py.

Run inside Isaac Sim:
  Window -> Script Editor
  exec(open('/home/rokey/isaaclab_ws/isaac_aruco/amr/amr_live_existing_stage_true8_qr_camera_controller_gpu.py', encoding='utf-8').read())
"""

import json
import math
import os
import re
import random
import shutil
import socket
import time
from dataclasses import dataclass, field

# v20 patch note:
# - PRE_TARGET_WAIT no longer releases by timeout.
# - B-side SG final entry is gated by same-lane A semantic clear.
# - v21/v22/v23 partial-entry: B can move safe_wait -> pre_approach before A fully clears,
#   but approach/final are still guarded by A side-exit/return phases.
# - v24: generic 3-stage B entry (SAFE_WAIT -> ENTRY -> FINAL_READY -> FINAL),
#   A-side EXIT_HOLD before RETURN_HOME, explicit DELIVERY_DONE/TASK_DONE status, and stronger stage logs.
from heapq import heappop, heappush
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

try:
    import cv2
    import numpy as np
    CV2_AVAILABLE = True
except Exception as _cv_err:
    cv2 = None
    np = None
    CV2_AVAILABLE = False
    _CV2_IMPORT_ERROR = _cv_err


def env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name, None)
    if value is None:
        return bool(default)
    return str(value).strip().lower() not in {"0", "false", "no", "off", "disable", "disabled"}


def env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except Exception:
        return int(default)


# GPU usage policy. The navigation/planning algorithm is intentionally unchanged.
# Only OpenCV image pre-processing is moved to CUDA when the installed cv2 build supports it.
AMR_GPU_ENABLED = env_bool("AMR_GPU_ENABLED", True)
AMR_QR_GPU_PREPROCESS_ENABLED = env_bool("AMR_QR_GPU_PREPROCESS_ENABLED", True)
AMR_QR_CUDA_DEVICE_ID = env_int("AMR_QR_CUDA_DEVICE_ID", 0)
AMR_OPENCV_CPU_THREADS = env_int("AMR_OPENCV_CPU_THREADS", 1)

_OPENCV_RUNTIME_CONFIGURED = False
_OPENCV_CUDA_CHECKED = False
_OPENCV_CUDA_AVAILABLE = False
_OPENCV_CUDA_STATUS = "not_checked"


def configure_opencv_runtime():
    global _OPENCV_RUNTIME_CONFIGURED
    if _OPENCV_RUNTIME_CONFIGURED or not CV2_AVAILABLE:
        return
    _OPENCV_RUNTIME_CONFIGURED = True
    try:
        cv2.setUseOptimized(True)
    except Exception:
        pass
    try:
        if AMR_OPENCV_CPU_THREADS >= 0:
            cv2.setNumThreads(AMR_OPENCV_CPU_THREADS)
    except Exception:
        pass


def opencv_cuda_available() -> bool:
    global _OPENCV_CUDA_CHECKED, _OPENCV_CUDA_AVAILABLE, _OPENCV_CUDA_STATUS
    if _OPENCV_CUDA_CHECKED:
        return _OPENCV_CUDA_AVAILABLE
    _OPENCV_CUDA_CHECKED = True
    _OPENCV_CUDA_AVAILABLE = False

    if not CV2_AVAILABLE:
        _OPENCV_CUDA_STATUS = "cv2_unavailable"
        return False
    if not AMR_GPU_ENABLED or not AMR_QR_GPU_PREPROCESS_ENABLED:
        _OPENCV_CUDA_STATUS = "disabled_by_env"
        return False
    if not hasattr(cv2, "cuda"):
        _OPENCV_CUDA_STATUS = "cv2_cuda_module_missing"
        return False

    try:
        count = int(cv2.cuda.getCudaEnabledDeviceCount())
    except Exception as e:
        _OPENCV_CUDA_STATUS = f"cuda_check_failed:{e}"
        return False

    if count <= 0:
        _OPENCV_CUDA_STATUS = "no_cuda_device_or_opencv_built_without_cuda"
        return False

    try:
        cv2.cuda.setDevice(max(0, min(AMR_QR_CUDA_DEVICE_ID, count - 1)))
    except Exception as e:
        _OPENCV_CUDA_STATUS = f"cuda_set_device_failed:{e}"
        return False

    _OPENCV_CUDA_AVAILABLE = True
    _OPENCV_CUDA_STATUS = f"available:{count}_device(s)"
    return True


try:
    import omni.replicator.core as rep
    REPLICATOR_AVAILABLE = True
except Exception as _rep_err:
    rep = None
    REPLICATOR_AVAILABLE = False
    _REPLICATOR_IMPORT_ERROR = _rep_err

import omni.kit.app
import omni.timeline
import omni.usd
from pxr import Gf, Usd, UsdGeom, UsdPhysics


# ============================================================
# Stage mapping: Final_Factory simple-exec stage
# ============================================================
# v37: User's current USD hierarchy is:
#   /World/defaultPrim/finalfac/finalfac/World3/AMR_01~05
#   /World/defaultPrim/finalfac/finalfac/World3/RACK_01~10
# This root is embedded directly so Script Editor can be run with the old simple command
# without manually setting os.environ path overrides.  Override only if the USD root changes.
WORLD_ROOT = os.environ.get("AMR_FINAL_FACTORY_WORLD_ROOT", "/World/defaultPrim/finalfac/finalfac/World3")

AMR_PRIM_PATHS = {
    f"AMR_{i:02d}": f"{WORLD_ROOT}/AMR_{i:02d}"
    for i in range(1, 6)
}

RACK_PRIM_PATHS = {
    **{
        f"WS_{i:02d}": f"{WORLD_ROOT}/RACK_{i:02d}"
        for i in range(1, 11)
    },
    **{
        f"RACK_{i:02d}": f"{WORLD_ROOT}/RACK_{i:02d}"
        for i in range(1, 11)
    },
}

print(f"FINAL_FACTORY TRUE SPOTS DYNAMIC RACK FOUR-WAY ZONE MODE V41 | WORLD_ROOT={WORLD_ROOT}")


# ============================================================
# v36: auto prim discovery for renamed Final_Factory USD stages
# ============================================================
# Older stages used fixed paths like /World/AMR_01 and /World/RACK_01.
# Final_Factory.usd may place the same objects under different parent prims or names
# such as AMR1, AMR_1, AGV_01, WS01, Workstation_01, etc.
# The controller therefore first tries the configured path, then searches the whole
# currently opened stage by normalized prim-name aliases. Manual env overrides are
# also supported:
#   export AMR_01_PRIM_PATH=/Your/Actual/Path
#   export WS_01_PRIM_PATH=/Your/Actual/Path
#   export RACK_01_PRIM_PATH=/Your/Actual/Path
AUTO_DISCOVER_STAGE_PRIMS = env_bool("AMR_AUTO_DISCOVER_STAGE_PRIMS", True)


def _norm_prim_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def _num_from_logical_name(logical_name: str) -> Optional[int]:
    m = re.search(r"(\d+)$", str(logical_name))
    if not m:
        return None
    try:
        return int(m.group(1))
    except Exception:
        return None


def _amr_aliases(logical_name: str) -> Set[str]:
    n = _num_from_logical_name(logical_name)
    aliases = {logical_name}
    if n is not None:
        aliases.update({
            f"AMR_{n:02d}", f"AMR{n:02d}", f"AMR_{n}", f"AMR{n}",
            f"amr_{n:02d}", f"amr{n:02d}", f"amr_{n}", f"amr{n}",
            f"AGV_{n:02d}", f"AGV{n:02d}", f"AGV_{n}", f"AGV{n}",
            f"Robot_{n:02d}", f"Robot{n:02d}", f"Robot_{n}", f"Robot{n}",
            f"MobileRobot_{n:02d}", f"MobileRobot{n:02d}",
            f"Turtlebot_{n:02d}", f"Turtlebot{n:02d}",
        })
    return aliases


def _rack_aliases(logical_name: str) -> Set[str]:
    n = _num_from_logical_name(logical_name)
    aliases = {logical_name}
    if n is not None:
        aliases.update({
            f"WS_{n:02d}", f"WS{n:02d}", f"WS_{n}", f"WS{n}",
            f"ws_{n:02d}", f"ws{n:02d}", f"ws_{n}", f"ws{n}",
            f"RACK_{n:02d}", f"RACK{n:02d}", f"RACK_{n}", f"RACK{n}",
            f"Rack_{n:02d}", f"Rack{n:02d}", f"Rack_{n}", f"Rack{n}",
            f"Workstation_{n:02d}", f"Workstation{n:02d}", f"Workstation_{n}", f"Workstation{n}",
            f"WORKSTATION_{n:02d}", f"WORKSTATION{n:02d}",
            f"Table_{n:02d}", f"Table{n:02d}", f"Table_{n}", f"Table{n}",
        })
    return aliases


def _env_prim_override_names(logical_name: str, kind: str) -> List[str]:
    # For WS_01, also check RACK_01 override because some users name them by rack id.
    names = [
        f"{logical_name}_PRIM_PATH",
        f"{logical_name}_PATH",
    ]
    if kind == "RACK":
        n = _num_from_logical_name(logical_name)
        if n is not None:
            names.extend([
                f"RACK_{n:02d}_PRIM_PATH",
                f"RACK_{n:02d}_PATH",
                f"WS{n:02d}_PRIM_PATH",
                f"WS{n:02d}_PATH",
            ])
    if kind == "AMR":
        n = _num_from_logical_name(logical_name)
        if n is not None:
            names.extend([
                f"AMR{n:02d}_PRIM_PATH",
                f"AMR{n:02d}_PATH",
                f"AMR{n}_PRIM_PATH",
                f"AMR{n}_PATH",
            ])
    return names


def _is_xformable_prim(prim) -> bool:
    try:
        return prim.IsA(UsdGeom.Xformable)
    except Exception:
        return bool(prim and prim.IsValid())


def resolve_stage_prim_path(stage, logical_name: str, configured_path: str, kind: str) -> Tuple[Optional[str], str]:
    """Return (path, reason). Does not raise."""
    # 1) explicit environment override
    for env_name in _env_prim_override_names(logical_name, kind):
        env_path = os.environ.get(env_name)
        if env_path:
            prim = stage.GetPrimAtPath(env_path)
            if prim.IsValid() and prim.IsActive():
                return str(env_path), f"env:{env_name}"
            print(f"{kind} ENV PATH INVALID: {logical_name} {env_name}={env_path}")

    # 2) old fixed path
    prim = stage.GetPrimAtPath(configured_path)
    if prim.IsValid() and prim.IsActive():
        return configured_path, "configured"

    if not AUTO_DISCOVER_STAGE_PRIMS:
        return None, "configured_missing_auto_disabled"

    aliases = _amr_aliases(logical_name) if kind == "AMR" else _rack_aliases(logical_name)
    alias_norms = {_norm_prim_token(a) for a in aliases}
    kind_hint_norms = {"amr", "agv", "robot", "mobilerobot", "turtlebot"} if kind == "AMR" else {"rack", "ws", "workstation", "table"}

    candidates = []
    try:
        iterator = stage.Traverse()
    except Exception:
        iterator = []

    for p in iterator:
        try:
            if not p.IsValid() or not p.IsActive():
                continue
            if not _is_xformable_prim(p):
                continue
            path_s = str(p.GetPath())
            tail = p.GetName()
            tail_norm = _norm_prim_token(tail)
            path_norm = _norm_prim_token(path_s)
            score = 0
            reason = ""
            if tail_norm in alias_norms:
                score = 100
                reason = "tail_exact"
            else:
                # Match full path only when it contains both the object kind and the numbered alias.
                for a in alias_norms:
                    if a and a in path_norm:
                        # Reject broad false matches such as a texture/material containing ws01 unless the tail/path has kind hints.
                        if any(h in path_norm for h in kind_hint_norms):
                            score = max(score, 75)
                            reason = f"path_contains:{a}"
                # Last fallback: numbered object with kind token in tail.
                n = _num_from_logical_name(logical_name)
                if n is not None:
                    compact_nums = {str(n), f"{n:02d}"}
                    if any(h in tail_norm for h in kind_hint_norms) and any(tail_norm.endswith(num) for num in compact_nums):
                        score = max(score, 65)
                        reason = "tail_kind_number"
            if score:
                # Prefer shallow, root-like Xforms over deep mesh children.
                depth_penalty = path_s.count("/")
                type_bonus = 5 if p.GetTypeName() in {"Xform", "Scope"} else 0
                candidates.append((score + type_bonus, -depth_penalty, path_s, tail, p.GetTypeName(), reason))
        except Exception:
            continue

    if candidates:
        candidates.sort(reverse=True)
        best = candidates[0]
        # Print top few to make mistakes easy to spot in Script Editor.
        preview = ", ".join([f"{c[2]}({c[5]})" for c in candidates[:3]])
        print(f"{kind} AUTO-DISCOVER: {logical_name} -> {best[2]} reason={best[5]} candidates=[{preview}]")
        return best[2], f"auto:{best[5]}"

    return None, "not_found"


def print_stage_object_discovery_report(stage, max_items: int = 200) -> None:
    """Debug helper. Call from Script Editor if object names changed again."""
    print("\n========== STAGE OBJECT DISCOVERY REPORT ==========")
    rows = []
    keywords = ("amr", "agv", "robot", "rack", "ws", "workstation", "table")
    try:
        for p in stage.Traverse():
            if not p.IsValid() or not p.IsActive():
                continue
            path_s = str(p.GetPath())
            tail_s = p.GetName()
            joined = (path_s + " " + tail_s).lower()
            if any(k in joined for k in keywords):
                rows.append((path_s, p.GetTypeName()))
    except Exception as e:
        print(f"STAGE DISCOVERY ERROR: {e}")
        return
    for path_s, type_s in rows[:max_items]:
        print(f"  {path_s} | type={type_s}")
    if len(rows) > max_items:
        print(f"  ... truncated {len(rows) - max_items} more candidates")
    print("=================================================\n")

# If target_x/target_y from Control Tower is 0/empty, target_location falls back to this map.
# Adjust these values to match your factory layout if needed.
LOCATION_TARGETS = {
    # ============================================================
    # v39 Final_Factory TRUE main-warehouse spot coordinates + simple exec auto prim discovery
    # Grid spacing is 1.5 m, so each coordinate maps directly to QR cell=(x/1.5, y/1.5).
    # ============================================================
    # Main warehouse storage spots.
    # Corrected DB layout received after v38: five rows from y=-9.0 to y=3.0.
    # Odd WS are now: WS01(-1,-6), WS03(-1,-4), WS05(-1,-2), WS07(-1,0), WS09(-1,2).
    "spot_01": (-1.5, -9.0, 0.0),
    "spot_02": (-3.0, -9.0, 0.0),
    "spot_03": (-1.5, -6.0, 0.0),
    "spot_04": (-3.0, -6.0, 0.0),
    "spot_05": (-1.5, -3.0, 0.0),
    "spot_06": (-3.0, -3.0, 0.0),
    "spot_07": (-1.5, 0.0, 0.0),
    "spot_08": (-3.0, 0.0, 0.0),
    "spot_09": (-1.5, 3.0, 0.0),
    "spot_10": (-3.0, 3.0, 0.0),

    # Inbound SG2 line buffers.
    "sg2_in_01_A": (7.5, 1.5, 0.0),
    "sg2_in_01_B": (6.0, 1.5, 0.0),
    "sg2_in_02_A": (7.5, -3.0, 0.0),
    "sg2_in_02_B": (6.0, -3.0, 0.0),
    "sg2_in_03_A": (7.5, -7.5, 0.0),
    "sg2_in_03_B": (6.0, -7.5, 0.0),

    # Outbound staging spots.
    "stage_01": (4.5, 9.0, 0.0),
    "stage_02": (4.5, 7.5, 0.0),
    "stage_03": (7.5, 9.0, 0.0),
    "stage_04": (7.5, 7.5, 0.0),
    "stage_drop_01": (4.5, 9.0, 0.0),
    "stage_drop_02": (4.5, 7.5, 0.0),
    "stage_drop_03": (7.5, 9.0, 0.0),
    "stage_drop_04": (7.5, 7.5, 0.0),
    "staging": (4.5, 9.0, 0.0),

    # Outbound packing line buffers.
    "sg2_out_00_A": (-4.5, 9.0, 0.0),
    "sg2_out_00_B": (-4.5, 7.5, 0.0),

    # AMR charging/home spots.
    "charging_01": (-6.0, -9.0, 0.0),
    "charging_02": (-6.0, -7.5, 0.0),
    "charging_03": (-6.0, -6.0, 0.0),
    "charging_04": (-6.0, -4.5, 0.0),
    "charging_05": (-6.0, -3.0, 0.0),

    # Generic fallback.
    "warehouse": (-1.5, -9.0, 0.0),
}


# ============================================================
# v17 SG A/B post-place choreography
# ============================================================
# Purpose: keep the efficient simultaneous A/B dispatch model, but make the
# departure plan explicit after placement.  A positions are inner cells and
# should clear sideways.  B positions are outer cells and should rotate AMR
# heading 180 degrees, then back out toward x-1.
SG_AB_POST_PLACE_ENABLED = True
SG_A_POST_PLACE_BEHAVIOR = "SIDE_EXIT"
SG_B_POST_PLACE_BEHAVIOR = "TURN_180_AND_BACK_EXIT"
POST_PLACE_TURN_DURATION_SEC = float(os.environ.get("AMR_POST_PLACE_TURN_DURATION_SEC", "1.2"))
POST_PLACE_EXIT_LOG_ENABLED = True
# If every preferred exit cell is blocked, fall back to normal return home rather
# than ending the command under the workstation.  This keeps tests recoverable.
POST_PLACE_FALLBACK_TO_RETURN_HOME = True

# ============================================================
# v27 SG local macro route
# ============================================================
# Long-range navigation still uses A*, but once a workstation is approaching an
# SG A/B pair, the final few cells are driven by deterministic local route
# templates.  This intentionally trades full generality for repeatability in the
# narrow SG bay.
SG_LOCAL_MACRO_ROUTE_ENABLED = env_bool("AMR_SG_LOCAL_MACRO_ROUTE_ENABLED", True)
SG_LOCAL_MACRO_LOG_ENABLED = env_bool("AMR_SG_LOCAL_MACRO_LOG_ENABLED", True)
SG_LOCAL_MACRO_A_BORROW_B_ROUTE_ENABLED = env_bool("AMR_SG_LOCAL_MACRO_A_BORROW_B_ROUTE_ENABLED", False)
SG_LOCAL_MACRO_A_BORROW_PENALTY = float(os.environ.get("AMR_SG_LOCAL_MACRO_A_BORROW_PENALTY", "999.0"))
SG_LOCAL_MACRO_USE_REVERSE_EXIT = env_bool("AMR_SG_LOCAL_MACRO_USE_REVERSE_EXIT", True)
# v30 strict mode: SG A/B targets enter through fixed local macro route with next-step availability.
# If the macro route is temporarily blocked, the AMR waits/retries instead of falling back
# to the older pre-target/TO_TARGET behavior.
SG_LOCAL_MACRO_STRICT_AB_ENTRY = env_bool("AMR_SG_LOCAL_MACRO_STRICT_AB_ENTRY", True)
# v29: A does not wait in EXIT_HOLD for same-lane B after exiting; route separation is responsible.
SG_LOCAL_MACRO_DISABLE_A_EXIT_HOLD = env_bool("AMR_SG_LOCAL_MACRO_DISABLE_A_EXIT_HOLD", True)

# v31: full A_in/B_in corridor macro. A and B no longer receive only the
# final one/two local cells.  A* is used only to reach the first corridor gate;
# after that the AMR follows the fixed corridor cell-by-cell.
#
# For a lane whose slot row is y:
#   B: (gate_x, y-1) -> ... -> (B.x, y-1) -> B
#   A: (gate_x, y-1) -> ... -> (A.x, y-1) -> A
# This matches the hand-drawn A_in/B_in traffic rule more closely than v30.
SG_LOCAL_MACRO_A_RIGHT_LANE_ENABLED = env_bool("AMR_SG_LOCAL_MACRO_A_RIGHT_LANE_ENABLED", False)
SG_LOCAL_MACRO_A_RIGHT_LANE_OFFSET_X = int(os.environ.get("AMR_SG_LOCAL_MACRO_A_RIGHT_LANE_OFFSET_X", "1"))
SG_LOCAL_MACRO_FULL_CORRIDOR_ENABLED = env_bool("AMR_SG_LOCAL_MACRO_FULL_CORRIDOR_ENABLED", True)
SG_LOCAL_MACRO_CORRIDOR_GATE_X = int(os.environ.get("AMR_SG_LOCAL_MACRO_CORRIDOR_GATE_X", "2"))
# v33: strict entry corridor. B/BIN remains on the same row as B, but the
# route starts from the AMR current pickup cell and expands cell-by-cell.
# This prevents A* from choosing a detour to B_IN. Example sg2_in_01_B from
# WS07 cell=(1,0): (1,0)->(1,1)->(2,1)->(3,1)->(4,1).
#
# v34: short exit anchor.  Entry remains strict, but A-side exits no longer
# traverse the full reverse corridor.  After placing at an A slot, the AMR backs
# out only N local cells, then RETURN_HOME uses the normal A* planner.  This
# removes the visible detour such as sg2_in_01_A: (5,1)->(5,0)->(4,0)->... before home.
SG_LOCAL_MACRO_B_SAME_ROW_BIN_ENABLED = env_bool("AMR_SG_LOCAL_MACRO_B_SAME_ROW_BIN_ENABLED", True)
SG_LOCAL_MACRO_B_IN_OFFSET_X = int(os.environ.get("AMR_SG_LOCAL_MACRO_B_IN_OFFSET_X", "1"))
SG_LOCAL_MACRO_STRICT_ENTRY_CORRIDOR_ENABLED = env_bool("AMR_SG_LOCAL_MACRO_STRICT_ENTRY_CORRIDOR_ENABLED", True)
# v31 local macro route availability: do not require the whole local route to be empty before starting.
# Only the first gateway cell must be free. Future cells are handled by time-aware A*/global arbiter at their actual arrival tick.
SG_LOCAL_MACRO_CHECK_WHOLE_ROUTE_BEFORE_START = env_bool("AMR_SG_LOCAL_MACRO_CHECK_WHOLE_ROUTE_BEFORE_START", False)
SG_LOCAL_MACRO_A_DIRECT_FALLBACK_IF_RIGHT_INVALID = env_bool("AMR_SG_LOCAL_MACRO_A_DIRECT_FALLBACK_IF_RIGHT_INVALID", False)

# v34: Shorten A-side local exit.  Entry remains fully strict; exit backs out
# only the first N reverse-corridor cells, then RETURN_HOME switches to A*.
SG_LOCAL_MACRO_SHORT_A_EXIT_ANCHOR_ENABLED = env_bool("AMR_SG_LOCAL_MACRO_SHORT_A_EXIT_ANCHOR_ENABLED", True)
SG_LOCAL_MACRO_A_SHORT_EXIT_STEPS = int(os.environ.get("AMR_SG_LOCAL_MACRO_A_SHORT_EXIT_STEPS", "1"))
SG_LOCAL_MACRO_SHORT_EXIT_LOG_ENABLED = env_bool("AMR_SG_LOCAL_MACRO_SHORT_EXIT_LOG_ENABLED", True)

# v30 time-aware arbiter: route/segment overlap is allowed when arrival time differs.
TIME_AWARE_SEGMENT_CHECK_ENABLED = env_bool("AMR_TIME_AWARE_SEGMENT_CHECK_ENABLED", True)
TIME_AWARE_SEGMENT_CLEARANCE_SCALE = float(os.environ.get("AMR_TIME_AWARE_SEGMENT_CLEARANCE_SCALE", "0.72"))
LOADED_AMR_SPACING_SOFTENED_V30 = env_bool("AMR_LOADED_AMR_SPACING_SOFTENED_V30", True)


# ============================================================
# v18 SG lane pre-target choreography
# ============================================================
# v17 solved only the motion after placing.  The latest log showed that most
# AMRs never reached PLACING; they deadlocked during TO_TARGET.  v18 therefore
# stages B-side AMRs at a wait cell before final entry and releases them only
# after the same-lane A task has started side-exit/return.
SG_AB_PRE_TARGET_STAGING_ENABLED = True
PRE_TARGET_WAIT_LOG_ENABLED = True
PRE_TARGET_WAIT_MAX_TICKS = int(os.environ.get("AMR_PRE_TARGET_WAIT_MAX_TICKS", "220"))  # log-only in v20; never releases B by timeout
PRE_TARGET_WAIT_LOG_PERIOD = int(os.environ.get("AMR_PRE_TARGET_WAIT_LOG_PERIOD", "40"))

# ============================================================
# v23/v24 early B final release + generic conflict-zone loaded-priority yield
# ============================================================
# Do NOT tune by lane name or by a specific AMR.  These rules apply to any lane:
# if an empty AMR returning home would move into the near-future approach/final
# conflict zone of a loaded delivery AMR, the empty AMR yields.  This preserves
# the MVP requirement that behavior is driven by roles and path conflicts, not by
# hard-coded SG1/SG2 exceptions.
GENERIC_CONFLICT_ZONE_YIELD_ENABLED = env_bool("AMR_GENERIC_CONFLICT_ZONE_YIELD_ENABLED", True)
GENERIC_CONFLICT_ZONE_LOG_ENABLED = env_bool("AMR_GENERIC_CONFLICT_ZONE_LOG_ENABLED", True)
GENERIC_CONFLICT_ZONE_RADIUS_CELLS = int(os.environ.get("AMR_GENERIC_CONFLICT_ZONE_RADIUS_CELLS", "1"))
GENERIC_CONFLICT_ZONE_SECOND_STEP_ENABLED = env_bool("AMR_GENERIC_CONFLICT_ZONE_SECOND_STEP_ENABLED", True)
LOADED_DELIVERY_ROLE_PRIORITY_BOOST = float(os.environ.get("AMR_LOADED_DELIVERY_ROLE_PRIORITY_BOOST", "180.0"))
LOADED_B_FINAL_ROLE_PRIORITY_BOOST = float(os.environ.get("AMR_LOADED_B_FINAL_ROLE_PRIORITY_BOOST", "80.0"))
EMPTY_RETURN_ROLE_PRIORITY_PENALTY = float(os.environ.get("AMR_EMPTY_RETURN_ROLE_PRIORITY_PENALTY", "70.0"))
EMPTY_RETURN_YIELD_LOG_PERIOD = int(os.environ.get("AMR_EMPTY_RETURN_YIELD_LOG_PERIOD", "20"))

# ============================================================
# v23/v24 generic early B final release
# ============================================================
# This is not lane-specific.  A B-side workstation may enter its final target
# before the same-lane A AMR reaches RETURN_HOME, but only when the A rack has
# already detached and the A AMR has a confirmed side-exit move reservation away
# from the A target.  The intent is to reduce B idle time while preserving the
# side-exit clearance that v20/v21 protected.
EARLY_B_FINAL_RELEASE_ENABLED = env_bool("AMR_EARLY_B_FINAL_RELEASE_ENABLED", True)
EARLY_B_FINAL_RELEASE_LOG_ENABLED = env_bool("AMR_EARLY_B_FINAL_RELEASE_LOG_ENABLED", True)

# ============================================================
# v24 generic 3-stage B entry + A exit-hold + explicit completion states
# ============================================================
# No SG/AMR-specific exceptions are used.  B-side workstations pass through
# three semantic entry stages before final placement.  A-side AMRs that have
# dropped their workstation perform a side-exit, then hold at the exit cell until
# the same-lane B delivery has reached final/placing/done.  This prevents an
# empty return-home AMR from re-entering the shared approach corridor too early.
B_3STAGE_ENTRY_ENABLED = env_bool("AMR_B_3STAGE_ENTRY_ENABLED", True)
A_EXIT_HOLD_ENABLED = env_bool("AMR_A_EXIT_HOLD_ENABLED", True)
A_EXIT_HOLD_LOG_ENABLED = env_bool("AMR_A_EXIT_HOLD_LOG_ENABLED", True)
B_STAGE_LOG_ENABLED = env_bool("AMR_B_STAGE_LOG_ENABLED", True)
DELIVERY_DONE_LOG_ENABLED = env_bool("AMR_DELIVERY_DONE_LOG_ENABLED", True)


# ============================================================
# Bridge queue paths
# ============================================================
BRIDGE_QUEUE_DIR = Path("/home/rokey/isaaclab_ws/isaac_aruco/amr/bridge_queue")
COMMAND_DIR = BRIDGE_QUEUE_DIR / "commands"
STATUS_DIR = BRIDGE_QUEUE_DIR / "status"
RESULT_DIR = BRIDGE_QUEUE_DIR / "results"
DONE_DIR = BRIDGE_QUEUE_DIR / "done"
CANCEL_DIR = BRIDGE_QUEUE_DIR / "cancel"


# ============================================================
# Redis realtime AMR status publishing
# ============================================================
# Control Tower / DB / Redis PC. Update if the other PC uses a different IP.
REDIS_STATUS_ENABLED = True
REDIS_HOST = "192.168.100.20"
REDIS_PORT = 6379
REDIS_KEY_PREFIX = "amr:"
REDIS_PUBLISH_PERIOD_SEC = float(os.environ.get("AMR_REDIS_PUBLISH_PERIOD_SEC", "0.20"))  # optimized default: 5 Hz
REDIS_CONNECT_TIMEOUT_SEC = 0.08
REDIS_RECONNECT_PERIOD_SEC = 3.0
REDIS_BATTERY_DEFAULT = "85.0"


# ============================================================
# Motion / planner parameters
# ============================================================
GRID_SPACING = 1.5
AMR_SIZE_M = 0.7
RACK_SIZE_M = 1.3
SAFETY_MARGIN_M = 0.12

AMR_SPEED_MPS = 1.35
AMR_CARRY_SPEED_MPS = 0.90
LIFT_HEIGHT_M = 0.10
LIFT_DURATION_SEC = 0.45
PLACE_DURATION_SEC = 0.45
ROTATE_DURATION_SEC = 1.20
ROTATE_WORKSTATION_TARGETS = {"ROTATE_WORKSTATION", "ROTATE", "ROTATE_180", "WORKSTATION_ROTATE", "TURN_WORKSTATION"}
ROTATE_LOCATION_KEYWORDS = {"ROTATING", "ROTATE_WORKSTATION", "ROTATE_180"}
ROTATE_WORKSTATION_DELTA_RAD = math.pi

MAX_TIME_HORIZON = 80
RESERVATION_HORIZON = int(os.environ.get("AMR_RESERVATION_HORIZON", "35"))
GOAL_HOLD_STEPS = int(os.environ.get("AMR_GOAL_HOLD_STEPS", "4"))
# v19: true reservation-table A*.
# When enabled, higher-priority AMRs reserve their timed future path before the
# next AMR is planned. Lower-priority AMRs then plan around those time-indexed
# reservations instead of colliding first and waiting at the arbiter.
RESERVATION_TABLE_ASTAR_ENABLED = env_bool("AMR_RESERVATION_TABLE_ASTAR_ENABLED", True)
RESERVATION_TABLE_ASTAR_LOG_ENABLED = env_bool("AMR_RESERVATION_TABLE_ASTAR_LOG_ENABLED", True)
RESERVATION_TABLE_ASTAR_LOG_PERIOD = int(os.environ.get("AMR_RESERVATION_TABLE_ASTAR_LOG_PERIOD", "40"))
LOOKAHEAD_STEPS = 2
DECISION_PERIOD_SEC = 0.08
COMMAND_SCAN_PERIOD_SEC = 0.20
STATUS_PERIOD_SEC = 0.25
LOG_PERIOD_SEC = 5.0

# ============================================================
# QR camera localization parameters
# ============================================================
# This does not change the 8-way planner. It only changes how AMR current_cell is observed.
QR_CAMERA_LOCALIZATION_ENABLED = True
QR_CAMERA_SCAN_PERIOD_SEC = float(os.environ.get("AMR_QR_CAMERA_SCAN_PERIOD_SEC", "0.45"))
QR_CAMERA_RESOLUTION = (
    int(os.environ.get("AMR_QR_CAMERA_WIDTH", "320")),
    int(os.environ.get("AMR_QR_CAMERA_HEIGHT", "240")),
)
QR_DETECTOR_EVERY_N_SCANS = int(os.environ.get("AMR_QR_DETECTOR_EVERY_N_SCANS", "1"))
QR_LOG_PERIOD_SEC = 5.0
QR_SCAN_ROUND_ROBIN_ENABLED = True
QR_SCAN_MAX_AMRS_PER_CYCLE = 1

# Safe QR localization gate.
# QR navigation is kept enabled, but detected QR cells are accepted only when they
# are physically plausible. This prevents two-cell jumps caused by reading a
# forward/neighbor QR while the scripted grid motion is still between cells.
QR_SAFE_STABLE_DETECTIONS = int(os.environ.get("AMR_QR_SAFE_STABLE_DETECTIONS", "2"))
QR_SAFE_MAX_CELL_JUMP = int(os.environ.get("AMR_QR_SAFE_MAX_CELL_JUMP", "1"))
QR_SAFE_MAX_WORLD_DIST_M = float(os.environ.get("AMR_QR_SAFE_MAX_WORLD_DIST_M", "1.0"))
QR_SAFE_BLOCK_STATES = {"LIFTING", "PLACING", "ROTATING"}

# If True, the demo keeps moving even when the QR is temporarily missed.
# The log will clearly say source=TRANSFORM_FALLBACK.
# Keep this False for QR-based tests: fallback may hide QR misreads.
QR_ALLOW_TRANSFORM_FALLBACK = False

# Navigation must use QR-coded cells only.
# If the QR map is loaded, A* will never plan through cells that do not have a QR marker.
QR_ONLY_NAVIGATION = True
QR_SNAP_TARGET_TO_NEAREST = True
QR_MAX_SNAP_DISTANCE_M = 2.20

# If a Control Tower goal resolves to the same QR cell as the rack pickup cell,
# the AMR would lift and immediately place. Prevent that by forcing the drop
# target to a different QR cell at least this many cells away from pickup.
COMMAND_MIN_DROP_DISTANCE_CELLS = 3

# Rack is moved as a kinematic object while carried to prevent physics sliding.
RACK_LOCK_TO_AMR_WHILE_CARRIED = True
RACK_DISABLE_RIGID_BODY_WHILE_CARRIED = True
# For this live demo, racks are script-controlled objects.
# We keep rack physics/collision disabled and use the software planner for obstacles.
RACK_DISABLE_PHYSICS_AT_STARTUP = True
RACK_KEEP_COLLISION_DISABLED_AFTER_PLACE = True

# When an AMR passes through or very near a rack/workstation, diagonal movement is forbidden.
# This represents the 4-leg workstation constraint: entering/exiting under the workstation must be done
# with cardinal motion only, not diagonal crossing between legs.
RACK_FOUR_WAY_ZONE_ENABLED = True
RACK_FOUR_WAY_ZONE_RADIUS_CELLS = 1

# v41 dynamic workstation four-way zone.
# Important: this does NOT reserve/block the surrounding 8 cells.
# AMRs may pass through the 3x3 neighborhood around a workstation, but while
# entering/leaving/crossing that neighborhood diagonal moves are forbidden.
# This models the four-leg workstation constraint without turning the whole
# neighborhood into an obstacle reservation.
RACK_DYNAMIC_FOUR_WAY_ZONE_ENABLED = os.environ.get("AMR_RACK_DYNAMIC_FOUR_WAY_ZONE_ENABLED", "1") != "0"
RACK_DYNAMIC_FOUR_WAY_RADIUS_CELLS = int(os.environ.get("AMR_RACK_DYNAMIC_FOUR_WAY_RADIUS_CELLS", "1"))
# Backward-compatible aliases: old v40 env names still work, but now mean
# "four-way-only zone", not obstacle/reservation zone.
RACK_DYNAMIC_SAFETY_ZONE_ENABLED = os.environ.get("AMR_RACK_DYNAMIC_SAFETY_ZONE_ENABLED", "1") != "0"
RACK_DYNAMIC_SAFETY_RADIUS_CELLS = int(os.environ.get("AMR_RACK_DYNAMIC_SAFETY_RADIUS_CELLS", str(RACK_DYNAMIC_FOUR_WAY_RADIUS_CELLS)))
RACK_DYNAMIC_SAFETY_APPLIES_TO_EMPTY = True
RACK_DYNAMIC_SAFETY_INCLUDE_DIAGONALS = True

# AMR heading convention. The controller assumes the visual front of the AMR points along +X when yaw=0.
# If your imported AMR model visually faces another direction, change only this value.
AMR_FRONT_YAW_OFFSET_DEG = 0.0
AMR_FRONT_YAW_OFFSET_RAD = math.radians(AMR_FRONT_YAW_OFFSET_DEG)

# v14 user-requested visual heading correction.
# No additional visual heading offset. Robot front is aligned directly with movement direction.
AMR_VISUAL_HEADING_CLOCKWISE_OFFSET_DEG = 0.0
AMR_VISUAL_HEADING_CLOCKWISE_OFFSET_RAD = math.radians(AMR_VISUAL_HEADING_CLOCKWISE_OFFSET_DEG)

# v11 stronger swept-path clearance. This prevents a diagonal AMR and a cardinal AMR
# from visually clipping during the same tick even if their destination cells differ.
DYNAMIC_SWEPT_COLLISION_MARGIN_M = 0.22
DIAGONAL_CARDINAL_CONFLICT_ENABLED = True

# v12 anti-clump / lookahead controls.
# LOOKAHEAD_STEPS was already configured as 2; v12 makes the second cell actively participate
# in global arbitration instead of only being kept in the planned path.
LOOKAHEAD2_ACTIVE_ARBITEER = True
LOOKAHEAD2_MIN_CLEARANCE_CELLS = 1

# v18 path-shape tuning.  The previous carrying turn penalty was too high, so
# the planner sometimes preferred a long detour over a simple 90-degree turn.
TURN_COST_EMPTY_90 = 0.03
TURN_COST_EMPTY_180 = 0.55
TURN_COST_CARRY_90 = 0.08
TURN_COST_CARRY_180 = 0.85

# v22 path-shape stability.  A waiting/following AMR should not suddenly back up
# when a short right/left turn or one-tick wait would be better.  U-turns and
# moves that increase the distance to the task goal are still allowed, but they
# are deliberately expensive so they are used only when no better route exists.
WAIT_COST_EMPTY = 0.75
WAIT_COST_CARRY = 0.90
REVERSE_MOVE_EXTRA_COST_EMPTY = 0.45
REVERSE_MOVE_EXTRA_COST_CARRY = 0.70
GOAL_REGRESSION_COST_EMPTY = 0.25
GOAL_REGRESSION_COST_CARRY = 0.35
KEEP_HEADING_SMALL_BONUS = 0.02

# v18/v19 convoy tuning. Same-direction following may use the cell vacated by the
# leading AMR in the same tick; otherwise straight-line traffic keeps an
# unnecessary 2-cell gap.  v20 keeps this into tail-release following:
# a trailing AMR may enter a cell only when the AMR currently occupying that cell
# is also approved to leave it in the same tick.  This keeps current AMR cells
# as hard blocks unless they are explicitly vacated by the approved leader move.
ALLOW_SAME_DIRECTION_CONVOY_FOLLOWING = True
ALLOW_VACATED_CELL_TAIL_RELEASE = True
ALLOW_LOADED_STRAIGHT_TIGHT_CONVOY = True
ALLOW_LOADED_TURN_TAIL_RELEASE = False
# v25 safety rule:
# - Straight same-direction convoy may use tail-release.
# - Perpendicular/L-shaped tail-release must be conservative when any AMR is carrying
#   a rack/workstation. A loaded AMR has a wider swept footprint; the follower must
#   wait until the loaded leader has actually completed the move.
ALLOW_EMPTY_TURN_TAIL_RELEASE = True
ALLOW_LOADED_PERPENDICULAR_TAIL_RELEASE = False
# v25 target lock:
# Keep explicit SG2 A/B destinations from being rewritten by the defensive
# "away from pickup" fallback, unless the requested target is exactly the pickup cell.
LOCK_EXPLICIT_SG2_AB_TARGETS = True

# v26 5-AMR congestion recovery.
# With 5 simultaneous tasks, a few AMRs can remain motionless because carrying
# AMRs keep winning arbitration and waiting AMRs keep selecting one-tick waits.
# This keeps all previous safety rules, but adds aging: the longer an AMR waits,
# the higher its arbitration priority becomes and the more expensive an additional
# wait action becomes.
CONGESTION_AGING_ENABLED = True
CONGESTION_WAIT_PRIORITY_CAP = 120
CONGESTION_TO_RACK_EXTRA_BOOST_AFTER = 35
CONGESTION_TO_RACK_EXTRA_BOOST = 70
CONGESTION_WAIT_COST_STEP_EMPTY = 0.030
CONGESTION_WAIT_COST_STEP_CARRY = 0.020
CONGESTION_WAIT_COST_CAP_EMPTY = 2.50
CONGESTION_WAIT_COST_CAP_CARRY = 2.00

# v10 dense loaded-lane spread.
# When three or more rack-carrying AMRs form a tight vertical queue, a plain
# shortest-path policy can keep the middle AMR going straight one more cell and
# continue blocking the two side AMRs.  This local traffic rule only rewrites the
# first proposal in that narrow jam pattern: the center blocker yields left/out,
# the lower AMR goes straight toward SG2, and the upper AMR turns toward its goal.
# The global arbiter still performs every normal collision, footprint, tail-release
# and QR safety check after this rewrite.
LOADED_LANE_SPREAD_ENABLED = True
LOADED_LANE_SPREAD_MIN_GROUP_SIZE = 3
LOADED_LANE_SPREAD_WAIT_THRESHOLD = 8
LOADED_LANE_SPREAD_LOG_PERIOD = 20

# v11 bottleneck turn-first policy.
# In dense SG2 traffic, continuing straight one more cell can keep the bottleneck
# closed. Once an AMR has waited for several ticks, prefer a 90-degree turn/yield
# over another straight step. This is a preference, not a hard command: every
# rewritten proposal still passes the normal QR, footprint, tail-release and
# swept-collision checks in the global arbiter.
BOTTLENECK_TURN_FIRST_ENABLED = True
BOTTLENECK_TURN_FIRST_WAIT_THRESHOLD = 8
BOTTLENECK_TURN_BONUS_EMPTY = 0.18
BOTTLENECK_TURN_BONUS_CARRY = 0.42
BOTTLENECK_STRAIGHT_EXTRA_EMPTY = 0.10
BOTTLENECK_STRAIGHT_EXTRA_CARRY = 0.28
BOTTLENECK_TURN_PRIORITY_BONUS = 90.0
BOTTLENECK_TURN_FIRST_LOG_PERIOD = 20

# v12 preemptive turn-first policy.
# v11 waited until wait/no_path accumulated, so the AMRs could already be packed into
# a one-column loaded queue before the turn-first rule started.  v12 predicts that
# bottleneck earlier from local loaded-neighbor density and same-column loaded queues,
# then prefers a 90-degree yield before the straight step closes the corridor.
PREEMPTIVE_TURN_FIRST_ENABLED = True
PREEMPTIVE_TURN_ONLY_CARRYING = True
PREEMPTIVE_TURN_LOCAL_DENSITY_THRESHOLD = 3
PREEMPTIVE_TURN_LOADED_NEIGHBOR_THRESHOLD = 2
PREEMPTIVE_TURN_SAME_COLUMN_GROUP_SIZE = 3
PREEMPTIVE_TURN_MAX_GOAL_REGRESSION = 2
PREEMPTIVE_TURN_PRIORITY_BONUS = 60.0
PREEMPTIVE_TURN_LOG_PERIOD = 20

# v14 final-drop-lock return-home policy.
# Keep no-path escape for the AMR carrying its current workstation, but do NOT
# create internal lane-clearance jobs that re-pick a workstation after it has
# already been placed at its requested destination.  This matches the test goal:
# workstations stay where they are dropped; only the AMR returns home.
NO_PATH_ESCAPE_WAYPOINT_ENABLED = True
NO_PATH_ESCAPE_THRESHOLD = 35
NO_PATH_ESCAPE_RADIUS = 3
NO_PATH_ESCAPE_LOG_PERIOD = 20
DYNAMIC_SG2_LANE_CLEARANCE_ENABLED = False
RETURN_HOME_CLEARANCE_PREEMPT_ENABLED = False


# v15 traffic-level starvation/spacing diagnostics.
# The log analysis showed AMR_02 often had no_path=0 but wait kept increasing,
# which means A* found a route but the global arbiter rejected the one-step move.
# These rules keep all v14 final-drop-lock behavior, but add:
# 1) wait/no_path==0 starvation unlock priority,
# 2) loaded AMR spacing guard to avoid creating tight side-by-side rack clusters,
# 3) explicit reject-reason logs from the arbiter.
STARVATION_UNLOCK_ENABLED = True
# v16: lower the trigger a little because the user test now starts AMRs one-by-one.
# If wait increases while no_path remains 0, the robot has a valid route but is losing arbitration.
STARVATION_UNLOCK_WAIT_THRESHOLD = 18
STARVATION_UNLOCK_PRIORITY_BONUS = 500.0
STARVATION_UNLOCK_LOG_PERIOD = 20

# v16: command JSON may request a specific AMR.  This is used by the 1-3-5-7-9
# stagger manager so command 1 uses AMR_01, command 2 uses AMR_02, and so on.
PREFERRED_AMR_ASSIGNMENT_ENABLED = True

LOADED_AMR_MIN_SPACING_ENABLED = True
LOADED_AMR_MIN_CHEBYSHEV_DISTANCE = int(os.environ.get("AMR_LOADED_AMR_MIN_CHEBYSHEV_DISTANCE", "1"))
LOADED_AMR_SPACING_ALLOW_STRAIGHT_CONVOY = True
LOADED_AMR_SPACING_LOG_PERIOD = 20

ARB_REJECT_REASON_LOG_ENABLED = True
ARB_REJECT_REASON_LOG_PERIOD = 20

# v42 cost-aware global reroute layer.
# A* already has movement/wait costs, but the global arbiter can still reject
# the chosen first step after planning. This layer gives rejected AMRs a
# second-chance replan with the rejected first step blocked, then compares:
#   WAIT cost  vs  DETOUR extra cost.
# It is applied at the common global driving layer, so it covers TO_RACK,
# LOCAL_ENTRY, TO_TARGET, LOCAL_EXIT, RETURN_HOME and RANDOM.
COST_AWARE_GLOBAL_REROUTE_ENABLED = env_bool("AMR_COST_AWARE_GLOBAL_REROUTE_ENABLED", True)
COST_AWARE_REROUTE_MIN_WAIT_STEPS = int(os.environ.get("AMR_COST_AWARE_REROUTE_MIN_WAIT_STEPS", "3"))
COST_AWARE_REROUTE_FORCE_AFTER_WAIT_STEPS = int(os.environ.get("AMR_COST_AWARE_REROUTE_FORCE_AFTER_WAIT_STEPS", "18"))
COST_AWARE_REROUTE_MAX_EXTRA_CELLS_EMPTY = float(os.environ.get("AMR_COST_AWARE_REROUTE_MAX_EXTRA_CELLS_EMPTY", "5.0"))
COST_AWARE_REROUTE_MAX_EXTRA_CELLS_CARRY = float(os.environ.get("AMR_COST_AWARE_REROUTE_MAX_EXTRA_CELLS_CARRY", "3.0"))
COST_AWARE_WAIT_COST_PER_TICK_EMPTY = float(os.environ.get("AMR_COST_AWARE_WAIT_COST_PER_TICK_EMPTY", "0.65"))
COST_AWARE_WAIT_COST_PER_TICK_CARRY = float(os.environ.get("AMR_COST_AWARE_WAIT_COST_PER_TICK_CARRY", "0.85"))
COST_AWARE_WAIT_REASON_PENALTY = float(os.environ.get("AMR_COST_AWARE_WAIT_REASON_PENALTY", "2.0"))
COST_AWARE_DETOUR_TURN_COST_EMPTY = float(os.environ.get("AMR_COST_AWARE_DETOUR_TURN_COST_EMPTY", "0.20"))
COST_AWARE_DETOUR_TURN_COST_CARRY = float(os.environ.get("AMR_COST_AWARE_DETOUR_TURN_COST_CARRY", "0.45"))
COST_AWARE_REROUTE_LOG_ENABLED = env_bool("AMR_COST_AWARE_REROUTE_LOG_ENABLED", True)
COST_AWARE_REROUTE_LOG_PERIOD = int(os.environ.get("AMR_COST_AWARE_REROUTE_LOG_PERIOD", "12"))

ANTI_CLUMP_ENABLED = True
ANTI_CLUMP_RADIUS_CELLS = 2
ANTI_CLUMP_MIN_GROUP_SIZE = 3
ANTI_CLUMP_GOAL_MIN_SEPARATION_CELLS = 4
REJECTED_MOVE_GOAL_REASSIGN_STEPS = 2

# v16 path policy patch: Mode C two-step approval.
# - Carrying AMR: 4-way A* + center/up/down/left/right rack footprint check.
# - Empty AMR: true 8-way movement, no stationary-rack footprint obstacle, can pass under racks.
# - Move approval treats the second planned cell as soft lookahead only; it never blocks a safe one-cell move.
# - Goal-cell entry never requires lookahead cells beyond the goal.
PATH_POLICY_MODE_C_2STEP_APPROVAL = True

# v14 unique target control.
# Prevent two AMRs from being assigned the same final QR cell.
UNIQUE_RANDOM_GOALS_ENABLED = True
UNIQUE_TASK_TARGET_RESERVATION_ENABLED = True
DUPLICATE_TARGET_RESOLVE_ENABLED = True

# v9 heading calibration:
# The AMR visual front is NOT assumed to be root +X.
# It is measured from the line: AMR visual bbox center -> selected front reference bbox center.
# During every move, root yaw is adjusted by the delta between current visual-front yaw and desired movement yaw.
FRONT_REFERENCE_KEYWORDS = [
    "frontnameplate",
    "front_nameplate",
    "front-nameplate",
    "frontplate",
    "front_plate",
    "frontsignature",
    "signaturelight",
    "topthinbluelinefront",
    "frontamber",
    "frontblue",
    "nameplate",
]

# Camera prim search keywords under each AMR. Keep these broad because the USD naming may vary.
QR_CAMERA_NAME_KEYWORDS = ["downward", "qr", "camera"]

# Keep the same QR detection algorithm. This only changes where RGB->BGR conversion runs.
QR_PREPROCESS_BACKEND = "CUDA_RGB2BGR_IF_AVAILABLE"

RANDOM_DRIVE_ENABLED = False
RANDOM_GOAL_MIN_RADIUS_CELL = 4
RANDOM_GOAL_RANGE_CELL = 8

# v15 integration mode: wait until Control Tower command arrives.
# Commands left in bridge_queue before this controller starts are ignored to prevent old tests
# from moving racks by themselves.
STANDBY_UNTIL_COMMAND = True
IGNORE_STALE_COMMANDS_ON_STARTUP = True
STALE_COMMAND_GRACE_SEC = 2.0

random.seed(42)

GridCell = Tuple[int, int]
TimedCell = Tuple[int, int, int]
EdgeKey = Tuple[int, int, int, int, int]
Move = Tuple[int, int]

# Filled by ExistingStageTrue8Controller.build_qr_prim_map().
GLOBAL_VALID_QR_CELLS: Set[GridCell] = set()
GLOBAL_QR_CELL_WORLD_MAP: Dict[GridCell, Tuple[float, float]] = {}
GLOBAL_RACK_FOUR_WAY_CELLS: Set[GridCell] = set()


# ============================================================
# File helpers
# ============================================================
def ensure_dirs():
    for d in [COMMAND_DIR, STATUS_DIR, RESULT_DIR, DONE_DIR, CANCEL_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def safe_read_json(path: Path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def safe_write_json(path: Path, data: Dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".{int(time.time() * 1000)}.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)


# ============================================================
# USD transform helpers
# ============================================================
def get_stage():
    return omni.usd.get_context().get_stage()


def get_world_translation(prim) -> Gf.Vec3d:
    mat = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default())
    tr = mat.ExtractTranslation()
    return Gf.Vec3d(float(tr[0]), float(tr[1]), float(tr[2]))


def get_bbox_center_world(prim) -> Gf.Vec3d:
    cache = UsdGeom.BBoxCache(
        Usd.TimeCode.Default(),
        [UsdGeom.Tokens.default_, UsdGeom.Tokens.render, UsdGeom.Tokens.proxy],
        useExtentsHint=True,
    )
    box = cache.ComputeWorldBound(prim).ComputeAlignedBox()
    mn = box.GetMin()
    mx = box.GetMax()
    return Gf.Vec3d(
        float(mn[0] + mx[0]) * 0.5,
        float(mn[1] + mx[1]) * 0.5,
        float(mn[2] + mx[2]) * 0.5,
    )


def normalize_angle_rad(angle: float) -> float:
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle <= -math.pi:
        angle += 2.0 * math.pi
    return angle


def get_root_yaw_rad(prim) -> float:
    try:
        api = UsdGeom.XformCommonAPI(prim)
        _translate, rotate, _scale, _pivot, _rot_order = api.GetXformVectors(Usd.TimeCode.Default())
        return math.radians(float(rotate[2]))
    except Exception:
        pass

    try:
        xformable = UsdGeom.Xformable(prim)
        for op in xformable.GetOrderedXformOps():
            if op.GetOpType() == UsdGeom.XformOp.TypeRotateXYZ:
                value = op.Get(Usd.TimeCode.Default())
                return math.radians(float(value[2]))
            if op.GetOpType() == UsdGeom.XformOp.TypeRotateZ:
                value = op.Get(Usd.TimeCode.Default())
                return math.radians(float(value))
    except Exception:
        pass

    return 0.0


def find_front_reference_prim(stage, amr_root_path: str):
    root = stage.GetPrimAtPath(amr_root_path)
    if not root.IsValid():
        return None

    candidates = []
    for prim in Usd.PrimRange(root):
        if not prim.IsValid() or not prim.IsActive():
            continue

        path = str(prim.GetPath())
        name = prim.GetName()
        compact_path = path.lower().replace("_", "").replace("-", "").replace(" ", "")
        compact_name = name.lower().replace("_", "").replace("-", "").replace(" ", "")
        type_name = prim.GetTypeName()

        score = 0

        # Strongly prefer actual front visual markers. In this AMR model,
        # FrontSignatureLight / TopThinBlueLineFront are more reliable than wheel front caps.
        preferred_terms = [
            "frontnameplate",
            "frontsignaturelight",
            "frontsignature",
            "signaturelight",
            "topthinbluelinefront",
            "frontplate",
            "frontblueedge",
            "frontamberglow",
            "frontamber",
            "frontblue",
            "nameplate",
        ]
        for idx, term in enumerate(preferred_terms):
            if term in compact_path or term in compact_name:
                score += 200 - idx * 5

        if "front" in compact_path or "front" in compact_name:
            score += 30
        if "nameplate" in compact_path or "nameplate" in compact_name:
            score += 40

        # Do not use wheel/pod/cap/housing meshes as the front reference.
        bad_terms = ["wheel", "pod", "housing", "cap", "rear", "back", "left", "right", "fl", "fr"]
        for term in bad_terms:
            if term in compact_path or term in compact_name:
                score -= 120

        if type_name in ("Mesh", "Cube", "Xform"):
            score += 2

        if score > 0:
            candidates.append((score, path, prim))

    if not candidates:
        return None

    candidates.sort(key=lambda item: (item[0], -len(item[1])), reverse=True)
    return candidates[0][2]

def calibrate_front_yaw_offset(stage, amr_prim, amr_name: str) -> Tuple[float, str]:
    front_prim = find_front_reference_prim(stage, str(amr_prim.GetPath()))
    if front_prim is None:
        print(
            f"AMR FRONT CALIBRATION FALLBACK | {amr_name} "
            f"front reference not found, offset_deg={AMR_FRONT_YAW_OFFSET_DEG:.3f}"
        )
        return AMR_FRONT_YAW_OFFSET_RAD, ""

    amr_center = get_bbox_center_world(amr_prim)
    front_center = get_bbox_center_world(front_prim)
    vx = float(front_center[0] - amr_center[0])
    vy = float(front_center[1] - amr_center[1])
    length = math.hypot(vx, vy)

    if length < 1e-5:
        print(
            f"AMR FRONT CALIBRATION FALLBACK | {amr_name} "
            f"front reference bbox too close path={front_prim.GetPath()}"
        )
        return AMR_FRONT_YAW_OFFSET_RAD, str(front_prim.GetPath())

    root_yaw = get_root_yaw_rad(amr_prim)
    front_world_yaw = math.atan2(vy, vx)
    front_offset = normalize_angle_rad(front_world_yaw - root_yaw)

    print(
        f"AMR FRONT CALIBRATED V11 | {amr_name} "
        f"front={front_prim.GetPath()} "
        f"root_yaw_deg={math.degrees(root_yaw):.2f} "
        f"front_bbox_yaw_deg={math.degrees(front_world_yaw):.2f} "
        f"front_offset_deg={math.degrees(front_offset):.2f}"
    )
    return front_offset, str(front_prim.GetPath())


def get_amr_visual_front_yaw_rad(amr) -> Optional[float]:
    front_path = getattr(amr, "front_reference_path", "")
    if not front_path:
        return None
    stage = get_stage()
    if stage is None:
        return None
    front_prim = stage.GetPrimAtPath(front_path)
    if not front_prim.IsValid() or not front_prim.IsActive():
        return None

    try:
        amr_center = get_bbox_center_world(amr.obj.prim)
        front_center = get_bbox_center_world(front_prim)
        vx = float(front_center[0] - amr_center[0])
        vy = float(front_center[1] - amr_center[1])
        if math.hypot(vx, vy) < 1e-5:
            return None
        return math.atan2(vy, vx)
    except Exception:
        return None

def get_xy(prim) -> Tuple[float, float]:
    p = get_world_translation(prim)
    return float(p[0]), float(p[1])


def get_z(prim) -> float:
    p = get_world_translation(prim)
    return float(p[2])


def set_translate(prim, x: float, y: float, z: float):
    """Set prim root to a requested WORLD translation.

    Older stages had AMR/RACK roots as direct children of /World, so local translate
    happened to equal world translate.  Final_Factory nests objects under
    /World/defaultPrim/finalfac/finalfac/World3.  Writing world coordinates directly
    into a nested prim's local translate can move racks far away, which looks like the
    workstation disappeared.

    This function converts the requested world coordinate into the parent prim's
    local frame, then writes that local translate op.
    """
    target_world = Gf.Vec3d(float(x), float(y), float(z))
    local_value = target_world
    try:
        parent = prim.GetParent()
        if parent and parent.IsValid() and not parent.IsPseudoRoot():
            cache = UsdGeom.XformCache(Usd.TimeCode.Default())
            parent_world = cache.GetLocalToWorldTransform(parent)
            local_value = parent_world.GetInverse().Transform(target_world)
    except Exception as e:
        print(f"WORLD TRANSLATE FALLBACK | prim={prim.GetPath()} err={e}")
        local_value = target_world

    xformable = UsdGeom.Xformable(prim)
    translate_op = None
    for op in xformable.GetOrderedXformOps():
        if op.GetOpType() == UsdGeom.XformOp.TypeTranslate:
            translate_op = op
            break
    if translate_op is None:
        translate_op = xformable.AddTranslateOp(UsdGeom.XformOp.PrecisionDouble)
    translate_op.Set(Gf.Vec3d(float(local_value[0]), float(local_value[1]), float(local_value[2])))


def set_yaw_if_possible(prim, yaw_rad: float):
    xformable = UsdGeom.Xformable(prim)
    rotate_op = None
    for op in xformable.GetOrderedXformOps():
        if op.GetOpType() == UsdGeom.XformOp.TypeRotateXYZ:
            rotate_op = op
            break
    if rotate_op is None:
        try:
            rotate_op = xformable.AddRotateXYZOp()
        except Exception:
            return
    rotate_op.Set(Gf.Vec3f(0.0, 0.0, math.degrees(yaw_rad)))

def set_rigid_body_enabled_subtree(root_prim, enabled: bool):
    """Disable/enable rigid body simulation under a rack while keeping visual transform controllable."""
    try:
        for prim in Usd.PrimRange(root_prim):
            if not prim.IsValid():
                continue
            if prim.HasAPI(UsdPhysics.RigidBodyAPI):
                try:
                    api = UsdPhysics.RigidBodyAPI(prim)
                    api.CreateRigidBodyEnabledAttr(bool(enabled))
                    # While carrying, force kinematic behavior as an additional guard.
                    try:
                        api.CreateKinematicEnabledAttr(not bool(enabled))
                    except Exception:
                        pass
                except Exception:
                    pass
            # Zero velocities if the attributes exist. This reduces post-lift sliding.
            for attr_name, value in [
                ("physics:velocity", Gf.Vec3f(0.0, 0.0, 0.0)),
                ("physics:angularVelocity", Gf.Vec3f(0.0, 0.0, 0.0)),
            ]:
                attr = prim.GetAttribute(attr_name)
                if attr and attr.IsValid():
                    try:
                        attr.Set(value)
                    except Exception:
                        pass
    except Exception as e:
        print(f"RACK PHYSICS LOCK WARNING | {root_prim.GetPath()} enabled={enabled} err={e}")


def set_collision_enabled_subtree(root_prim, enabled: bool):
    """Temporarily disable rack collisions while it is carried to avoid physics separation/sliding."""
    try:
        for prim in Usd.PrimRange(root_prim):
            if not prim.IsValid():
                continue
            if prim.HasAPI(UsdPhysics.CollisionAPI):
                try:
                    UsdPhysics.CollisionAPI(prim).CreateCollisionEnabledAttr(bool(enabled))
                except Exception:
                    pass
    except Exception as e:
        print(f"RACK COLLISION LOCK WARNING | {root_prim.GetPath()} enabled={enabled} err={e}")


def hard_disable_physics_subtree(root_prim, disable_collision: bool = True):
    """Make an imported rack purely script-controlled.

    Imported racks can have RigidBodyAPI/CollisionAPI on nested mesh prims.
    If those remain active, PhysX may keep pulling the mesh downward even while
    the parent Xform is moved by script. This function disables/removes the
    physics APIs as much as the current editable layer allows.
    """
    try:
        for prim in Usd.PrimRange(root_prim):
            if not prim.IsValid():
                continue

            for attr_name, value in [
                ("physics:velocity", Gf.Vec3f(0.0, 0.0, 0.0)),
                ("physics:angularVelocity", Gf.Vec3f(0.0, 0.0, 0.0)),
            ]:
                attr = prim.GetAttribute(attr_name)
                if attr and attr.IsValid():
                    try:
                        attr.Set(value)
                    except Exception:
                        pass

            if prim.HasAPI(UsdPhysics.RigidBodyAPI):
                try:
                    rb = UsdPhysics.RigidBodyAPI(prim)
                    rb.CreateRigidBodyEnabledAttr(False)
                    try:
                        rb.CreateKinematicEnabledAttr(True)
                    except Exception:
                        pass
                except Exception:
                    pass
                try:
                    prim.RemoveAPI(UsdPhysics.RigidBodyAPI)
                except Exception:
                    pass

            if prim.HasAPI(UsdPhysics.MassAPI):
                try:
                    prim.RemoveAPI(UsdPhysics.MassAPI)
                except Exception:
                    pass

            if disable_collision and prim.HasAPI(UsdPhysics.CollisionAPI):
                try:
                    UsdPhysics.CollisionAPI(prim).CreateCollisionEnabledAttr(False)
                except Exception:
                    pass

            if disable_collision and prim.HasAPI(UsdPhysics.MeshCollisionAPI):
                try:
                    prim.RemoveAPI(UsdPhysics.MeshCollisionAPI)
                except Exception:
                    pass
    except Exception as e:
        print(f"HARD PHYSICS DISABLE WARNING | {root_prim.GetPath()} err={e}")


def set_world_translate_preserve_direct_child(prim, x: float, y: float, z: float):
    set_translate(prim, x, y, z)


def compute_visual_center_offset_xy(prim) -> Tuple[float, float]:
    """Return world-space XY offset from prim origin to rendered bbox center."""
    try:
        bbox_cache = UsdGeom.BBoxCache(
            Usd.TimeCode.Default(),
            [UsdGeom.Tokens.default_, UsdGeom.Tokens.render, UsdGeom.Tokens.proxy],
            useExtentsHint=True,
        )
        box = bbox_cache.ComputeWorldBound(prim).ComputeAlignedBox()
        center = box.GetMidpoint()
        origin = get_world_translation(prim)
        return float(center[0] - origin[0]), float(center[1] - origin[1])
    except Exception:
        return 0.0, 0.0


def get_object_center_xy(obj) -> Tuple[float, float]:
    """Return the controllable root origin used as the AMR/RACK center.

    Do NOT use BBox center here. In this user stage, bbox center can be far from
    the actual AMR/RACK root because imported assets contain nested offsets.
    Using the root origin makes the AMR root center align exactly with QR centers.
    """
    return get_xy(obj.prim)


def set_object_center_xy(obj, x: float, y: float, z: float):
    """Place the AMR/RACK root center exactly on the requested QR center."""
    set_translate(obj.prim, float(x), float(y), float(z))


def qr_cell_to_world(cell: GridCell) -> Tuple[float, float]:
    mapped = GLOBAL_QR_CELL_WORLD_MAP.get(cell)
    if mapped is not None:
        return mapped
    return cell[0] * GRID_SPACING, cell[1] * GRID_SPACING


def distance_xy(a: Tuple[float, float], b: Tuple[float, float]) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def cell_chebyshev_distance(a: GridCell, b: GridCell) -> int:
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))


def cell_manhattan_distance(a: GridCell, b: GridCell) -> int:
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def world_to_grid(x: float, y: float) -> GridCell:
    return int(round(x / GRID_SPACING)), int(round(y / GRID_SPACING))


def grid_to_world(cell: GridCell) -> Tuple[float, float]:
    mapped = GLOBAL_QR_CELL_WORLD_MAP.get(cell)
    if mapped is not None:
        return mapped
    return cell[0] * GRID_SPACING, cell[1] * GRID_SPACING


def normalize_move(dx: int, dy: int) -> Move:
    return (0 if dx == 0 else int(math.copysign(1, dx)), 0 if dy == 0 else int(math.copysign(1, dy)))


def is_diagonal_move(move: Move) -> bool:
    return abs(move[0]) == 1 and abs(move[1]) == 1


def is_cardinal_move(move: Move) -> bool:
    return (abs(move[0]) + abs(move[1])) == 1


def yaw_from_move(move: Move) -> Optional[float]:
    if move == (0, 0):
        return None
    # Desired WORLD direction of the robot visual front.
    return math.atan2(move[1], move[0])


def set_amr_yaw_to_movement(amr) -> bool:
    desired_front_yaw = yaw_from_move(amr.heading)
    if desired_front_yaw is None:
        return False

    # v12: apply requested visual heading offset.
    # Negative clockwise value means counterclockwise offset.
    desired_front_yaw = normalize_angle_rad(desired_front_yaw - AMR_VISUAL_HEADING_CLOCKWISE_OFFSET_RAD)

    current_root_yaw = get_root_yaw_rad(amr.obj.prim)
    current_front_yaw = get_amr_visual_front_yaw_rad(amr)

    if current_front_yaw is not None:
        # Dynamic visual correction:
        # rotate the root by exactly the angular error between the currently visible
        # front direction and the desired movement direction.
        delta = normalize_angle_rad(desired_front_yaw - current_front_yaw)
        root_yaw = normalize_angle_rad(current_root_yaw + delta)
    else:
        # Fallback to static calibrated offset.
        offset = getattr(amr, "front_yaw_offset_rad", AMR_FRONT_YAW_OFFSET_RAD)
        root_yaw = normalize_angle_rad(desired_front_yaw - offset)

    set_yaw_if_possible(amr.obj.prim, root_yaw)
    return True


# ============================================================
# Redis status publisher helpers
# ============================================================
def redis_encode_command(*parts: str) -> bytes:
    chunks = [f"*{len(parts)}\r\n".encode("utf-8")]
    for part in parts:
        data = str(part).encode("utf-8")
        chunks.append(f"${len(data)}\r\n".encode("utf-8"))
        chunks.append(data)
        chunks.append(b"\r\n")
    return b"".join(chunks)


class RedisStatusClient:
    def __init__(self, host: str, port: int, timeout: float, reconnect_period: float):
        self.host = host
        self.port = int(port)
        self.timeout = float(timeout)
        self.reconnect_period = float(reconnect_period)
        self.sock = None
        self.last_connect_try = 0.0
        self.last_error = ""
        self.connected_once = False

    def close(self):
        if self.sock is not None:
            try:
                self.sock.close()
            except Exception:
                pass
        self.sock = None

    def connect_if_needed(self) -> bool:
        if self.sock is not None:
            return True
        now = time.time()
        if now - self.last_connect_try < self.reconnect_period:
            return False
        self.last_connect_try = now
        try:
            s = socket.create_connection((self.host, self.port), timeout=self.timeout)
            s.settimeout(self.timeout)
            self.sock = s
            self.last_error = ""
            if not self.connected_once:
                print(f"REDIS STATUS CONNECTED | {self.host}:{self.port}")
                self.connected_once = True
            return True
        except Exception as e:
            self.last_error = str(e)
            self.close()
            return False

    def hset(self, key: str, mapping: Dict[str, str]) -> bool:
        if not mapping:
            return True
        if not self.connect_if_needed():
            return False
        parts = ["HSET", key]
        for k, v in mapping.items():
            parts.append(str(k))
            parts.append(str(v))
        try:
            self.sock.sendall(redis_encode_command(*parts))
            try:
                self.sock.recv(256)
            except socket.timeout:
                pass
            return True
        except Exception as e:
            self.last_error = str(e)
            self.close()
            return False


def cell_to_floor_qr_id_from_map(cell: Optional[GridCell], cell_world_map: Dict[GridCell, Tuple[float, float]]) -> str:
    if cell is None:
        return ""
    xy = cell_world_map.get(cell)
    if xy is None:
        # Fallback format. It is still a valid logical QR-style ID, but exact map coordinates are preferred.
        x, y = grid_to_world(cell)
    else:
        x, y = xy
    return f"FLOOR_X_{float(x):.3f}_Y_{float(y):.3f}"


# ============================================================
# QR camera localization helpers
# ============================================================
def normalize_qr_id(value: str) -> str:
    return str(value or "").strip().replace(" ", "").upper()


def find_descendant_camera(stage, root_path: str) -> Optional[str]:
    root = stage.GetPrimAtPath(root_path)
    if not root.IsValid():
        return None

    candidates = []
    try:
        for prim in Usd.PrimRange(root):
            if not prim.IsValid() or not prim.IsActive():
                continue
            if prim.GetTypeName() != "Camera":
                continue
            name = prim.GetName().lower()
            path = str(prim.GetPath())
            score = 0
            for kw in QR_CAMERA_NAME_KEYWORDS:
                if kw in name or kw in path.lower():
                    score += 1
            # Prefer explicitly downward/qr named cameras.
            if "downward" in name or "downward" in path.lower():
                score += 5
            if "qr" in name or "qr" in path.lower():
                score += 3
            candidates.append((score, path))
    except Exception as e:
        print(f"QR camera scan failed under {root_path}: {e}")
        return None

    if not candidates:
        return None

    candidates.sort(key=lambda x: (-x[0], x[1]))
    return candidates[0][1]


class QRCameraReader:
    def __init__(self, amr_name: str, camera_path: str):
        self.amr_name = amr_name
        self.camera_path = camera_path
        self.render_product = None
        self.annotator = None
        self.detector = cv2.QRCodeDetector() if CV2_AVAILABLE else None
        self.ready = False
        self.last_qr_id = ""
        self.last_error = ""
        self.scan_count = 0
        self.cuda_preprocess_enabled = False
        self.cuda_disabled_reason = ""
        self.setup()

    def setup(self):
        configure_opencv_runtime()
        if not CV2_AVAILABLE:
            self.last_error = f"cv2 unavailable: {_CV2_IMPORT_ERROR}"
            return
        if not REPLICATOR_AVAILABLE:
            self.last_error = f"omni.replicator.core unavailable: {_REPLICATOR_IMPORT_ERROR}"
            return
        try:
            self.cuda_preprocess_enabled = opencv_cuda_available()
            self.cuda_disabled_reason = _OPENCV_CUDA_STATUS
            self.render_product = rep.create.render_product(self.camera_path, QR_CAMERA_RESOLUTION)
            self.annotator = rep.AnnotatorRegistry.get_annotator("rgb")
            self.annotator.attach([self.render_product])
            self.ready = True
            backend = "opencv_cuda_rgb2bgr" if self.cuda_preprocess_enabled else f"opencv_cpu_rgb2bgr({_OPENCV_CUDA_STATUS})"
            print(f"QR CAMERA READY | {self.amr_name} camera={self.camera_path} res={QR_CAMERA_RESOLUTION} preprocess={backend} cv_threads={AMR_OPENCV_CPU_THREADS}")
        except Exception as e:
            self.last_error = str(e)
            print(f"QR CAMERA SETUP FAILED | {self.amr_name} camera={self.camera_path} err={e}")

    def get_rgb_array(self):
        if not self.ready or self.annotator is None:
            return None
        try:
            data = self.annotator.get_data()
            if data is None:
                return None
            if isinstance(data, dict):
                data = data.get("data", None)
            if data is None:
                return None
            arr = np.asarray(data)
            if arr.size == 0:
                return None
            if arr.ndim == 3 and arr.shape[2] == 4:
                arr = arr[:, :, :3]
            if arr.dtype != np.uint8:
                arr = arr.astype(np.uint8, copy=False)
            if not arr.flags.c_contiguous:
                arr = np.ascontiguousarray(arr)
            return arr
        except Exception as e:
            self.last_error = str(e)
            return None

    def rgb_to_bgr_for_qr(self, frame):
        # QRCodeDetector is still the same detector. Only RGB->BGR conversion is moved
        # to cv2.cuda when the local OpenCV build supports CUDA.
        if self.cuda_preprocess_enabled:
            try:
                gpu_frame = cv2.cuda_GpuMat()
                gpu_frame.upload(frame)
                gpu_bgr = cv2.cuda.cvtColor(gpu_frame, cv2.COLOR_RGB2BGR)
                return gpu_bgr.download(), "CUDA"
            except Exception as e:
                self.cuda_preprocess_enabled = False
                self.cuda_disabled_reason = f"cuda_runtime_failed:{e}"
                self.last_error = self.cuda_disabled_reason
                print(f"QR CUDA PREPROCESS DISABLED | {self.amr_name} reason={self.cuda_disabled_reason}")

        return cv2.cvtColor(frame, cv2.COLOR_RGB2BGR), "CPU"

    def decode(self) -> Optional[str]:
        self.scan_count += 1
        if QR_DETECTOR_EVERY_N_SCANS > 1 and self.scan_count % QR_DETECTOR_EVERY_N_SCANS != 0:
            return self.last_qr_id or None

        frame = self.get_rgb_array()
        if frame is None:
            return None

        try:
            bgr, _backend = self.rgb_to_bgr_for_qr(frame)

            decoded = ""
            if hasattr(self.detector, "detectAndDecodeMulti"):
                ok, decoded_info, points, _ = self.detector.detectAndDecodeMulti(bgr)
                if ok and decoded_info:
                    decoded = next((s for s in decoded_info if str(s).strip()), "")

            if not decoded:
                decoded, points, _ = self.detector.detectAndDecode(bgr)

            decoded = normalize_qr_id(decoded)
            if decoded:
                self.last_qr_id = decoded
                return decoded
            return None
        except Exception as e:
            self.last_error = str(e)
            return None


# ============================================================
# Planner data structures
# ============================================================
@dataclass
class PlanRequest:
    robot_id: str
    start: GridCell
    goal: GridCell
    heading: Move = (1, 0)
    carrying_rack: bool = False
    priority: int = 0
    waiting_steps: int = 0
    allowed_goal_occupied: bool = False
    # v42 cost-aware global reroute:
    # The normal planner may choose a one-tick WAIT or a first step that the
    # global arbiter later rejects. A second-chance route can forbid only that
    # first step and/or the first WAIT, forcing A* to compare an immediate detour.
    allow_wait_first_step: bool = True
    avoid_first_cells: Set[GridCell] = field(default_factory=set)


@dataclass
class PlanResult:
    robot_id: str
    path: List[GridCell]
    timed_path: List[TimedCell]
    success: bool
    reason: str = ""


class ReservationTable:
    def __init__(self):
        self.reserved_cell: Dict[TimedCell, str] = {}
        self.reserved_edge: Dict[EdgeKey, str] = {}
        self.soft_reserved_cell: Dict[TimedCell, str] = {}

    def clear(self):
        self.reserved_cell.clear()
        self.reserved_edge.clear()
        self.soft_reserved_cell.clear()

    def reserve_cell(self, cell: GridCell, t: int, robot_id: str):
        self.reserved_cell[(cell[0], cell[1], t)] = robot_id

    def reserve_edge(self, from_cell: GridCell, to_cell: GridCell, t: int, robot_id: str):
        self.reserved_edge[(from_cell[0], from_cell[1], to_cell[0], to_cell[1], t)] = robot_id

    def reserve_soft_cell(self, cell: GridCell, t: int, robot_id: str):
        self.soft_reserved_cell[(cell[0], cell[1], t)] = robot_id

    def is_cell_reserved(self, cell: GridCell, t: int, robot_id: str) -> bool:
        owner = self.reserved_cell.get((cell[0], cell[1], t))
        return owner is not None and owner != robot_id

    def is_soft_reserved(self, cell: GridCell, t: int, robot_id: str) -> bool:
        owner = self.soft_reserved_cell.get((cell[0], cell[1], t))
        return owner is not None and owner != robot_id

    def is_soft_cell_reserved(self, cell: GridCell, t: int, robot_id: str) -> bool:
        return self.is_soft_reserved(cell, t, robot_id)

    def is_edge_swap(self, from_cell: GridCell, to_cell: GridCell, t: int, robot_id: str) -> bool:
        owner = self.reserved_edge.get((to_cell[0], to_cell[1], from_cell[0], from_cell[1], t))
        return owner is not None and owner != robot_id

    def reserve_path(self, robot_id: str, timed_path: List[TimedCell], carrying_rack: bool, heading_path: List[Move]):
        if not timed_path:
            return
        horizon = timed_path[:RESERVATION_HORIZON]
        for i, node in enumerate(horizon):
            x, y, t = node
            cell = (x, y)
            self.reserve_cell(cell, t, robot_id)
            if carrying_rack:
                heading = heading_path[i] if i < len(heading_path) else (0, 0)
                for c in self._rack_soft_cells(cell, heading):
                    self.reserve_soft_cell(c, t, robot_id)
            if i > 0:
                px, py, pt = horizon[i - 1]
                self.reserve_edge((px, py), cell, pt, robot_id)
        gx, gy, gt = timed_path[-1]
        for dt in range(GOAL_HOLD_STEPS):
            self.reserve_cell((gx, gy), gt + dt, robot_id)

    def _rack_soft_cells(self, cell: GridCell, heading: Move) -> List[GridCell]:
        x, y = cell
        # v41: do NOT soft-reserve the surrounding 8 cells.
        # The surrounding 3x3 area is a four-way-only movement zone, not an
        # obstacle/reservation zone.  Keep only the physical cardinal footprint
        # around a carried workstation as a soft reservation.
        return [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]


class TimeAStar8:
    def __init__(self):
        self.moves8: List[Move] = [
            (1, 0), (-1, 0), (0, 1), (0, -1),
            (1, 1), (1, -1), (-1, 1), (-1, -1),
            (0, 0),
        ]
        self.moves4: List[Move] = [(1, 0), (-1, 0), (0, 1), (0, -1), (0, 0)]

    def plan(self, req: PlanRequest, reservation: ReservationTable, static_obstacles: Set[GridCell], start_time: int) -> PlanResult:
        if req.start == req.goal:
            return PlanResult(req.robot_id, [req.start], [(req.start[0], req.start[1], start_time)], True, "already_at_goal")

        open_heap = []
        came_from: Dict[Tuple[int, int, int, int, int], Tuple[int, int, int, int, int]] = {}
        g_score: Dict[Tuple[int, int, int, int, int], float] = {}

        sx, sy = req.start
        hx, hy = req.heading
        start_node = (sx, sy, start_time, hx, hy)
        g_score[start_node] = 0.0
        heappush(open_heap, (self.heuristic(req.start, req.goal), 0.0, start_node))

        while open_heap:
            _, current_g, current = heappop(open_heap)
            x, y, t, chx, chy = current
            current_cell = (x, y)

            if current_cell == req.goal:
                path, timed, _ = self.reconstruct(came_from, current)
                return PlanResult(req.robot_id, path, timed, True, "success")

            if t - start_time >= MAX_TIME_HORIZON:
                continue

            for move in self.neighbors(req.carrying_rack):
                dx, dy = move
                nx, ny = x + dx, y + dy
                nt = t + 1
                next_cell = (nx, ny)

                # v42 cost-aware global reroute:
                # During a second-chance replan, forbid only the first WAIT or
                # the first cell that was just rejected by the global arbiter.
                # Later ticks may still wait if the detour itself requires it.
                if t == start_time:
                    if move == (0, 0) and not getattr(req, "allow_wait_first_step", True):
                        continue
                    if next_cell in getattr(req, "avoid_first_cells", set()):
                        continue

                if not self.valid_cell(next_cell, req.goal, req.allowed_goal_occupied, static_obstacles):
                    continue
                if not self.transition_safe(req.robot_id, current_cell, next_cell, t, nt, move, req, reservation, static_obstacles):
                    continue

                nhx, nhy = (chx, chy) if move == (0, 0) else move
                next_node = (nx, ny, nt, nhx, nhy)
                step_cost = self.step_cost((chx, chy), move, current_cell, next_cell, req.goal, nt, req.carrying_rack, reservation, req.robot_id, req.waiting_steps)
                # Balanced Mode-C policy:
                #   - immediate next-cell safety remains a hard condition in transition_safe()
                #   - the second cell is not a hard blocker, but it adds cost so A* prefers
                #     smoother paths that do not immediately run into an obstacle/dead-end.
                step_cost += self.second_step_soft_penalty(next_cell, move, nt, req, reservation, static_obstacles)
                tentative_g = current_g + step_cost

                if tentative_g < g_score.get(next_node, float("inf")):
                    came_from[next_node] = current
                    g_score[next_node] = tentative_g
                    f = tentative_g + self.heuristic(next_cell, req.goal)
                    heappush(open_heap, (f, tentative_g, next_node))

        return PlanResult(req.robot_id, [], [], False, "no_path")

    def neighbors(self, carrying_rack: bool) -> List[Move]:
        # Previous improved policy: normal AMR true 8-way, rack-carrying AMR 4-way only.
        return self.moves4 if carrying_rack else self.moves8

    def valid_cell(self, cell: GridCell, goal: GridCell, allowed_goal_occupied: bool, static_obstacles: Set[GridCell]) -> bool:
        # QR-only navigation: the planner may step only on cells that have an actual QR marker.
        # The goal is also snapped to a QR cell before planning, so no non-QR goal exception is needed.
        if QR_ONLY_NAVIGATION and GLOBAL_VALID_QR_CELLS and cell not in GLOBAL_VALID_QR_CELLS:
            return False
        if cell in static_obstacles and not (allowed_goal_occupied and cell == goal):
            return False
        return True

    def transition_safe(self, robot_id: str, from_cell: GridCell, to_cell: GridCell, t: int, nt: int, move: Move, req: PlanRequest, reservation: ReservationTable, static_obstacles: Set[GridCell]) -> bool:
        if reservation.is_cell_reserved(to_cell, nt, robot_id):
            return False
        if reservation.is_edge_swap(from_cell, to_cell, t, robot_id):
            return False
        if self.is_diagonal(move):
            # Rack/workstation leg constraint.
            # If the AMR is entering, leaving, crossing, or moving adjacent to a rack zone,
            # diagonal motion is forbidden when it is carrying a workstation.
            #
            # Pickup approach fix:
            # A non-carrying AMR may normally move 8-way and pass under stationary racks,
            # but when it is moving to a rack pickup goal, the final approach must be
            # cardinal. Otherwise the AMR can cut diagonally into a liftable cell and start
            # lifting from an unrealistic diagonal pose.
            c1 = (from_cell[0] + move[0], from_cell[1])
            c2 = (from_cell[0], from_cell[1] + move[1])

            if req.allowed_goal_occupied:
                if to_cell == req.goal or cell_chebyshev_distance(to_cell, req.goal) <= 1:
                    return False
                if RACK_FOUR_WAY_ZONE_ENABLED and GLOBAL_RACK_FOUR_WAY_CELLS:
                    if (
                        from_cell in GLOBAL_RACK_FOUR_WAY_CELLS
                        or to_cell in GLOBAL_RACK_FOUR_WAY_CELLS
                        or c1 in GLOBAL_RACK_FOUR_WAY_CELLS
                        or c2 in GLOBAL_RACK_FOUR_WAY_CELLS
                    ):
                        return False

            if req.carrying_rack and RACK_FOUR_WAY_ZONE_ENABLED and GLOBAL_RACK_FOUR_WAY_CELLS:
                if (
                    from_cell in GLOBAL_RACK_FOUR_WAY_CELLS
                    or to_cell in GLOBAL_RACK_FOUR_WAY_CELLS
                    or c1 in GLOBAL_RACK_FOUR_WAY_CELLS
                    or c2 in GLOBAL_RACK_FOUR_WAY_CELLS
                ):
                    return False

            # Corner cutting prevention.
            if (c1 in static_obstacles) or (c2 in static_obstacles):
                return False
            if reservation.is_cell_reserved(c1, nt, robot_id) or reservation.is_cell_reserved(c2, nt, robot_id):
                return False
        if req.carrying_rack:
            # Carrying rack footprint policy.
            # A* checks only the candidate next-cell footprint. The second planned cell is
            # checked later by the global move arbiter (Mode C two-step approval), so A*
            # does not become too conservative and produce unnecessary no_path failures.
            # At the final goal, do not require extra lookahead/side cells beyond the
            # destination. The goal cell itself is still validated by valid_cell().
            # Footprint cells check physical conflicts such as stationary racks and AMR
            # reservations. They do not require QR markers, because QR cells represent
            # AMR center navigation points rather than the entire rack body footprint.
            for c in self.rack_occupied_cells(to_cell, move, req.goal):
                if c == to_cell:
                    if not self.valid_cell(c, req.goal, req.allowed_goal_occupied, static_obstacles):
                        return False
                else:
                    if c in static_obstacles:
                        return False
                if reservation.is_cell_reserved(c, nt, robot_id):
                    return False
        return True

    def rack_occupied_cells(self, center: GridCell, move: Move, goal: Optional[GridCell] = None) -> List[GridCell]:
        x, y = center
        if goal is not None and center == goal:
            # SG A/B placement cells are intentionally adjacent.  Enforcing an
            # 8-cell exclusion at the final goal would make B placement impossible.
            return [(x, y)]

        if RACK_DYNAMIC_SAFETY_ZONE_ENABLED and RACK_DYNAMIC_SAFETY_INCLUDE_DIAGONALS:
            r = max(0, int(RACK_DYNAMIC_SAFETY_RADIUS_CELLS))
            cells = [(x + dx, y + dy) for dx in range(-r, r + 1) for dy in range(-r, r + 1)]
        else:
            cells = [
                (x, y),
                (x + 1, y),
                (x - 1, y),
                (x, y + 1),
                (x, y - 1),
            ]

        deduped: List[GridCell] = []
        seen: Set[GridCell] = set()
        for c in cells:
            if c not in seen:
                seen.add(c)
                deduped.append(c)
        return deduped

    def step_cost(self, heading: Move, move: Move, current_cell: GridCell, next_cell: GridCell, goal: GridCell, nt: int, carrying_rack: bool, reservation: ReservationTable, robot_id: str, waiting_steps: int = 0) -> float:
        """Cost model tuned for dense AMR convoy behavior.

        V22 intent:
        - A 90-degree turn should be cheap, so the planner chooses a short right/left
          turn instead of a long detour.
        - A U-turn / backward move should be much more expensive than waiting or
          turning. This prevents a follower AMR from suddenly reversing when the
          leader or a temporary reservation blocks the forward cell.
        - Moving farther away from the task goal is allowed but penalized. This keeps
          unavoidable detours possible while strongly preferring forward/right-turn
          progress.
        """
        if move == (0, 0):
            cost = WAIT_COST_CARRY if carrying_rack else WAIT_COST_EMPTY
            if CONGESTION_AGING_ENABLED and waiting_steps > 0:
                if carrying_rack:
                    cost += min(waiting_steps * CONGESTION_WAIT_COST_STEP_CARRY, CONGESTION_WAIT_COST_CAP_CARRY)
                else:
                    cost += min(waiting_steps * CONGESTION_WAIT_COST_STEP_EMPTY, CONGESTION_WAIT_COST_CAP_EMPTY)
        elif self.is_diagonal(move):
            cost = 1.414
        else:
            cost = 1.0

        if move != (0, 0) and heading != (0, 0):
            dot = heading[0] * move[0] + heading[1] * move[1]
            if move == heading:
                cost = max(0.01, cost - KEEP_HEADING_SMALL_BONUS)
            elif dot < 0:
                cost += TURN_COST_CARRY_180 if carrying_rack else TURN_COST_EMPTY_180
                cost += REVERSE_MOVE_EXTRA_COST_CARRY if carrying_rack else REVERSE_MOVE_EXTRA_COST_EMPTY
            else:
                cost += TURN_COST_CARRY_90 if carrying_rack else TURN_COST_EMPTY_90

            # v11: after the AMR has actually waited in congestion, make a 90-degree
            # turn/yield cheaper than another straight step. This is intentionally
            # conditional, so normal open-road driving does not zigzag.
            if BOTTLENECK_TURN_FIRST_ENABLED and waiting_steps >= BOTTLENECK_TURN_FIRST_WAIT_THRESHOLD:
                if dot == 0:
                    bonus = BOTTLENECK_TURN_BONUS_CARRY if carrying_rack else BOTTLENECK_TURN_BONUS_EMPTY
                    cost = max(0.05, cost - bonus)
                elif move == heading:
                    cost += BOTTLENECK_STRAIGHT_EXTRA_CARRY if carrying_rack else BOTTLENECK_STRAIGHT_EXTRA_EMPTY

        # Penalize moves that increase distance to the task goal.  This is the
        # core fix for the observed behavior where a trailing AMR waits and then
        # reverses, even though a short right turn would reach the goal faster.
        if move != (0, 0):
            h_now = self.heuristic(current_cell, goal)
            h_next = self.heuristic(next_cell, goal)
            if h_next > h_now + 1e-9:
                regression = h_next - h_now
                cost += regression * (GOAL_REGRESSION_COST_CARRY if carrying_rack else GOAL_REGRESSION_COST_EMPTY)

        if reservation.is_soft_reserved(next_cell, nt, robot_id):
            cost += 0.20
        return cost

    def second_step_soft_penalty(self, next_cell: GridCell, move: Move, nt: int, req: PlanRequest, reservation: ReservationTable, static_obstacles: Set[GridCell]) -> float:
        """Return a non-blocking cost penalty for the cell after next_cell.

        This keeps the 2-step lookahead useful without freezing the AMR when the
        immediate next cell is safe. The second cell is treated as a risk signal,
        not as a hard safety veto. A* will prefer safer 2-step candidates when they
        exist, but it can still advance one safe cell and replan on the next tick.
        """
        # V21: do not let 2-step lookahead distort the actual route.
        # The second cell remains available as a soft risk probe in the arbiter/logs,
        # but A* cost should primarily follow shortest/turn-minimal paths.
        # This prevents the regression where a simple 90-degree turn path is avoided
        # because a future cell adds artificial penalty.
        if True:
            return 0.0

        if move == (0, 0) or next_cell == req.goal:
            return 0.0

        second = (next_cell[0] + move[0], next_cell[1] + move[1])
        t2 = nt + 1
        penalty = 0.0

        if req.carrying_rack:
            # Carrying AMR: evaluate the same 4-neighbor rack footprint, but as a
            # soft preference only. Center cell QR validity matters for future AMR
            # center navigation; side cells are physical clearance cells.
            for c in self.rack_occupied_cells(second, move, req.goal):
                if c == second:
                    if QR_ONLY_NAVIGATION and GLOBAL_VALID_QR_CELLS and c not in GLOBAL_VALID_QR_CELLS:
                        penalty += 0.45
                    if c in static_obstacles and c != req.goal:
                        penalty += 0.45
                else:
                    if c in static_obstacles:
                        penalty += 0.30
                if reservation.is_cell_reserved(c, t2, req.robot_id):
                    penalty += 0.55
        else:
            # Empty AMR: do not treat stationary racks as obstacles. Keep only AMR
            # center navigation and active reservation risks as soft cost.
            if QR_ONLY_NAVIGATION and GLOBAL_VALID_QR_CELLS and second not in GLOBAL_VALID_QR_CELLS:
                penalty += 0.25
            if second in static_obstacles:
                penalty += 0.25
            if reservation.is_cell_reserved(second, t2, req.robot_id):
                penalty += 0.55

        return penalty

    def heuristic(self, cell: GridCell, goal: GridCell) -> float:
        dx = abs(cell[0] - goal[0])
        dy = abs(cell[1] - goal[1])
        # Octile distance for 8-way grid.
        return (max(dx, dy) - min(dx, dy)) + 1.414 * min(dx, dy)

    def is_diagonal(self, move: Move) -> bool:
        return abs(move[0]) == 1 and abs(move[1]) == 1

    def reconstruct(self, came_from, current):
        nodes = [current]
        while current in came_from:
            current = came_from[current]
            nodes.append(current)
        nodes.reverse()
        path = [(n[0], n[1]) for n in nodes]
        timed = [(n[0], n[1], n[2]) for n in nodes]
        headings = [(n[3], n[4]) for n in nodes]
        return path, timed, headings


# ============================================================
# Simulation state
# ============================================================
@dataclass
class SimObject:
    name: str
    path: str
    prim: object
    base_z: float


@dataclass
class RackState:
    key: str
    obj: SimObject
    cell: GridCell
    carried_by: Optional[str] = None
    assigned: bool = False
    physics_locked: bool = False


@dataclass
class CommandTask:
    command_id: str
    workstation_id: str
    rack_key: str
    target_location: str
    target_xy: Tuple[float, float]
    target_cell: GridCell
    target_yaw: float = 0.0
    action_mode: str = "MOVE_WORKSTATION"
    rotate_start_yaw: float = 0.0
    rotate_target_yaw: float = 0.0
    amr_name: Optional[str] = None
    preferred_amr_name: Optional[str] = None
    require_preferred_amr: bool = False
    rack_attach_dx: float = 0.0
    rack_attach_dy: float = 0.0
    phase: str = "PENDING"
    phase_start: float = 0.0
    last_status_at: float = 0.0
    created_at: float = field(default_factory=time.time)
    # Cell where the AMR was located when this task was assigned.
    # After dropping the workstation, the AMR returns here before the command result is published.
    return_cell: Optional[GridCell] = None
    return_xy: Optional[Tuple[float, float]] = None
    # Internal clearance tasks are generated by the controller to move a workstation
    # that is blocking an SG2 inner A lane. They must not create bridge result files,
    # otherwise the batch test script would count them as user commands.
    internal: bool = False
    parent_command_id: Optional[str] = None
    clearance_reason: str = ""
    # v13: if an internal lane-clearance task preempts an external RETURN_HOME task,
    # this stores the external command id so it can be completed after clearance return-home.
    resume_task_id: Optional[str] = None
    # v17: post-place choreography for SG A/B targets.
    # A: place -> side-exit -> return home.
    # B: place -> AMR 180-degree heading turn -> back-exit -> return home.
    post_place_behavior: str = "AUTO"
    post_place_exit_cell: Optional[GridCell] = None
    post_place_exit_xy: Optional[Tuple[float, float]] = None
    post_place_turn_start_heading: Move = (0, 0)
    post_place_turn_target_heading: Move = (0, 0)
    # v18/v20/v21/v22/v23: optional wait and approach cells used before final SG B entry.
    # safe wait: B waits here while same-lane A has not reached placing.
    # pre-approach: B may advance here while A is placing, before full clear.
    # approach: B may advance here after A starts side-exit/return choreography.
    pre_target_wait_cell: Optional[GridCell] = None
    pre_target_wait_xy: Optional[Tuple[float, float]] = None
    pre_target_pre_approach_cell: Optional[GridCell] = None
    pre_target_pre_approach_xy: Optional[Tuple[float, float]] = None
    pre_target_approach_cell: Optional[GridCell] = None
    pre_target_approach_xy: Optional[Tuple[float, float]] = None
    pre_target_wait_required: bool = False
    pre_target_partial_released: bool = False
    pre_target_approach_released: bool = False
    pre_target_released: bool = False
    # v24: semantic stage labels for B-side staged entry.  The physical AMR state
    # remains TO_PRE_TARGET_WAIT for planner compatibility, but this field makes
    # logs/status readable and separates ENTRY / FINAL_READY / FINAL decisions.
    pre_target_stage: str = "NONE"
    # v24: explicit completion split.  DELIVERY_DONE is set when the workstation
    # is placed at the requested target.  TASK_DONE is set only after the AMR
    # completes post-place choreography and returns home.
    delivery_done: bool = False
    delivery_done_at: float = 0.0
    task_done: bool = False
    task_done_at: float = 0.0
    # v27: deterministic local macro route inside SG A/B bays.
    # local_entry_route includes the final slot as its last element.
    # local_exit_route is normally the reverse route, with the current final slot
    # removed when the AMR starts exiting after placement.
    local_entry_route: List[GridCell] = field(default_factory=list)
    local_entry_index: int = 0
    local_entry_label: str = ""
    local_exit_route: List[GridCell] = field(default_factory=list)
    local_exit_index: int = 0
    local_route_mode: str = ""


@dataclass
class AmrState:
    name: str
    obj: SimObject
    cell: GridCell
    heading: Move = (1, 0)
    state: str = "IDLE"
    target_cell: Optional[GridCell] = None
    target_xy: Optional[Tuple[float, float]] = None
    task_id: Optional[str] = None
    carrying_rack: Optional[str] = None
    move_from: Optional[GridCell] = None
    move_to: Optional[GridCell] = None
    move_elapsed: float = 0.0
    wait_steps: int = 0
    no_path_steps: int = 0
    current_qr_id: str = ""
    localization_source: str = "TRANSFORM"
    qr_candidate_id: str = ""
    qr_candidate_cell: Optional[GridCell] = None
    qr_candidate_count: int = 0
    qr_last_rejected_id: str = ""
    qr_last_rejected_reason: str = ""
    camera_path: Optional[str] = None
    qr_reader: Optional[QRCameraReader] = None
    last_qr_log_at: float = 0.0
    front_reference_path: str = ""
    front_yaw_offset_rad: float = AMR_FRONT_YAW_OFFSET_RAD

    def is_moving(self) -> bool:
        return self.move_from is not None and self.move_to is not None


# ============================================================
# Main controller
# ============================================================
class ExistingStageTrue8Controller:
    def __init__(self):
        ensure_dirs()
        self.stage = get_stage()
        if self.stage is None:
            raise RuntimeError("No active USD stage. Open your Nucleus Live stage first.")

        self.amrs: Dict[str, AmrState] = {}
        self.racks: Dict[str, RackState] = {}
        self.qr_prim_map: Dict[str, Tuple[GridCell, Tuple[float, float], str]] = {}
        self.valid_qr_cells: Set[GridCell] = set()
        self.qr_cell_world_map: Dict[GridCell, Tuple[float, float]] = {}
        self.rack_four_way_cells: Set[GridCell] = set()
        self.tasks: Dict[str, CommandTask] = {}
        self.processed_commands: Set[str] = set()
        self.controller_start_time = time.time()
        self.planner = TimeAStar8()
        self.reservation = ReservationTable()
        self.tick = 0
        self.redis_client = RedisStatusClient(REDIS_HOST, REDIS_PORT, REDIS_CONNECT_TIMEOUT_SEC, REDIS_RECONNECT_PERIOD_SEC) if REDIS_STATUS_ENABLED else None
        self.last_redis_publish_at = 0.0
        self.last_redis_log_at = 0.0
        self.last_decision_at = 0.0
        self.last_command_scan_at = 0.0
        self.last_qr_scan_at = 0.0
        self.qr_round_robin_index = 0
        self.last_log_at = 0.0
        self.redis_last_payloads: Dict[str, Dict[str, str]] = {}
        self.collision_counts = {
            "CELL": 0,
            "EDGE_SWAP": 0,
            "DIAGONAL_CROSS": 0,
            "FOOTPRINT": 0,
            "SWEPT_FOOTPRINT": 0,
        }

        self.build_qr_prim_map()
        self.load_stage_objects()
        self.build_rack_four_way_zones()
        self.setup_amr_qr_readers()
        self.assign_initial_random_goals()

        self._subscription = omni.kit.app.get_app().get_update_event_stream().create_subscription_to_pop(
            self.on_update,
            name="existing_stage_true8_amr_controller",
        )

        print("\nExistingStageTrue8Controller V41-TRUE-SPOTS-DYNAMIC-RACK-FOURWAY-ZONE started")
        print(f"OpenCV CUDA status: {_OPENCV_CUDA_STATUS}; GPU enabled={AMR_GPU_ENABLED}; QR GPU preprocess={AMR_QR_GPU_PREPROCESS_ENABLED}")
        print(f"AMRs loaded: {list(self.amrs.keys())}")
        print(f"Racks loaded: {list(self.racks.keys())}")
        print(f"Bridge queue: {BRIDGE_QUEUE_DIR}")
        print("Press Play. Control Tower commands will move existing /World AMR/RACK prims. V19: optimized QR camera 320x240 + round-robin decode + Redis 5Hz + V18 compatibility.\n")
        if REDIS_STATUS_ENABLED:
            print(f"REDIS STATUS TARGET | {REDIS_HOST}:{REDIS_PORT} key_prefix={REDIS_KEY_PREFIX} period={REDIS_PUBLISH_PERIOD_SEC}s")

    def build_qr_prim_map(self):
        global GLOBAL_VALID_QR_CELLS, GLOBAL_QR_CELL_WORLD_MAP
        self.qr_prim_map.clear()
        self.valid_qr_cells.clear()
        self.qr_cell_world_map.clear()

        floor_pattern = re.compile(r"FLOOR[_\-]?X[_\-]?(-?\d+(?:\.\d+)?)[_\-]?Y[_\-]?(-?\d+(?:\.\d+)?)", re.IGNORECASE)

        for prim in self.stage.Traverse():
            if not prim.IsValid() or not prim.IsActive():
                continue
            path = str(prim.GetPath())
            name = prim.GetName()
            key_src = f"{name} {path}"
            low = key_src.lower()

            is_marker_candidate = (
                "qr" in low
                or "aruco" in low
                or "marker" in low
                or "floor_x" in low
                or "floor-x" in low
                or bool(floor_pattern.search(key_src))
            )
            if not is_marker_candidate:
                continue

            try:
                xy = get_xy(prim)
            except Exception:
                continue

            # If the QR ID encodes the true floor coordinate, prefer that over prim transform.
            encoded_xy = None
            m = floor_pattern.search(key_src)
            if m:
                try:
                    encoded_xy = (float(m.group(1)), float(m.group(2)))
                except Exception:
                    encoded_xy = None

            source_xy = encoded_xy if encoded_xy is not None else xy
            cell = world_to_grid(*source_xy)
            self.valid_qr_cells.add(cell)
            self.qr_cell_world_map.setdefault(cell, (float(source_xy[0]), float(source_xy[1])))

            candidates = {
                normalize_qr_id(name),
                normalize_qr_id(path.split("/")[-1]),
                normalize_qr_id(path),
            }
            if encoded_xy is not None:
                candidates.add(normalize_qr_id(f"FLOOR_X_{encoded_xy[0]}_Y_{encoded_xy[1]}"))
                candidates.add(normalize_qr_id(f"FLOOR_X_{encoded_xy[0]:.3f}_Y_{encoded_xy[1]:.3f}"))

            for c in list(candidates):
                if c:
                    self.qr_prim_map[c] = (cell, source_xy, path)

        GLOBAL_VALID_QR_CELLS = set(self.valid_qr_cells)
        GLOBAL_QR_CELL_WORLD_MAP = dict(self.qr_cell_world_map)
        print(f"QR MAP LOADED V19 | ids={len(self.qr_prim_map)} valid_qr_cells={len(self.valid_qr_cells)} exact_centers={len(self.qr_cell_world_map)}")
        if QR_ONLY_NAVIGATION and not self.valid_qr_cells:
            print("QR MAP WARNING | QR_ONLY_NAVIGATION is enabled but no QR cells were loaded. Planner will fall back to unrestricted grid.")
        if not CV2_AVAILABLE:
            print(f"QR CAMERA WARNING | cv2 unavailable: {_CV2_IMPORT_ERROR}")
        if not REPLICATOR_AVAILABLE:
            print(f"QR CAMERA WARNING | replicator unavailable: {_REPLICATOR_IMPORT_ERROR}")

    def setup_amr_qr_readers(self):
        if not QR_CAMERA_LOCALIZATION_ENABLED:
            print("QR CAMERA LOCALIZATION DISABLED")
            return
        for amr in self.amrs.values():
            camera_path = find_descendant_camera(self.stage, amr.obj.path)
            amr.camera_path = camera_path
            if camera_path:
                amr.qr_reader = QRCameraReader(amr.name, camera_path)
            else:
                print(f"QR CAMERA NOT FOUND | {amr.name} under={amr.obj.path}")

    def parse_qr_cell_from_text(self, qr_id: str) -> Optional[GridCell]:
        q = normalize_qr_id(qr_id)
        if not q:
            return None
        if q in self.qr_prim_map:
            return self.qr_prim_map[q][0]

        # Current floor QR payload pattern: FLOOR_X_4.225_Y_14.475
        m = re.search(r"FLOOR[_\-]?X[_\-]?(-?\d+(?:\.\d+)?)[_\-]?Y[_\-]?(-?\d+(?:\.\d+)?)", q, re.IGNORECASE)
        if m:
            xy = (float(m.group(1)), float(m.group(2)))
            cell = world_to_grid(*xy)
            # Register newly observed QR cell as valid if the stage map missed it.
            self.valid_qr_cells.add(cell)
            self.qr_cell_world_map.setdefault(cell, (float(xy[0]), float(xy[1])))
            GLOBAL_VALID_QR_CELLS.add(cell)
            GLOBAL_QR_CELL_WORLD_MAP.setdefault(cell, (float(xy[0]), float(xy[1])))
            return cell

        # Common integer grid patterns: QR_12_08, QR_X12_Y08, QR_0012_0008.
        m = re.search(r"(?:X)?(-?\d+)[_\-:, ]+(?:Y)?(-?\d+)", q)
        if m:
            cell = (int(m.group(1)), int(m.group(2)))
            if not QR_ONLY_NAVIGATION or not self.valid_qr_cells or cell in self.valid_qr_cells:
                return cell
            return self.nearest_qr_cell_to_world(*grid_to_world(cell))

        # If IDs are sequential QR_0000~QR_9999, interpret as row-major only if no QR map is available.
        m = re.search(r"(\d+)$", q)
        if m and not self.qr_prim_map:
            idx = int(m.group(1))
            grid_w = 40
            return idx % grid_w, idx // grid_w

        return None

    def nearest_qr_cell_to_world(self, x: float, y: float) -> GridCell:
        if not self.valid_qr_cells:
            return world_to_grid(x, y)
        best_cell = None
        best_d = float("inf")
        for cell in self.valid_qr_cells:
            wx, wy = grid_to_world(cell)
            d = (wx - x) ** 2 + (wy - y) ** 2
            if d < best_d:
                best_d = d
                best_cell = cell
        return best_cell if best_cell is not None else world_to_grid(x, y)

    def snap_xy_to_nearest_qr(self, x: float, y: float) -> Tuple[float, float, GridCell]:
        cell = self.nearest_qr_cell_to_world(x, y)
        wx, wy = grid_to_world(cell)
        return wx, wy, cell

    def explicit_drop_target_locked(self, target_location: str, rack_key: str, target_cell: GridCell) -> bool:
        """Return True when the command explicitly requested an SG2 A/B cell.

        This prevents the defensive drop-target fallback from changing
        sg2_in_XX_A to sg2_in_XX_B after lift completion. The only exception is
        when the requested target is exactly the pickup cell; in that invalid case
        we still need a real carry destination.
        """
        if not LOCK_EXPLICIT_SG2_AB_TARGETS:
            return False
        loc = str(target_location or "").strip().lower()
        if not (loc.startswith("sg2_in_") and (loc.endswith("_a") or loc.endswith("_b"))):
            return False
        rack = self.racks.get(rack_key)
        if rack is None:
            return False
        if target_cell == rack.cell:
            return False
        if QR_ONLY_NAVIGATION and self.valid_qr_cells and target_cell not in self.valid_qr_cells:
            return False
        return True

    def choose_drop_cell_away_from_pickup(self, desired_xy: Tuple[float, float], pickup_cell: GridCell) -> Tuple[float, float, GridCell]:
        """Return a QR cell that is not effectively the pickup cell.

        The Control Tower can send target_x/y equal to the current rack position.
        In that case the state machine sees TO_TARGET already complete right after
        lifting and immediately places the rack. This selector keeps the user
        requested target as much as possible, but guarantees a meaningful carry
        distance on QR cells.
        """
        if not self.valid_qr_cells:
            base = world_to_grid(*desired_xy)
            if cell_chebyshev_distance(base, pickup_cell) >= COMMAND_MIN_DROP_DISTANCE_CELLS:
                wx, wy = grid_to_world(base)
                return wx, wy, base
            fallback = (pickup_cell[0] + COMMAND_MIN_DROP_DISTANCE_CELLS, pickup_cell[1])
            wx, wy = grid_to_world(fallback)
            return wx, wy, fallback

        candidates = []
        for cell in self.valid_qr_cells:
            sep = cell_chebyshev_distance(cell, pickup_cell)
            if sep < COMMAND_MIN_DROP_DISTANCE_CELLS:
                continue
            wx, wy = grid_to_world(cell)
            desired_dist = distance_xy((wx, wy), desired_xy)
            # Prefer cells close to the requested target, then farther from pickup.
            score = desired_dist - 0.03 * sep
            candidates.append((score, desired_dist, -sep, cell, wx, wy))

        if not candidates:
            # Very defensive fallback: use the farthest known QR cell.
            far = max(self.valid_qr_cells, key=lambda c: cell_chebyshev_distance(c, pickup_cell))
            wx, wy = grid_to_world(far)
            return wx, wy, far

        candidates.sort()
        _, desired_dist, neg_sep, cell, wx, wy = candidates[0]
        return wx, wy, cell

    def enforce_drop_target_not_pickup(self, command_id: str, rack_key: str, target_xy: Tuple[float, float], target_cell: GridCell) -> Tuple[Tuple[float, float], GridCell]:
        rack = self.racks.get(rack_key)
        if rack is None:
            return target_xy, target_cell

        pickup_cell = rack.cell
        sep = cell_chebyshev_distance(target_cell, pickup_cell)
        if sep >= COMMAND_MIN_DROP_DISTANCE_CELLS:
            return target_xy, target_cell

        old_xy = target_xy
        old_cell = target_cell
        new_x, new_y, new_cell = self.choose_drop_cell_away_from_pickup(target_xy, pickup_cell)
        print(
            f"TARGET REASSIGNED AWAY FROM PICKUP | command={command_id} "
            f"pickup_cell={pickup_cell} old_target=({old_xy[0]:.3f}, {old_xy[1]:.3f}) "
            f"old_cell={old_cell} new_target=({new_x:.3f}, {new_y:.3f}) "
            f"new_cell={new_cell} min_sep={COMMAND_MIN_DROP_DISTANCE_CELLS}"
        )
        return (new_x, new_y), new_cell

    def update_qr_candidate_stability(self, amr: AmrState, qr_id: str, cell: GridCell) -> int:
        if amr.qr_candidate_id == qr_id and amr.qr_candidate_cell == cell:
            amr.qr_candidate_count += 1
        else:
            amr.qr_candidate_id = qr_id
            amr.qr_candidate_cell = cell
            amr.qr_candidate_count = 1
        return amr.qr_candidate_count

    def qr_localization_reject(self, amr: AmrState, qr_id: str, cell: Optional[GridCell], reason: str, now: float, force_log: bool = False) -> bool:
        amr.localization_source = "QR_REJECTED_HOLD_LAST_CELL"
        amr.qr_last_rejected_id = qr_id or ""
        amr.qr_last_rejected_reason = reason
        if force_log or now - amr.last_qr_log_at >= QR_LOG_PERIOD_SEC:
            print(
                f"QR REJECTED | {amr.name} qr={qr_id} detected_cell={cell} "
                f"hold_cell={amr.cell} state={amr.state} moving={amr.is_moving()} reason={reason}"
            )
            amr.last_qr_log_at = now
        return False

    def is_qr_cell_update_safe(self, amr: AmrState, cell: GridCell) -> Tuple[bool, str]:
        if amr.is_moving():
            return False, "amr_is_moving"
        if amr.state in QR_SAFE_BLOCK_STATES:
            return False, f"blocked_state_{amr.state}"

        jump = cell_chebyshev_distance(amr.cell, cell)
        if jump > QR_SAFE_MAX_CELL_JUMP:
            return False, f"cell_jump_{jump}_gt_{QR_SAFE_MAX_CELL_JUMP}"

        amr_xy = get_object_center_xy(amr.obj)
        qr_xy = self.qr_cell_world_map.get(cell, grid_to_world(cell))
        dist = distance_xy(amr_xy, qr_xy)
        if dist > QR_SAFE_MAX_WORLD_DIST_M:
            return False, f"world_dist_{dist:.3f}_gt_{QR_SAFE_MAX_WORLD_DIST_M:.3f}"

        return True, "safe"

    def localize_amr_by_qr_camera(self, amr: AmrState, now: float, force_log: bool = False) -> bool:
        if not QR_CAMERA_LOCALIZATION_ENABLED:
            return False
        if amr.qr_reader is None:
            if QR_ALLOW_TRANSFORM_FALLBACK:
                xy = get_object_center_xy(amr.obj)
                amr.cell = self.nearest_qr_cell_to_world(*xy) if QR_ONLY_NAVIGATION else world_to_grid(*xy)
                amr.localization_source = "TRANSFORM_FALLBACK_NO_CAMERA_QR_SNAPPED" if QR_ONLY_NAVIGATION else "TRANSFORM_FALLBACK_NO_CAMERA"
            return False

        qr_id = amr.qr_reader.decode()
        if not qr_id:
            if QR_ALLOW_TRANSFORM_FALLBACK:
                xy = get_object_center_xy(amr.obj)
                amr.cell = self.nearest_qr_cell_to_world(*xy) if QR_ONLY_NAVIGATION else world_to_grid(*xy)
                amr.localization_source = "TRANSFORM_FALLBACK_QR_MISS_QR_SNAPPED" if QR_ONLY_NAVIGATION else "TRANSFORM_FALLBACK_QR_MISS"
            else:
                amr.localization_source = "QR_MISS_HOLD_LAST_CELL"
            if force_log or now - amr.last_qr_log_at >= QR_LOG_PERIOD_SEC:
                print(f"QR MISS | {amr.name} camera={amr.camera_path} hold_cell={amr.cell} fallback={QR_ALLOW_TRANSFORM_FALLBACK} err={amr.qr_reader.last_error}")
                amr.last_qr_log_at = now
            return False

        cell = self.parse_qr_cell_from_text(qr_id)
        if cell is None:
            if QR_ALLOW_TRANSFORM_FALLBACK:
                xy = get_object_center_xy(amr.obj)
                amr.cell = self.nearest_qr_cell_to_world(*xy) if QR_ONLY_NAVIGATION else world_to_grid(*xy)
                amr.localization_source = "TRANSFORM_FALLBACK_QR_UNMAPPED_QR_SNAPPED" if QR_ONLY_NAVIGATION else "TRANSFORM_FALLBACK_QR_UNMAPPED"
            else:
                amr.localization_source = "QR_UNMAPPED_HOLD_LAST_CELL"
            if force_log or now - amr.last_qr_log_at >= QR_LOG_PERIOD_SEC:
                print(f"QR UNMAPPED | {amr.name} qr={qr_id} hold_cell={amr.cell} fallback={QR_ALLOW_TRANSFORM_FALLBACK}")
                amr.last_qr_log_at = now
            amr.current_qr_id = qr_id
            return False

        stable_count = self.update_qr_candidate_stability(amr, qr_id, cell)
        if stable_count < max(1, QR_SAFE_STABLE_DETECTIONS):
            return self.qr_localization_reject(
                amr,
                qr_id,
                cell,
                f"stable_count_{stable_count}_lt_{QR_SAFE_STABLE_DETECTIONS}",
                now,
                force_log,
            )

        safe, reason = self.is_qr_cell_update_safe(amr, cell)
        if not safe:
            return self.qr_localization_reject(amr, qr_id, cell, reason, now, force_log)

        amr.current_qr_id = qr_id
        old_cell = amr.cell
        amr.cell = cell
        amr.localization_source = "QR_CAMERA_SAFE"
        if force_log or now - amr.last_qr_log_at >= QR_LOG_PERIOD_SEC:
            print(
                f"QR LOCALIZED SAFE | {amr.name} qr={qr_id} old_cell={old_cell} "
                f"new_cell={cell} stable={stable_count} camera={amr.camera_path}"
            )
            amr.last_qr_log_at = now
        return True

    def update_qr_localization(self, now: float):
        amr_list = list(self.amrs.values())
        if not amr_list:
            return

        # FPS optimization: do not decode all five camera render products on every QR cycle.
        # Each AMR keeps its last valid QR/cell; only a small round-robin subset is decoded per cycle.
        # This keeps QR-based navigation while reducing camera readback + OpenCV workload.
        if QR_SCAN_ROUND_ROBIN_ENABLED:
            count = max(1, min(int(QR_SCAN_MAX_AMRS_PER_CYCLE), len(amr_list)))
            selected = []
            for _ in range(count):
                selected.append(amr_list[self.qr_round_robin_index % len(amr_list)])
                self.qr_round_robin_index += 1
        else:
            selected = amr_list

        for amr in selected:
            # Avoid changing discrete planner cell while interpolating between cells.
            if amr.is_moving():
                continue
            self.localize_amr_by_qr_camera(amr, now)

    def load_stage_objects(self):
        print_stage_object_discovery_report(self.stage, max_items=80)

        for name, configured_path in AMR_PRIM_PATHS.items():
            resolved_path, resolve_reason = resolve_stage_prim_path(self.stage, name, configured_path, "AMR")
            if not resolved_path:
                print(f"AMR NOT VALID/ACTIVE: {name} {configured_path} resolve={resolve_reason}")
                continue
            path = resolved_path
            prim = self.stage.GetPrimAtPath(path)
            if not prim.IsValid() or not prim.IsActive():
                print(f"AMR NOT VALID/ACTIVE AFTER RESOLVE: {name} {path}")
                continue
            z = get_z(prim)
            obj = SimObject(name=name, path=path, prim=prim, base_z=z)
            xy = get_object_center_xy(obj)
            cell = self.nearest_qr_cell_to_world(*xy) if QR_ONLY_NAVIGATION else world_to_grid(*xy)
            front_offset, front_ref_path = calibrate_front_yaw_offset(self.stage, prim, name)
            self.amrs[name] = AmrState(
                name=name,
                obj=obj,
                cell=cell,
                localization_source="TRANSFORM_INIT_QR_SNAPPED" if QR_ONLY_NAVIGATION else "TRANSFORM_INIT",
                front_reference_path=front_ref_path,
                front_yaw_offset_rad=front_offset,
            )
            print(
                f"AMR OK: {name} path={path} resolve={resolve_reason} center_xy={xy} cell={cell} "
                f"front_ref={front_ref_path or 'FALLBACK_OFFSET'} front_offset_deg={math.degrees(front_offset):.2f}"
            )

        # Load only WS_01~WS_10 keys to avoid duplicates from RACK_XX aliases.
        for i in range(1, 11):
            key = f"WS_{i:02d}"
            configured_path = RACK_PRIM_PATHS[key]
            resolved_path, resolve_reason = resolve_stage_prim_path(self.stage, key, configured_path, "RACK")
            if not resolved_path:
                print(f"RACK NOT VALID/ACTIVE: {key} {configured_path} resolve={resolve_reason}")
                continue
            path = resolved_path
            prim = self.stage.GetPrimAtPath(path)
            if not prim.IsValid() or not prim.IsActive():
                print(f"RACK NOT VALID/ACTIVE AFTER RESOLVE: {key} {path}")
                continue
            z = get_z(prim)
            obj = SimObject(name=key, path=path, prim=prim, base_z=z)
            if RACK_DISABLE_PHYSICS_AT_STARTUP:
                hard_disable_physics_subtree(prim, disable_collision=True)
                print(f"RACK SCRIPT CONTROLLED | {key} physics/collision disabled at startup")
            xy = get_object_center_xy(obj)
            cell = self.nearest_qr_cell_to_world(*xy) if QR_ONLY_NAVIGATION else world_to_grid(*xy)
            # Snap rack root to its nearest QR center at startup so rack origins are also aligned.
            if QR_ONLY_NAVIGATION and self.valid_qr_cells:
                qx, qy = grid_to_world(cell)
                set_object_center_xy(obj, qx, qy, obj.base_z)
                xy = get_object_center_xy(obj)
            self.racks[key] = RackState(key=key, obj=obj, cell=cell, physics_locked=RACK_DISABLE_PHYSICS_AT_STARTUP)
            print(f"RACK OK: {key} path={path} resolve={resolve_reason} center_xy={xy} cell={cell}")

        if not self.amrs:
            raise RuntimeError("No AMR prims loaded. v37 could not find AMR objects under Final_Factory World3 root. Check STAGE OBJECT DISCOVERY REPORT or set AMR_01_PRIM_PATH~AMR_05_PRIM_PATH.")
        if not self.racks:
            raise RuntimeError("No RACK prims loaded. v38 true-spots simple-exec auto-discovery could not find rack/workstation objects. Check STAGE OBJECT DISCOVERY REPORT or set WS_01_PRIM_PATH~WS_10_PRIM_PATH.")

    def build_rack_four_way_zones(self):
        """Build cells where diagonal motion is forbidden because of workstation legs.

        The workstation has four legs. When an AMR goes under/through or immediately around
        the rack, allowing diagonal motion can visually cut through the legs. This zone forces
        the planner and arbiter to use only north/east/south/west movement in and near racks.
        """
        global GLOBAL_RACK_FOUR_WAY_CELLS
        self.rack_four_way_cells.clear()

        if not RACK_FOUR_WAY_ZONE_ENABLED:
            GLOBAL_RACK_FOUR_WAY_CELLS = set()
            print("RACK FOUR-WAY ZONE DISABLED")
            return

        r = max(0, int(RACK_FOUR_WAY_ZONE_RADIUS_CELLS))
        for rack in self.racks.values():
            cx, cy = rack.cell
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    cell = (cx + dx, cy + dy)
                    if QR_ONLY_NAVIGATION and self.valid_qr_cells and cell not in self.valid_qr_cells:
                        continue
                    self.rack_four_way_cells.add(cell)

        GLOBAL_RACK_FOUR_WAY_CELLS = set(self.rack_four_way_cells)
        print(
            f"RACK FOUR-WAY ZONE LOADED | racks={len(self.racks)} "
            f"zone_cells={len(self.rack_four_way_cells)} radius={RACK_FOUR_WAY_ZONE_RADIUS_CELLS}"
        )

    def assign_initial_random_goals(self):
        if not RANDOM_DRIVE_ENABLED or STANDBY_UNTIL_COMMAND:
            for amr in self.amrs.values():
                if amr.state not in ["TO_RACK", "LIFTING", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "PLACING", "POST_PLACE_TURN_180", "POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT", "POST_PLACE_EXIT_HOLD", "RETURN_HOME"]:
                    amr.state = "IDLE"
                    amr.target_cell = None
                    amr.target_xy = None
            print("STANDBY MODE | AMRs will stay idle until /manage_workstation command arrives")
            return
        for amr in self.amrs.values():
            self.assign_random_goal(amr)

    def assign_random_goal(self, amr: AmrState):
        candidates: List[GridCell] = []
        obstacles = self.static_obstacles_for(amr, allow_assigned_rack=False)
        occupied_targets = self.occupied_and_target_cells(exclude_name=amr.name) if UNIQUE_RANDOM_GOALS_ENABLED else set()
        blocked = obstacles | occupied_targets

        if QR_ONLY_NAVIGATION and self.valid_qr_cells:
            for cell in self.valid_qr_cells:
                if cell == amr.cell or cell in blocked:
                    continue
                if cell in self.rack_four_way_cells:
                    # keep random circulation goals out of the rack-leg zone.
                    continue
                d = cell_manhattan_distance(cell, amr.cell)
                if RANDOM_GOAL_MIN_RADIUS_CELL <= d <= RANDOM_GOAL_RANGE_CELL * 2:
                    candidates.append(cell)
            if not candidates:
                for cell in self.valid_qr_cells:
                    if cell != amr.cell and cell not in blocked and cell not in self.rack_four_way_cells:
                        candidates.append(cell)
            if candidates:
                # Prefer targets farther from other AMR targets to reduce identical-coordinate convergence.
                def score(cell: GridCell) -> Tuple[int, int]:
                    other_targets = [a.target_cell for a in self.amrs.values() if a.name != amr.name and a.target_cell is not None]
                    min_sep = min((cell_chebyshev_distance(cell, t) for t in other_targets), default=99)
                    dist_self = cell_manhattan_distance(cell, amr.cell)
                    return (min_sep, dist_self)

                ranked = sorted(candidates, key=score, reverse=True)
                top = ranked[: min(16, len(ranked))]
                cell = random.choice(top)
                amr.target_cell = cell
                amr.target_xy = grid_to_world(cell)
                if amr.state not in ["TO_RACK", "LIFTING", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "PLACING", "POST_PLACE_TURN_180", "POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT", "POST_PLACE_EXIT_HOLD", "RETURN_HOME"]:
                    amr.state = "RANDOM"
                return

        for _ in range(120):
            dx = random.randint(-RANDOM_GOAL_RANGE_CELL, RANDOM_GOAL_RANGE_CELL)
            dy = random.randint(-RANDOM_GOAL_RANGE_CELL, RANDOM_GOAL_RANGE_CELL)
            if abs(dx) + abs(dy) < RANDOM_GOAL_MIN_RADIUS_CELL:
                continue
            cell = (amr.cell[0] + dx, amr.cell[1] + dy)
            if cell in blocked or cell in self.rack_four_way_cells:
                continue
            amr.target_cell = cell
            amr.target_xy = grid_to_world(cell)
            if amr.state not in ["TO_RACK", "LIFTING", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "PLACING", "POST_PLACE_TURN_180", "POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT", "POST_PLACE_EXIT_HOLD", "RETURN_HOME"]:
                amr.state = "RANDOM"
            return
        amr.target_cell = None
        amr.target_xy = None

    def occupied_and_target_cells(self, exclude_name: Optional[str] = None) -> Set[GridCell]:
        cells: Set[GridCell] = set()
        for other in self.amrs.values():
            if other.name == exclude_name:
                continue
            cells.add(other.cell)
            if other.target_cell is not None:
                cells.add(other.target_cell)
            if other.is_moving() and other.move_to is not None:
                cells.add(other.move_to)
        for rack in self.racks.values():
            cells.add(rack.cell)
        if UNIQUE_TASK_TARGET_RESERVATION_ENABLED:
            for task in self.tasks.values():
                if task.target_cell is not None:
                    cells.add(task.target_cell)
        return cells

    def release_random_goals_conflicting_with(self, reserved_cell: GridCell, owner_name: Optional[str] = None, reason: str = "reserved_target"):
        if not UNIQUE_RANDOM_GOALS_ENABLED:
            return
        for other in self.amrs.values():
            if owner_name is not None and other.name == owner_name:
                continue
            if other.state != "RANDOM":
                continue
            if other.target_cell == reserved_cell:
                print(f"UNIQUE TARGET RELEASE | {other.name} reason={reason} released={reserved_cell}")
                other.target_cell = None
                other.target_xy = None
                self.assign_dispersed_random_goal(other, reason=reason)

    def resolve_duplicate_random_targets(self):
        if not DUPLICATE_TARGET_RESOLVE_ENABLED:
            return
        target_groups: Dict[GridCell, List[AmrState]] = {}
        for amr in self.amrs.values():
            if amr.state != "RANDOM" or amr.target_cell is None:
                continue
            target_groups.setdefault(amr.target_cell, []).append(amr)

        for cell, group in target_groups.items():
            if len(group) <= 1:
                continue
            # Keep the AMR closest to the duplicated target; reassign the rest.
            group.sort(key=lambda a: cell_manhattan_distance(a.cell, cell))
            keeper = group[0]
            for amr in group[1:]:
                print(f"DUPLICATE TARGET REASSIGN | keep={keeper.name} reassign={amr.name} duplicated_goal={cell}")
                amr.target_cell = None
                amr.target_xy = None
                self.assign_dispersed_random_goal(amr, reason=f"duplicate_goal_{cell}")

        # Also keep random AMR goals away from active task destination cells.
        task_targets = {task.target_cell for task in self.tasks.values() if task.target_cell is not None}
        for amr in self.amrs.values():
            if amr.state == "RANDOM" and amr.target_cell in task_targets:
                old = amr.target_cell
                print(f"TASK TARGET CONFLICT REASSIGN | {amr.name} old_goal={old}")
                amr.target_cell = None
                amr.target_xy = None
                self.assign_dispersed_random_goal(amr, reason=f"task_target_conflict_{old}")

    def assign_dispersed_random_goal(self, amr: AmrState, reason: str = "anti_clump") -> bool:
        obstacles = self.static_obstacles_for(amr, allow_assigned_rack=False)
        occupied = self.occupied_and_target_cells(exclude_name=amr.name) | obstacles

        source_cells = list(self.valid_qr_cells) if (QR_ONLY_NAVIGATION and self.valid_qr_cells) else []
        if not source_cells:
            # Fallback to a bounded search around the robot if QR map is unavailable.
            cx, cy = amr.cell
            for dx in range(-RANDOM_GOAL_RANGE_CELL * 2, RANDOM_GOAL_RANGE_CELL * 2 + 1):
                for dy in range(-RANDOM_GOAL_RANGE_CELL * 2, RANDOM_GOAL_RANGE_CELL * 2 + 1):
                    source_cells.append((cx + dx, cy + dy))

        ranked: List[Tuple[int, int, GridCell]] = []
        for cell in source_cells:
            if cell == amr.cell or cell in occupied:
                continue
            if cell in self.rack_four_way_cells:
                # do not choose a rack-leg constrained zone as a random circulation target.
                continue
            dist_from_self = cell_manhattan_distance(cell, amr.cell)
            if dist_from_self < RANDOM_GOAL_MIN_RADIUS_CELL:
                continue
            min_sep = min((cell_chebyshev_distance(cell, c) for c in occupied), default=99)
            if min_sep < ANTI_CLUMP_GOAL_MIN_SEPARATION_CELLS:
                continue
            # Prefer far, well-separated goals.
            ranked.append((min_sep, dist_from_self, cell))

        if not ranked:
            return False

        ranked.sort(key=lambda x: (x[0], x[1]), reverse=True)
        # Use one of the best few to avoid deterministic cycling.
        top = ranked[: min(12, len(ranked))]
        _, _, chosen = random.choice(top)
        amr.target_cell = chosen
        amr.target_xy = grid_to_world(chosen)
        if amr.state not in ["TO_RACK", "LIFTING", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "PLACING", "POST_PLACE_TURN_180", "POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT", "POST_PLACE_EXIT_HOLD", "RETURN_HOME"]:
            amr.state = "RANDOM"
        amr.wait_steps = 0
        amr.no_path_steps = 0
        print(f"ANTI-CLUMP GOAL REASSIGNED | {amr.name} reason={reason} new_goal={chosen}")
        return True

    def resolve_random_clumps(self):
        if not ANTI_CLUMP_ENABLED:
            return
        random_amrs = [a for a in self.amrs.values() if a.state == "RANDOM" and not a.is_moving()]
        for amr in random_amrs:
            near = [
                other for other in self.amrs.values()
                if other.name != amr.name and cell_chebyshev_distance(other.cell, amr.cell) <= ANTI_CLUMP_RADIUS_CELLS
            ]
            if len(near) + 1 >= ANTI_CLUMP_MIN_GROUP_SIZE:
                self.assign_dispersed_random_goal(amr, reason=f"cluster_size_{len(near)+1}")

    def on_update(self, event):
        timeline = omni.timeline.get_timeline_interface()
        if not timeline.is_playing():
            return

        now = time.time()
        dt = getattr(event, "dt", None)
        if dt is None or dt <= 0.0:
            dt = 1.0 / 60.0
        dt = min(float(dt), 0.05)

        if now - self.last_qr_scan_at >= QR_CAMERA_SCAN_PERIOD_SEC:
            self.update_qr_localization(now)
            self.last_qr_scan_at = now

        if now - self.last_command_scan_at >= COMMAND_SCAN_PERIOD_SEC:
            self.scan_commands()
            self.last_command_scan_at = now

        self.update_task_phases(now, dt)

        # Dynamic SG2 lane clearance: allow B placements, but evacuate a placed B rack
        # when a matching A placement needs to enter behind it.
        self.ensure_sg2_lane_clearance_tasks()

        if now - self.last_decision_at >= DECISION_PERIOD_SEC:
            self.plan_and_approve_moves()
            self.last_decision_at = now

        self.update_motion(dt)
        self.detect_collisions()
        self.publish_redis_status_if_due(now)

        if now - self.last_log_at >= LOG_PERIOD_SEC:
            self.print_summary()
            self.last_log_at = now

    # --------------------------------------------------------
    # Redis realtime status publishing
    # --------------------------------------------------------
    def amr_state_for_redis(self, amr: AmrState) -> str:
        if amr.state in ["ERROR", "FAILED"]:
            return "ERROR"
        if amr.is_moving() or amr.state in ["TO_RACK", "LIFTING", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "PLACING", "POST_PLACE_TURN_180", "POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT", "POST_PLACE_EXIT_HOLD", "RETURN_HOME"]:
            return "MOVING"
        return "IDLE"

    def amr_target_qr_for_redis(self, amr: AmrState) -> str:
        if amr.target_cell is not None:
            return cell_to_floor_qr_id_from_map(amr.target_cell, self.qr_cell_world_map)
        return ""

    def amr_current_qr_for_redis(self, amr: AmrState) -> str:
        if amr.current_qr_id:
            return amr.current_qr_id
        return cell_to_floor_qr_id_from_map(amr.cell, self.qr_cell_world_map)

    def publish_redis_status_if_due(self, now: float):
        if not REDIS_STATUS_ENABLED or self.redis_client is None:
            return
        if now - self.last_redis_publish_at < REDIS_PUBLISH_PERIOD_SEC:
            return
        self.last_redis_publish_at = now

        ok_count = 0
        skipped_count = 0
        for amr in self.amrs.values():
            mapping = {
                "state": self.amr_state_for_redis(amr),
                "current_qr_id": self.amr_current_qr_for_redis(amr),
                "target_qr_id": self.amr_target_qr_for_redis(amr),
                "carrying_workstation_id": amr.carrying_rack or "",
                "battery": REDIS_BATTERY_DEFAULT,
            }
            key = f"{REDIS_KEY_PREFIX}{amr.name}"

            # Redis optimization: if nothing changed, do not write the same hash every cycle.
            # A full refresh is still forced at the reduced publish period by status changes.
            if self.redis_last_payloads.get(key) == mapping:
                skipped_count += 1
                continue

            if self.redis_client.hset(key, mapping):
                self.redis_last_payloads[key] = dict(mapping)
                ok_count += 1

        if ok_count == 0 and skipped_count == 0 and now - self.last_redis_log_at >= REDIS_RECONNECT_PERIOD_SEC:
            self.last_redis_log_at = now
            print(f"REDIS STATUS WAITING | {REDIS_HOST}:{REDIS_PORT} err={self.redis_client.last_error}")
        elif ok_count > 0 and now - self.last_redis_log_at >= 15.0:
            self.last_redis_log_at = now
            print(f"REDIS STATUS SENT | changed_amrs={ok_count} skipped_unchanged={skipped_count} host={REDIS_HOST}:{REDIS_PORT}")

    # --------------------------------------------------------
    # Dynamic SG2 lane clearance
    # --------------------------------------------------------
    def parse_sg2_target_location(self, target_location: str) -> Optional[Tuple[str, str]]:
        """Return (lane, slot) for names like sg2_in_02_A."""
        m = re.search(r"sg2[_\-]?in[_\-]?(\d+)[_\-]?([AB])", str(target_location or ""), re.IGNORECASE)
        if not m:
            return None
        return (m.group(1).zfill(2), m.group(2).upper())

    def sg2_outer_b_cell_for_inner_a_task(self, task: CommandTask) -> Optional[GridCell]:
        """Infer the outer B cell that can block the matching inner A cell.

        In the current Isaac grid used by the commands, A is one cell deeper in +x
        than B. Example: sg2_in_02_B=(4,-2), sg2_in_02_A=(5,-2).
        We intentionally infer from task.target_cell, not LOCATION_TARGETS, because
        incoming command JSON already provides the calibrated positive Isaac coordinates.
        """
        parsed = self.parse_sg2_target_location(task.target_location)
        if parsed is None:
            return None
        _, slot = parsed
        if slot != "A":
            return None
        return (task.target_cell[0] - 1, task.target_cell[1])

    def stationary_rack_at_cell(self, cell: GridCell, exclude_key: Optional[str] = None) -> Optional[RackState]:
        for rack in self.racks.values():
            if exclude_key is not None and rack.key == exclude_key:
                continue
            if rack.cell != cell:
                continue
            if rack.carried_by is not None:
                continue
            # If another active task is already assigned to this rack, do not steal it.
            if rack.assigned:
                return None
            return rack
        return None

    def active_clearance_for_rack(self, rack_key: str) -> bool:
        for task in self.tasks.values():
            if task.internal and task.action_mode == "LANE_CLEARANCE" and task.rack_key == rack_key:
                return True
        return False

    def preempt_return_home_for_lane_clearance(self, clearance_task: CommandTask, blocker: RackState, parent_task: CommandTask) -> bool:
        """Use a non-carrying RETURN_HOME AMR as the clearance carrier when no AMR is idle.

        This keeps the user's return-home policy: the preempted external command is
        not completed immediately.  It is paused, the AMR clears the blocking rack,
        then the internal task returns the same AMR to the original home cell and
        completes the paused external command.
        """
        if not RETURN_HOME_CLEARANCE_PREEMPT_ENABLED:
            return False

        candidates: List[Tuple[int, str, CommandTask]] = []
        for task in self.tasks.values():
            if task.internal:
                continue
            if task.phase != "RETURN_HOME":
                continue
            amr = self.amrs.get(task.amr_name or "")
            if amr is None:
                continue
            if amr.is_moving() or amr.carrying_rack:
                continue
            if amr.state != "RETURN_HOME":
                continue
            # Do not steal the A-bound AMR itself.
            if amr.name == parent_task.amr_name:
                continue
            candidates.append((cell_manhattan_distance(amr.cell, blocker.cell), amr.name, task))

        if not candidates:
            return False

        candidates.sort()
        _, amr_name, paused_task = candidates[0]
        amr = self.amrs[amr_name]

        paused_task.phase = "RETURN_HOME_PAUSED"
        paused_task.phase_start = time.time()

        clearance_task.amr_name = amr.name
        clearance_task.phase = "TO_RACK"
        clearance_task.phase_start = time.time()
        clearance_task.return_cell = paused_task.return_cell
        clearance_task.return_xy = paused_task.return_xy
        clearance_task.resume_task_id = paused_task.command_id

        blocker.assigned = True
        amr.state = "TO_RACK"
        amr.task_id = clearance_task.command_id
        amr.carrying_rack = None
        amr.target_cell = blocker.cell
        amr.target_xy = grid_to_world(blocker.cell)
        amr.wait_steps = 0
        amr.no_path_steps = 0
        self.release_random_goals_conflicting_with(blocker.cell, owner_name=amr.name, reason="lane_clearance_preempt_pickup")
        self.release_random_goals_conflicting_with(clearance_task.target_cell, owner_name=amr.name, reason="lane_clearance_preempt_drop")
        print(
            f"LANE CLEARANCE PREEMPT RETURN_HOME | parent={parent_task.command_id} blocker={blocker.key} "
            f"amr={amr.name} paused={paused_task.command_id} from={blocker.cell} to={clearance_task.target_cell} "
            f"return={clearance_task.return_cell}"
        )
        return True

    def active_external_targets(self) -> Set[GridCell]:
        cells: Set[GridCell] = set()
        for task in self.tasks.values():
            if task.internal:
                continue
            cells.add(task.target_cell)
            if task.return_cell is not None:
                cells.add(task.return_cell)
        return cells

    def choose_lane_clearance_cell(self, blocked_cell: GridCell, a_cell: GridCell, blocking_rack_key: str) -> Optional[GridCell]:
        """Choose a temporary cell for a rack that blocks an SG2 B->A lane.

        The target must be a QR-valid free cell, must not be an active task target,
        and should be outside the direct B/A lane.  The scoring prefers moving the
        rack left/outward and slightly aside rather than placing it directly in the
        same lane again.
        """
        occupied_racks = {rack.cell for key, rack in self.racks.items() if key != blocking_rack_key and rack.carried_by is None}
        occupied_amrs = {amr.cell for amr in self.amrs.values()}
        moving_to = {amr.move_to for amr in self.amrs.values() if amr.move_to is not None}
        forbidden = occupied_racks | occupied_amrs | moving_to | self.active_external_targets()
        forbidden.add(blocked_cell)
        forbidden.add(a_cell)
        # Keep the direct A/B lane clear after evacuation.
        for dx in range(-1, 2):
            forbidden.add((blocked_cell[0] + dx, blocked_cell[1]))

        candidates: List[GridCell] = []
        if self.valid_qr_cells:
            source = self.valid_qr_cells
        else:
            bx, by = blocked_cell
            source = {(x, y) for x in range(bx - 6, bx + 3) for y in range(by - 6, by + 7)}

        bx, by = blocked_cell
        for cell in source:
            if cell in forbidden:
                continue
            if cell in self.static_obstacles_for_virtual(blocking_rack_key):
                continue
            # Do not place the evacuation target deeper than the blocked SG2 B cell.
            if cell[0] >= blocked_cell[0]:
                continue
            candidates.append(cell)

        if not candidates:
            return None

        def score(cell: GridCell) -> Tuple[float, int, int, int]:
            x, y = cell
            dist = abs(x - bx) + abs(y - by)
            same_lane_penalty = 8 if y == by else 0
            near_a_penalty = 20 if cell_chebyshev_distance(cell, a_cell) <= 1 else 0
            # Prefer x <= B-2 so the B cell and its immediate approach stay clear.
            shallow_penalty = 5 if x == bx - 1 else 0
            return (dist + same_lane_penalty + near_a_penalty + shallow_penalty, abs(y - by), -x, y)

        candidates.sort(key=score)
        return candidates[0]

    def static_obstacles_for_virtual(self, exclude_rack_key: str) -> Set[GridCell]:
        obstacles: Set[GridCell] = set()
        for key, rack in self.racks.items():
            if key == exclude_rack_key:
                continue
            if rack.carried_by is not None:
                continue
            obstacles.add(rack.cell)
        return obstacles

    def ensure_sg2_lane_clearance_tasks(self):
        """Optionally create internal lane-clearance tasks.

        v14 default is OFF: after a workstation is placed at its final requested
        destination, the controller must not pick it again just to clear a lane.
        This keeps SG A/B and stage drops final for standalone 10-workstation tests.
        """
        if not DYNAMIC_SG2_LANE_CLEARANCE_ENABLED:
            return
        for task in list(self.tasks.values()):
            if task.internal:
                continue
            if task.phase not in {"TO_RACK", "LIFTING", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "PLACING"}:
                continue
            b_cell = self.sg2_outer_b_cell_for_inner_a_task(task)
            if b_cell is None:
                continue
            blocker = self.stationary_rack_at_cell(b_cell, exclude_key=task.rack_key)
            if blocker is None:
                continue
            if self.active_clearance_for_rack(blocker.key):
                continue
            clearance_cell = self.choose_lane_clearance_cell(b_cell, task.target_cell, blocker.key)
            if clearance_cell is None:
                now = time.time()
                print(f"LANE CLEARANCE WAIT | parent={task.command_id} blocker={blocker.key} at={b_cell} reason=no_clearance_cell")
                continue
            clearance_id = f"__CLEAR_{blocker.key}_FROM_{b_cell[0]}_{b_cell[1]}_FOR_{task.command_id}"
            if clearance_id in self.tasks:
                continue
            clearance_task = CommandTask(
                command_id=clearance_id,
                workstation_id=blocker.key,
                rack_key=blocker.key,
                target_location=f"lane_clearance_for_{task.target_location}",
                target_xy=grid_to_world(clearance_cell),
                target_cell=clearance_cell,
                target_yaw=0.0,
                action_mode="LANE_CLEARANCE",
                internal=True,
                parent_command_id=task.command_id,
                clearance_reason=f"blocking_{task.target_location}_via_{b_cell}",
            )
            if self.assign_task_to_amr(clearance_task):
                self.tasks[clearance_id] = clearance_task
                print(
                    f"LANE CLEARANCE START | parent={task.command_id} blocker={blocker.key} "
                    f"from={b_cell} to={clearance_cell} amr={clearance_task.amr_name}"
                )
            elif self.preempt_return_home_for_lane_clearance(clearance_task, blocker, task):
                self.tasks[clearance_id] = clearance_task
                print(
                    f"LANE CLEARANCE START | parent={task.command_id} blocker={blocker.key} "
                    f"from={b_cell} to={clearance_cell} amr={clearance_task.amr_name} mode=preempt_return_home"
                )
            else:
                # No idle/preemptable AMR yet. Retry on the next decision cycle; do not fail the user task.
                if int(time.time() * 10) % 30 == 0:
                    print(f"LANE CLEARANCE WAIT | parent={task.command_id} blocker={blocker.key} at={b_cell} reason=no_idle_or_preemptable_amr")

    # --------------------------------------------------------
    # Command queue
    # --------------------------------------------------------
    def scan_commands(self):
        for command_path in sorted(COMMAND_DIR.glob("*.json")):
            if command_path.name in self.processed_commands:
                continue
            data = safe_read_json(command_path)
            if not data:
                continue
            command_id = str(data.get("command_id", command_path.stem))
            created_at = float(data.get("created_at", 0.0) or 0.0)
            if IGNORE_STALE_COMMANDS_ON_STARTUP and created_at > 0.0:
                if created_at < self.controller_start_time - STALE_COMMAND_GRACE_SEC:
                    done_path = DONE_DIR / command_path.name
                    try:
                        shutil.move(str(command_path), str(done_path))
                    except Exception:
                        pass
                    self.processed_commands.add(command_path.name)
                    print(f"STALE COMMAND IGNORED | {command_id} created_at={created_at:.3f} controller_start={self.controller_start_time:.3f}")
                    continue
            if command_id in self.tasks:
                continue

            task = self.command_to_task(data)
            if task is None:
                safe_write_json(RESULT_DIR / f"{command_id}.json", {
                    "command_id": command_id,
                    "success": False,
                    "status": "FAILED",
                    "message": "invalid rack/workstation mapping",
                    "finished_at": time.time(),
                })
                self.processed_commands.add(command_path.name)
                continue

            if not self.assign_task_to_amr(task):
                safe_write_json(RESULT_DIR / f"{command_id}.json", {
                    "command_id": command_id,
                    "success": False,
                    "status": "FAILED",
                    "message": "no available AMR",
                    "finished_at": time.time(),
                })
                self.processed_commands.add(command_path.name)
                continue

            self.tasks[command_id] = task
            self.processed_commands.add(command_path.name)
            print(f"COMMAND ACCEPTED | {command_id} mode={task.action_mode} rack={task.rack_key} amr={task.amr_name} target={task.target_xy}")

    def command_to_task(self, data: Dict) -> Optional[CommandTask]:
        command_id = str(data.get("command_id", f"CMD_{int(time.time())}"))
        workstation_id = str(data.get("workstation_id", ""))
        rack_key = self.resolve_rack_key(workstation_id)
        if rack_key is None or rack_key not in self.racks:
            print(f"COMMAND REJECTED | unknown workstation_id={workstation_id}")
            return None

        start_location = str(data.get("start_location", ""))
        target_location = str(data.get("target_location", ""))
        start_location_key = start_location.strip().upper()
        target_location_key = target_location.strip().upper()
        tx = data.get("target_x", None)
        ty = data.get("target_y", None)
        yaw = float(data.get("target_yaw", 0.0) or 0.0)
        preferred_amr_name = str(
            data.get("preferred_amr_name", "")
            or data.get("preferred_amr", "")
            or data.get("amr_name", "")
            or data.get("robot_id", "")
        ).strip()
        require_preferred_amr = bool(data.get("require_preferred_amr", False))
        post_place_behavior = str(data.get("post_place_behavior", "AUTO") or "AUTO").strip().upper()
        post_place_exit_cell_raw = data.get("post_place_exit_cell", None)
        post_place_exit_cell: Optional[GridCell] = None
        if isinstance(post_place_exit_cell_raw, (list, tuple)) and len(post_place_exit_cell_raw) >= 2:
            try:
                post_place_exit_cell = (int(post_place_exit_cell_raw[0]), int(post_place_exit_cell_raw[1]))
            except Exception:
                post_place_exit_cell = None

        pre_target_wait_cell_raw = data.get("pre_target_wait_cell", None)
        pre_target_wait_cell: Optional[GridCell] = None
        if isinstance(pre_target_wait_cell_raw, (list, tuple)) and len(pre_target_wait_cell_raw) >= 2:
            try:
                pre_target_wait_cell = (int(pre_target_wait_cell_raw[0]), int(pre_target_wait_cell_raw[1]))
            except Exception:
                pre_target_wait_cell = None
        pre_target_pre_approach_cell_raw = data.get("pre_target_pre_approach_cell", None)
        pre_target_pre_approach_cell: Optional[GridCell] = None
        if isinstance(pre_target_pre_approach_cell_raw, (list, tuple)) and len(pre_target_pre_approach_cell_raw) >= 2:
            try:
                pre_target_pre_approach_cell = (int(pre_target_pre_approach_cell_raw[0]), int(pre_target_pre_approach_cell_raw[1]))
            except Exception:
                pre_target_pre_approach_cell = None
        pre_target_approach_cell_raw = data.get("pre_target_approach_cell", None)
        pre_target_approach_cell: Optional[GridCell] = None
        if isinstance(pre_target_approach_cell_raw, (list, tuple)) and len(pre_target_approach_cell_raw) >= 2:
            try:
                pre_target_approach_cell = (int(pre_target_approach_cell_raw[0]), int(pre_target_approach_cell_raw[1]))
            except Exception:
                pre_target_approach_cell = None
        pre_target_wait_required = bool(data.get("pre_target_wait_required", pre_target_wait_cell is not None))

        if preferred_amr_name and preferred_amr_name.upper().startswith("AMR") and not preferred_amr_name.startswith("AMR_"):
            digits = "".join(ch for ch in preferred_amr_name if ch.isdigit())
            if digits:
                preferred_amr_name = f"AMR_{int(digits):02d}"

        rack = self.racks.get(rack_key)
        if rack is None:
            return None

        rotate_by_target = target_location_key in ROTATE_WORKSTATION_TARGETS
        rotate_by_location = any(keyword in start_location_key for keyword in ROTATE_LOCATION_KEYWORDS) or any(keyword in target_location_key for keyword in ROTATE_LOCATION_KEYWORDS)
        action_mode = "ROTATE_WORKSTATION" if (rotate_by_target or rotate_by_location) else "MOVE_WORKSTATION"

        if action_mode == "ROTATE_WORKSTATION":
            target_xy = get_object_center_xy(rack.obj)
            target_cell = rack.cell
            rotate_start_yaw = get_root_yaw_rad(rack.obj.prim)
            rotate_target_yaw = normalize_angle_rad(rotate_start_yaw + ROTATE_WORKSTATION_DELTA_RAD)
            reason = "target_location" if rotate_by_target else "ROTATING_LOCATION"
            print(
                f"ROTATE_WORKSTATION COMMAND | command={command_id} reason={reason} "
                f"start_location={start_location} target_location={target_location} "
                f"rack={rack_key} cell={target_cell} start_yaw={rotate_start_yaw:.3f} target_yaw={rotate_target_yaw:.3f}"
            )
        else:
            if tx is not None and ty is not None and (abs(float(tx)) > 1e-6 or abs(float(ty)) > 1e-6):
                target_xy = (float(tx), float(ty))
            else:
                loc = LOCATION_TARGETS.get(target_location, LOCATION_TARGETS.get("warehouse", (0.0, -5.0, 0.0)))
                target_xy = (float(loc[0]), float(loc[1]))
                yaw = float(loc[2])

            target_cell = world_to_grid(*target_xy)
            if QR_ONLY_NAVIGATION and QR_SNAP_TARGET_TO_NEAREST and self.valid_qr_cells:
                snapped_x, snapped_y, snapped_cell = self.snap_xy_to_nearest_qr(*target_xy)
                snap_dist = distance_xy(target_xy, (snapped_x, snapped_y))
                if snap_dist <= QR_MAX_SNAP_DISTANCE_M:
                    print(f"TARGET SNAP TO QR | command={command_id} raw={target_xy} snapped=({snapped_x:.3f}, {snapped_y:.3f}) cell={snapped_cell} dist={snap_dist:.3f}")
                    target_xy = (snapped_x, snapped_y)
                    target_cell = snapped_cell
                else:
                    print(f"TARGET SNAP WARNING | command={command_id} raw={target_xy} nearest_cell={snapped_cell} dist={snap_dist:.3f}m > {QR_MAX_SNAP_DISTANCE_M}m")
                    target_cell = snapped_cell
                    target_xy = grid_to_world(target_cell)
            if not self.explicit_drop_target_locked(target_location, rack_key, target_cell):
                target_xy, target_cell = self.enforce_drop_target_not_pickup(command_id, rack_key, target_xy, target_cell)
            rotate_start_yaw = 0.0
            rotate_target_yaw = 0.0

        return CommandTask(
            command_id=command_id,
            workstation_id=workstation_id,
            rack_key=rack_key,
            target_location=target_location,
            target_xy=target_xy,
            target_cell=target_cell,
            target_yaw=yaw,
            preferred_amr_name=preferred_amr_name or None,
            require_preferred_amr=require_preferred_amr,
            action_mode=action_mode,
            rotate_start_yaw=rotate_start_yaw,
            rotate_target_yaw=rotate_target_yaw,
            post_place_behavior=post_place_behavior,
            post_place_exit_cell=post_place_exit_cell,
            post_place_exit_xy=grid_to_world(post_place_exit_cell) if post_place_exit_cell is not None else None,
            pre_target_wait_cell=pre_target_wait_cell,
            pre_target_wait_xy=grid_to_world(pre_target_wait_cell) if pre_target_wait_cell is not None else None,
            pre_target_pre_approach_cell=pre_target_pre_approach_cell,
            pre_target_pre_approach_xy=grid_to_world(pre_target_pre_approach_cell) if pre_target_pre_approach_cell is not None else None,
            pre_target_approach_cell=pre_target_approach_cell,
            pre_target_approach_xy=grid_to_world(pre_target_approach_cell) if pre_target_approach_cell is not None else None,
            pre_target_wait_required=pre_target_wait_required,
        )

    def resolve_rack_key(self, workstation_id: str) -> Optional[str]:
        if workstation_id in self.racks:
            return workstation_id
        if workstation_id.startswith("RACK_"):
            digits = "".join(ch for ch in workstation_id if ch.isdigit())
            if digits:
                key = f"WS_{int(digits):02d}"
                return key if key in self.racks else None
        if workstation_id.startswith("WS_"):
            return workstation_id if workstation_id in self.racks else None
        digits = "".join(ch for ch in workstation_id if ch.isdigit())
        if digits:
            key = f"WS_{int(digits):02d}"
            return key if key in self.racks else None
        return None

    def assign_task_to_amr(self, task: CommandTask) -> bool:
        rack = self.racks.get(task.rack_key)
        if rack is None or rack.assigned or rack.carried_by is not None:
            return False

        available = []
        rack_xy = get_object_center_xy(rack.obj)
        for amr in self.amrs.values():
            if amr.state in ["LIFTING", "ROTATING", "TO_RACK", "LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_TARGET", "PLACING", "POST_PLACE_TURN_180", "POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT", "POST_PLACE_EXIT_HOLD", "RETURN_HOME"] or amr.carrying_rack:
                continue
            dist = distance_xy(get_object_center_xy(amr.obj), rack_xy)
            available.append((dist, amr.name))

        if not available:
            return False

        available.sort()
        available_names = {name for _, name in available}
        preferred = (task.preferred_amr_name or "").strip()
        if PREFERRED_AMR_ASSIGNMENT_ENABLED and preferred:
            if preferred in available_names:
                amr = self.amrs[preferred]
                print(f"PREFERRED AMR ASSIGNED | command={task.command_id} preferred={preferred} rack={task.rack_key}")
            elif task.require_preferred_amr:
                print(
                    f"PREFERRED AMR UNAVAILABLE | command={task.command_id} preferred={preferred} "
                    f"available={sorted(available_names)} require=True"
                )
                return False
            else:
                amr = self.amrs[available[0][1]]
                print(
                    f"PREFERRED AMR FALLBACK | command={task.command_id} preferred={preferred} "
                    f"assigned={amr.name} available={sorted(available_names)}"
                )
        else:
            amr = self.amrs[available[0][1]]
        task.amr_name = amr.name
        task.phase = "TO_RACK"
        task.phase_start = time.time()
        task.return_cell = amr.cell
        task.return_xy = grid_to_world(amr.cell)

        if QR_ONLY_NAVIGATION and self.valid_qr_cells:
            rack.cell = self.nearest_qr_cell_to_world(*get_object_center_xy(rack.obj))

        rack.assigned = True
        amr.state = "TO_RACK"
        amr.task_id = task.command_id
        amr.carrying_rack = None
        amr.target_cell = rack.cell
        amr.target_xy = grid_to_world(rack.cell)
        self.release_random_goals_conflicting_with(rack.cell, owner_name=amr.name, reason="task_pickup_target_reserved")
        if task.action_mode != "ROTATE_WORKSTATION":
            self.release_random_goals_conflicting_with(task.target_cell, owner_name=amr.name, reason="task_drop_target_reserved")
        amr.wait_steps = 0
        amr.no_path_steps = 0
        self.publish_status(task, "PICKING")
        return True

    # --------------------------------------------------------
    # Task state machine
    # --------------------------------------------------------
    def clear_stale_motion_reservation(self, amr: AmrState):
        # Non-moving task phases must not keep a future move_to reservation.
        # This prevents another AMR from waiting on a cell that the current AMR
        # is not physically moving into while LIFTING/ROTATING/PLACING.
        if not amr.is_moving():
            amr.move_from = None
            amr.move_to = None
            amr.move_elapsed = 0.0

    def sg2_target_side(self, target_location: str) -> Optional[str]:
        parsed = self.parse_sg2_target_location(target_location)
        if parsed is None:
            return None
        _lane, side = parsed
        return str(side).upper()

    def resolve_post_place_behavior(self, task: CommandTask) -> str:
        """Return normalized v17 post-place behavior for a task.

        Explicit command payload wins.  AUTO maps SG2 A/B targets to the
        choreography discussed with the user:
          A -> SIDE_EXIT
          B -> TURN_180_AND_BACK_EXIT
        Non-SG targets keep legacy RETURN_HOME behavior.
        """
        behavior = str(task.post_place_behavior or "AUTO").strip().upper()
        if not SG_AB_POST_PLACE_ENABLED:
            return "RETURN_HOME"
        if behavior not in ("", "AUTO"):
            return behavior
        side = self.sg2_target_side(task.target_location)
        if side == "A":
            return SG_A_POST_PLACE_BEHAVIOR
        if side == "B":
            return SG_B_POST_PLACE_BEHAVIOR
        return "RETURN_HOME"

    def candidate_post_place_exit_cells(self, task: CommandTask, behavior: str) -> List[GridCell]:
        x, y = task.target_cell
        behavior = str(behavior or "").upper()
        out: List[GridCell] = []
        if task.post_place_exit_cell is not None:
            out.append(task.post_place_exit_cell)

        if behavior == "SIDE_EXIT":
            # Inner A cell: leave sideways so the B cell at x-1,y remains usable.
            # Prefer the aisle between this lane and the next upper lane; fallback to
            # the lower side and then forward/backward if the side cell is not QR-valid.
            if y >= 0:
                out += [(x, y + 1), (x, y - 1)]
            else:
                out += [(x, y + 1), (x, y - 1)]
            out += [(x + 1, y), (x - 1, y)]
        elif behavior in ("TURN_180_AND_BACK_EXIT", "BACK_EXIT", "TURN_180"):
            # Outer B cell: after placing, rotate the AMR and back out toward the entry side.
            out += [(x - 1, y), (x - 2, y), (x, y + 1), (x, y - 1)]
        else:
            out += [(x - 1, y), (x, y + 1), (x, y - 1), (x + 1, y)]

        # Keep order but remove duplicates.
        seen: Set[GridCell] = set()
        uniq: List[GridCell] = []
        for c in out:
            if c in seen:
                continue
            seen.add(c)
            uniq.append(c)
        return uniq

    def post_place_exit_cell_is_usable(self, amr: AmrState, cell: GridCell) -> bool:
        if cell == amr.cell:
            return False
        if QR_ONLY_NAVIGATION and self.valid_qr_cells and cell not in self.valid_qr_cells:
            return False
        # Empty AMR can pass under placed racks in this demo, but it still cannot
        # move into an AMR's current or in-progress destination cell.
        for other_name, other in self.amrs.items():
            if other_name == amr.name:
                continue
            if other.cell == cell:
                return False
            if other.is_moving() and other.move_to == cell:
                return False
        return True

    def choose_post_place_exit_cell(self, task: CommandTask, amr: AmrState, behavior: str) -> Optional[GridCell]:
        for c in self.candidate_post_place_exit_cells(task, behavior):
            if self.post_place_exit_cell_is_usable(amr, c):
                return c
        # Last-resort: scan nearby QR cells for any empty one that increases clearance
        # from the placed workstation.  This prevents a permanent stop under the rack.
        source = list(self.valid_qr_cells) if self.valid_qr_cells else []
        if not source:
            cx, cy = amr.cell
            source = [(cx + dx, cy + dy) for dx in range(-2, 3) for dy in range(-2, 3)]
        source.sort(key=lambda c: (cell_manhattan_distance(c, amr.cell), cell_manhattan_distance(c, task.target_cell), c[0], c[1]))
        for c in source:
            if 1 <= cell_manhattan_distance(c, amr.cell) <= 2 and self.post_place_exit_cell_is_usable(amr, c):
                return c
        return None

    def sg2_target_lane_id(self, target_location: str) -> Optional[str]:
        parsed = self.parse_sg2_target_location(target_location)
        if parsed is None:
            return None
        lane, _side = parsed
        return str(lane)

    def same_lane_a_task(self, task: CommandTask) -> Optional[CommandTask]:
        """Return the active A-side task in the same generic lane as a B-side task.

        This intentionally uses parsed lane/side semantics, not a specific SG name,
        AMR name, or target id.  If no matching A task is active, the A side is
        considered DONE/clear for this lane.
        """
        if self.sg2_target_side(task.target_location) != "B":
            return None
        lane = self.sg2_target_lane_id(task.target_location)
        if lane is None:
            return None
        for other in self.tasks.values():
            if other.command_id == task.command_id:
                continue
            if self.sg2_target_lane_id(other.target_location) != lane:
                continue
            if self.sg2_target_side(other.target_location) != "A":
                continue
            return other
        return None

    def same_lane_a_task_phase(self, task: CommandTask) -> str:
        """Return same-lane A task phase for a B-side task.

        DONE means no active same-lane A task remains.  This function is the
        semantic gate in front of Reservation Table A*: A* may optimize motion
        only inside the currently allowed sub-goal window.
        """
        other = self.same_lane_a_task(task)
        if other is None:
            return "DONE"
        return str(other.phase or "PENDING")

    def same_lane_b_task(self, task: CommandTask) -> Optional[CommandTask]:
        """Return the active B-side task in the same generic lane as an A-side task.

        Generic counterpart to same_lane_a_task().  Used for v24 A exit-hold so
        the A-side empty AMR waits at its side-exit cell while the same-lane B
        loaded AMR is close to final placement.
        """
        if self.sg2_target_side(task.target_location) != "A":
            return None
        lane = self.sg2_target_lane_id(task.target_location)
        if lane is None:
            return None
        for other in self.tasks.values():
            if other.command_id == task.command_id:
                continue
            if self.sg2_target_lane_id(other.target_location) != lane:
                continue
            if self.sg2_target_side(other.target_location) != "B":
                continue
            return other
        return None

    def same_lane_b_phase(self, task: CommandTask) -> str:
        other = self.same_lane_b_task(task)
        if other is None:
            return "DONE"
        return str(other.phase or "PENDING")

    def same_lane_b_needs_a_exit_hold(self, task: CommandTask) -> bool:
        """True when A should hold at side-exit instead of starting RETURN_HOME.

        The rule is generic: if an A-side task has just left its target and the
        matching B-side task is still carrying/delivering toward final, keep the
        empty A AMR parked at side-exit.  This leaves the shared approach/return
        corridor available to the loaded B AMR and avoids lane-specific hacks.
        """
        if not A_EXIT_HOLD_ENABLED:
            return False
        if self.sg2_target_side(task.target_location) != "A":
            return False
        b_task = self.same_lane_b_task(task)
        if b_task is None:
            return False
        if b_task.delivery_done or b_task.task_done:
            return False
        b_amr = self.amrs.get(b_task.amr_name or "")
        if b_amr is None:
            return False
        # Hold only when B is already in, or about to enter, the target-side
        # staging/final sequence.  If B is still going to rack, holding A would
        # only waste time.
        if b_task.phase in {"LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "PLACING"}:
            return True
        if b_amr.carrying_rack and b_amr.state in {"LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "PLACING"}:
            return True
        return False

    def mark_delivery_done(self, task: CommandTask, rack: RackState, amr: AmrState, now: float, reason: str):
        """Mark workstation delivery complete separately from AMR return-home."""
        if task.delivery_done:
            return
        task.delivery_done = True
        task.delivery_done_at = now
        if DELIVERY_DONE_LOG_ENABLED:
            print(
                f"DELIVERY_DONE | {amr.name} task={task.command_id} rack={rack.key} "
                f"target={task.target_cell} lane={self.sg2_target_lane_id(task.target_location)} "
                f"side={self.sg2_target_side(task.target_location)} reason={reason}"
            )
        self.publish_status(task, "DELIVERY_DONE")

    def start_a_exit_hold_if_needed(self, task: CommandTask, amr: AmrState, now: float) -> bool:
        """Enter v24 A-side EXIT_HOLD if same-lane B still needs final delivery."""
        if not self.same_lane_b_needs_a_exit_hold(task):
            return False
        task.phase = "POST_PLACE_EXIT_HOLD"
        task.phase_start = now
        amr.state = "POST_PLACE_EXIT_HOLD"
        amr.target_cell = None
        amr.target_xy = None
        amr.wait_steps = 0
        amr.no_path_steps = 0
        self.clear_stale_motion_reservation(amr)
        b_task = self.same_lane_b_task(task)
        if A_EXIT_HOLD_LOG_ENABLED:
            print(
                f"A_EXIT_HOLD START | {amr.name} task={task.command_id} cell={amr.cell} "
                f"lane={self.sg2_target_lane_id(task.target_location)} b_task={b_task.command_id if b_task else None} "
                f"b_phase={b_task.phase if b_task else 'DONE'} b_stage={getattr(b_task, 'pre_target_stage', '') if b_task else ''}"
            )
        self.publish_status(task, "EXIT_HOLD")
        return True


    def sg_local_macro_template(self, task: CommandTask) -> Optional[Dict[str, GridCell]]:
        """Return SG local macro cells for A/B target.

        v31 treats A_in/B_in as a corridor, not as a single final approach cell.
        A* may bring the AMR to the first corridor gate, but inside the corridor
        the AMR follows the fixed cell list in order.
        """
        if not SG_LOCAL_MACRO_ROUTE_ENABLED:
            return None
        side = self.sg2_target_side(task.target_location)
        if side not in {"A", "B"}:
            return None
        x, y = task.target_cell
        if side == "A":
            a_slot = task.target_cell
            b_slot = (x - 1, y)
        else:
            b_slot = task.target_cell
            a_slot = (x + 1, y)

        # Corridor row sits one QR row below the A/B slots.
        corridor_y = a_slot[1] - 1
        gate_x = min(SG_LOCAL_MACRO_CORRIDOR_GATE_X, a_slot[0], b_slot[0])

        # A keeps the existing lower corridor rule for now.
        # B uses a stricter same-row BIN rule when enabled.  The user's SG2-1-B
        # expectation is QR_c9_r7 -> QR_c10_r7, i.e. (3,1) -> (4,1), not
        # (2,0)->(3,0)->(4,0)->(4,1).
        b_same_row_y = b_slot[1]
        b_in = (b_slot[0] - max(1, SG_LOCAL_MACRO_B_IN_OFFSET_X), b_slot[1])

        return {
            "A": a_slot,
            "B": b_slot,
            "CORRIDOR_GATE_X": gate_x,
            "CORRIDOR_Y": corridor_y,
            "A_IN": (a_slot[0], corridor_y),
            "B_IN": b_in,
            "B_SAME_ROW_Y": b_same_row_y,
        }

    def build_strict_cell_by_cell_route(self, start_cell: GridCell, corridor_y: int, slot: GridCell) -> List[GridCell]:
        """Build a strict adjacent-cell route from the AMR's current cell to the slot.

        Unlike v32, this does not set a far target such as B_IN=(3,1) from
        current=(1,0).  It expands every intermediate cell so the local macro
        can command one adjacent cell at a time and A* has no opportunity to
        select a detour inside the SG entry corridor.

        Examples:
          B sg2_in_01_B from WS07 (1,0) to (4,1):
            [(1,0),(1,1),(2,1),(3,1),(4,1)]
          B sg2_in_02_B from WS05 (1,-2) to (4,-2):
            [(1,-2),(2,-2),(3,-2),(4,-2)]
          A sg2_in_02_A from WS03 (1,-4) to (5,-2), corridor_y=-3:
            [(1,-4),(1,-3),(2,-3),(3,-3),(4,-3),(5,-3),(5,-2)]
        """
        cx, cy = start_cell
        sx, sy = slot
        route: List[GridCell] = [(cx, cy)]

        # 1) Move vertically at the current x until the desired corridor row.
        if cy != corridor_y:
            vstep = 1 if corridor_y > cy else -1
            yy = cy + vstep
            while True:
                route.append((cx, yy))
                if yy == corridor_y:
                    break
                yy += vstep

        # 2) Move horizontally along the corridor row until aligned with slot x.
        if cx != sx:
            hstep = 1 if sx > cx else -1
            xx = cx + hstep
            while True:
                route.append((xx, corridor_y))
                if xx == sx:
                    break
                xx += hstep

        # 3) Move vertically into the final slot if the corridor row differs.
        if corridor_y != sy:
            vstep = 1 if sy > corridor_y else -1
            yy = corridor_y + vstep
            while True:
                route.append((sx, yy))
                if yy == sy:
                    break
                yy += vstep

        # Remove immediate duplicates while preserving order.
        cleaned: List[GridCell] = []
        for c in route:
            if not cleaned or cleaned[-1] != c:
                cleaned.append(c)
        return cleaned

    def build_sg_b_same_row_route(self, b_in: GridCell, b_slot: GridCell) -> List[GridCell]:
        """Legacy v32 B/BIN two-point route.

        Kept for env-switch comparison. v33 strict entry corridor should prefer
        build_strict_cell_by_cell_route(...).
        """
        bx, by = b_slot
        ix, iy = b_in
        route: List[GridCell] = []
        if iy != by:
            route.append((ix, iy))
            route.append((ix, by))
        step = 1 if bx >= ix else -1
        for xx in range(ix, bx + step, step):
            route.append((xx, by))
        cleaned: List[GridCell] = []
        for c in route:
            if not cleaned or cleaned[-1] != c:
                cleaned.append(c)
        return cleaned

    def build_sg_corridor_route(self, gate_x: int, corridor_y: int, slot: GridCell) -> List[GridCell]:
        """Build a fixed horizontal-then-vertical corridor route to a slot.

        Example for B=(4,-2), gate_x=2:
          [(2,-3), (3,-3), (4,-3), (4,-2)]
        Example for A=(5,-2), gate_x=2:
          [(2,-3), (3,-3), (4,-3), (5,-3), (5,-2)]
        """
        sx, sy = slot
        route: List[GridCell] = []
        step = 1 if sx >= gate_x else -1
        for xx in range(gate_x, sx + step, step):
            route.append((xx, corridor_y))
        if not route or route[-1] != (sx, sy):
            route.append((sx, sy))
        # Remove immediate duplicates while preserving order.
        cleaned: List[GridCell] = []
        for c in route:
            if not cleaned or cleaned[-1] != c:
                cleaned.append(c)
        return cleaned

    def local_macro_cell_is_free(self, cell: GridCell, task: CommandTask, amr: AmrState, *, allow_task_final: bool = False) -> bool:
        if QR_ONLY_NAVIGATION and self.valid_qr_cells and cell not in self.valid_qr_cells:
            return False
        if allow_task_final and cell == task.target_cell:
            pass
        for other_name, other in self.amrs.items():
            if other_name == amr.name:
                continue
            if other.cell == cell:
                return False
            if other.is_moving() and other.move_to == cell:
                return False
            # Treat another AMR's current macro/normal target as a soft reservation.
            if other.target_cell == cell and other.state not in {"IDLE", "RETURN_HOME"}:
                return False
        for rk, rack in self.racks.items():
            if rk == task.rack_key:
                continue
            if rack.cell == cell and rack.carried_by is None:
                return False
        return True

    def same_lane_b_task_blocks_a_borrow(self, task: CommandTask, route: List[GridCell]) -> bool:
        """Return True if the same-lane B task is already using/approaching B/B_in.

        A may borrow B/B_in only when those cells are actually free.  If the B AMR
        is still going to its rack, borrowing can still be efficient; if it is
        already carrying into the local bay, A must not steal the B route.
        """
        b_task = self.same_lane_b_task(task)
        if b_task is None or b_task.delivery_done or b_task.task_done:
            return False
        b_amr = self.amrs.get(b_task.amr_name or "")
        route_set = set(route)
        if b_amr is None:
            return False
        if b_amr.cell in route_set or (b_amr.move_to in route_set if b_amr.move_to is not None else False):
            return True
        if b_amr.target_cell in route_set and b_amr.state in {"TO_PRE_TARGET_WAIT", "TO_TARGET", "LOCAL_ENTRY", "PLACING"}:
            return True
        if b_amr.carrying_rack and b_amr.state in {"TO_PRE_TARGET_WAIT", "TO_TARGET", "LOCAL_ENTRY", "PLACING"}:
            return True
        return False

    def local_macro_route_qr_valid(self, route: List[GridCell]) -> bool:
        """Return True when every local macro cell exists in the QR graph.

        v30: QR validity remains a hard constraint, but occupancy is checked only
        for the first step before starting.  This prevents a later cell, which an
        AMR will reach 2~3 ticks later, from blocking the whole route at t=0.
        """
        if not (QR_ONLY_NAVIGATION and self.valid_qr_cells):
            return True
        return all(c in self.valid_qr_cells for c in route)

    def local_macro_route_start_is_free(self, route: List[GridCell], task: CommandTask, amr: AmrState) -> bool:
        """Check only the immediate gateway cell for local macro start.

        If the first route cell is the AMR's current cell, skip it and check the
        next cell.  Future route cells are deliberately not treated as hard
        reservations here; they will be arbitrated when the AMR actually reaches
        the previous cell.
        """
        if not route:
            return False
        idx = 0
        while idx < len(route) - 1 and route[idx] == amr.cell:
            idx += 1
        first = route[idx]
        return self.local_macro_cell_is_free(first, task, amr, allow_task_final=(first == task.target_cell))

    def choose_sg_local_entry_route(self, task: CommandTask, amr: AmrState) -> Tuple[List[GridCell], str]:
        """Choose a deterministic SG local entry route.

        v33 policy:
        - A and B use strict adjacent-cell entry corridors.
        - B same-row BIN means current -> target row -> ... -> B_IN -> B.
        - A lower corridor means current -> corridor row -> ... -> A_IN -> A.
        - No A*/detour target is used inside the local macro because every
          route element is adjacent to the previous element.
        """
        tpl = self.sg_local_macro_template(task)
        if tpl is None:
            return [], ""
        side = self.sg2_target_side(task.target_location)

        def route_start_ok(route: List[GridCell]) -> bool:
            if not self.local_macro_route_qr_valid(route):
                return False
            if SG_LOCAL_MACRO_CHECK_WHOLE_ROUTE_BEFORE_START:
                return all(self.local_macro_cell_is_free(c, task, amr, allow_task_final=(c == task.target_cell)) for c in route)
            return self.local_macro_route_start_is_free(route, task, amr)

        gate_x = int(tpl.get("CORRIDOR_GATE_X", SG_LOCAL_MACRO_CORRIDOR_GATE_X))
        corridor_y = int(tpl.get("CORRIDOR_Y", task.target_cell[1] - 1))

        if side == "B":
            # v33: strict same-row B/BIN corridor from the current pickup cell.
            # Example sg2_in_01_B from current=(1,0):
            #   (1,0)->(1,1)->(2,1)->(3,1)->(4,1)
            if SG_LOCAL_MACRO_STRICT_ENTRY_CORRIDOR_ENABLED and SG_LOCAL_MACRO_B_SAME_ROW_BIN_ENABLED:
                route = self.build_strict_cell_by_cell_route(amr.cell, int(tpl["B_SAME_ROW_Y"]), tpl["B"])
                if route_start_ok(route):
                    return route, "B_STRICT_SAME_ROW_CORRIDOR"
                return [], ""
            # Legacy v32/v31 fallbacks, kept behind env switches for comparison.
            if SG_LOCAL_MACRO_B_SAME_ROW_BIN_ENABLED:
                route = self.build_sg_b_same_row_route(tpl["B_IN"], tpl["B"])
                if route_start_ok(route):
                    return route, "B_SAME_ROW_BIN"
                return [], ""
            route = self.build_sg_corridor_route(gate_x, corridor_y, tpl["B"])
            if route_start_ok(route):
                return route, "B_FULL_CORRIDOR"
            return [], ""

        if side == "A":
            # v33: strict adjacent A corridor from the current pickup cell.
            # Example sg2_in_02_A from current=(1,-4):
            #   (1,-4)->(1,-3)->(2,-3)->...->(5,-3)->(5,-2)
            if SG_LOCAL_MACRO_STRICT_ENTRY_CORRIDOR_ENABLED:
                route = self.build_strict_cell_by_cell_route(amr.cell, corridor_y, tpl["A"])
                if route_start_ok(route):
                    return route, "A_STRICT_CORRIDOR"
                return [], ""

            route = self.build_sg_corridor_route(gate_x, corridor_y, tpl["A"])
            if route_start_ok(route):
                return route, "A_FULL_CORRIDOR"

            if SG_LOCAL_MACRO_A_DIRECT_FALLBACK_IF_RIGHT_INVALID:
                direct_route = [tpl["A_IN"], tpl["A"]]
                if route_start_ok(direct_route):
                    return direct_route, "A_DIRECT_FALLBACK"
            return [], ""
        return [], ""

    def is_strict_sg_local_macro_task(self, task: CommandTask) -> bool:
        if not (SG_LOCAL_MACRO_ROUTE_ENABLED and SG_LOCAL_MACRO_STRICT_AB_ENTRY):
            return False
        if task.action_mode == "ROTATE_WORKSTATION":
            return False
        return self.sg2_target_side(task.target_location) in {"A", "B"}

    def start_local_macro_wait(self, task: CommandTask, amr: AmrState, now: float, reason: str = "route_not_free") -> bool:
        if not self.is_strict_sg_local_macro_task(task):
            return False
        task.phase = "LOCAL_ENTRY_WAIT"
        task.phase_start = now
        amr.state = "LOCAL_ENTRY_WAIT"
        amr.target_cell = None
        amr.target_xy = None
        self.clear_stale_motion_reservation(amr)
        amr.wait_steps = 0
        amr.no_path_steps = 0
        if SG_LOCAL_MACRO_LOG_ENABLED:
            print(
                f"LOCAL_MACRO ENTRY WAIT | {amr.name} task={task.command_id} "
                f"side={self.sg2_target_side(task.target_location)} lane={self.sg2_target_lane_id(task.target_location)} "
                f"reason={reason} final={task.target_cell}"
            )
        self.publish_status(task, "NAVIGATING")
        return True

    def start_local_macro_entry_if_available(self, task: CommandTask, amr: AmrState, now: float) -> bool:
        if not SG_LOCAL_MACRO_ROUTE_ENABLED or task.action_mode == "ROTATE_WORKSTATION":
            return False
        route, label = self.choose_sg_local_entry_route(task, amr)
        if not route:
            return False
        # Drop already-current leading cells, but keep at least the final slot.
        while route and route[0] == amr.cell and len(route) > 1:
            route.pop(0)
        task.local_entry_route = list(route)
        task.local_entry_index = 0
        task.local_entry_label = label
        task.local_route_mode = label
        task.local_exit_route = list(reversed(task.local_entry_route)) if SG_LOCAL_MACRO_USE_REVERSE_EXIT else []
        task.local_exit_index = 0
        next_cell = task.local_entry_route[0]
        task.phase = "LOCAL_ENTRY"
        task.phase_start = now
        amr.state = "LOCAL_ENTRY"
        amr.target_cell = next_cell
        amr.target_xy = grid_to_world(next_cell)
        amr.wait_steps = 0
        amr.no_path_steps = 0
        self.release_random_goals_conflicting_with(next_cell, owner_name=amr.name, reason="local_macro_entry_reserved")
        if SG_LOCAL_MACRO_LOG_ENABLED:
            print(
                f"LOCAL_MACRO ENTRY START | {amr.name} task={task.command_id} mode={label} "
                f"route={task.local_entry_route} final={task.target_cell} lane={self.sg2_target_lane_id(task.target_location)} "
                f"side={self.sg2_target_side(task.target_location)}"
            )
        self.publish_status(task, "NAVIGATING")
        return True

    def advance_local_macro_entry(self, task: CommandTask, amr: AmrState, now: float):
        if not task.local_entry_route:
            task.phase = "TO_TARGET"
            task.phase_start = now
            amr.state = "TO_TARGET"
            amr.target_cell = task.target_cell
            amr.target_xy = task.target_xy
            return
        if amr.cell != amr.target_cell or amr.is_moving():
            return
        if amr.cell == task.target_cell:
            task.phase = "PLACING"
            task.phase_start = now
            amr.state = "PLACING"
            self.clear_stale_motion_reservation(amr)
            if SG_LOCAL_MACRO_LOG_ENABLED:
                print(f"LOCAL_MACRO ENTRY DONE | {amr.name} task={task.command_id} mode={task.local_entry_label} at={amr.cell}")
            self.publish_status(task, "PLACING")
            return
        task.local_entry_index += 1
        if task.local_entry_index >= len(task.local_entry_route):
            # Safety fallback: aim at final if the route ended unexpectedly.
            next_cell = task.target_cell
        else:
            next_cell = task.local_entry_route[task.local_entry_index]
        amr.target_cell = next_cell
        amr.target_xy = grid_to_world(next_cell) if next_cell != task.target_cell else task.target_xy
        amr.wait_steps = 0
        amr.no_path_steps = 0
        self.release_random_goals_conflicting_with(next_cell, owner_name=amr.name, reason="local_macro_entry_step_reserved")
        if SG_LOCAL_MACRO_LOG_ENABLED:
            print(f"LOCAL_MACRO ENTRY STEP | {amr.name} task={task.command_id} next={next_cell} index={task.local_entry_index} route={task.local_entry_route}")

    def start_local_macro_exit_if_available(self, task: CommandTask, amr: AmrState, now: float) -> bool:
        if not SG_LOCAL_MACRO_ROUTE_ENABLED or not SG_LOCAL_MACRO_USE_REVERSE_EXIT:
            return False
        if not task.local_exit_route:
            return False
        route = list(task.local_exit_route)
        while route and route[0] == amr.cell:
            route.pop(0)
        if not route:
            return False

        original_exit_route = list(route)
        if (
            SG_LOCAL_MACRO_SHORT_A_EXIT_ANCHOR_ENABLED
            and self.sg2_target_side(task.target_location) == "A"
            and SG_LOCAL_MACRO_A_SHORT_EXIT_STEPS >= 0
        ):
            # v34: For A slots, do not replay the full reverse corridor.
            # Back out only a short anchor segment, then let RETURN_HOME A* plan
            # from that anchor to the AMR's home.  This removes unnecessary
            # moves such as (5,1)->(5,0)->(4,0)->(3,0)->... before going home.
            short_steps = max(0, SG_LOCAL_MACRO_A_SHORT_EXIT_STEPS)
            route = route[:short_steps]
            if SG_LOCAL_MACRO_SHORT_EXIT_LOG_ENABLED:
                print(
                    f"LOCAL_MACRO SHORT EXIT ANCHOR | {amr.name} task={task.command_id} "
                    f"side=A steps={short_steps} from={amr.cell} short_route={route} original_route={original_exit_route}"
                )
            if not route:
                self.start_return_home_after_post_place_exit(task, amr, now)
                return True

        task.local_exit_route = route
        task.local_exit_index = 0
        next_cell = route[0]
        task.phase = "LOCAL_EXIT"
        task.phase_start = now
        amr.state = "LOCAL_EXIT"
        amr.target_cell = next_cell
        amr.target_xy = grid_to_world(next_cell)
        amr.wait_steps = 0
        amr.no_path_steps = 0
        self.release_random_goals_conflicting_with(next_cell, owner_name=amr.name, reason="local_macro_exit_reserved")
        if SG_LOCAL_MACRO_LOG_ENABLED:
            print(
                f"LOCAL_MACRO EXIT START | {amr.name} task={task.command_id} mode={task.local_entry_label} "
                f"route={task.local_exit_route} from={amr.cell}"
            )
        self.publish_status(task, "RETURNING")
        return True

    def advance_local_macro_exit(self, task: CommandTask, amr: AmrState, now: float):
        if not task.local_exit_route:
            self.start_return_home_after_post_place_exit(task, amr, now)
            return
        if amr.cell != amr.target_cell or amr.is_moving():
            return
        if task.local_exit_index >= len(task.local_exit_route) - 1:
            if SG_LOCAL_MACRO_LOG_ENABLED:
                print(f"LOCAL_MACRO EXIT DONE | {amr.name} task={task.command_id} at={amr.cell} mode={task.local_entry_label}")
            self.start_return_home_after_post_place_exit(task, amr, now)
            return
        task.local_exit_index += 1
        next_cell = task.local_exit_route[task.local_exit_index]
        amr.target_cell = next_cell
        amr.target_xy = grid_to_world(next_cell)
        amr.wait_steps = 0
        amr.no_path_steps = 0
        self.release_random_goals_conflicting_with(next_cell, owner_name=amr.name, reason="local_macro_exit_step_reserved")
        if SG_LOCAL_MACRO_LOG_ENABLED:
            print(f"LOCAL_MACRO EXIT STEP | {amr.name} task={task.command_id} next={next_cell} index={task.local_exit_index} route={task.local_exit_route}")

    def same_lane_a_exit_move_reserved(self, task: CommandTask) -> bool:
        """True when same-lane A has detached its rack and has committed to exit.

        v23 early B final release condition.  A does not need to be fully
        RETURN_HOME yet.  It must already be in side-exit choreography with a
        concrete move target away from the A target, or later.  This is a generic
        semantic condition for any A/B lane.
        """
        if not EARLY_B_FINAL_RELEASE_ENABLED:
            return False
        other = self.same_lane_a_task(task)
        if other is None:
            return True
        phase = str(other.phase or "PENDING")
        if phase in {"POST_PLACE_EXIT_HOLD", "RETURN_HOME", "DONE"}:
            return True
        if phase != "POST_PLACE_SIDE_EXIT":
            return False

        a_amr = self.amrs.get(other.amr_name or "")
        a_rack = self.racks.get(other.rack_key or "")
        if a_amr is None:
            return False

        # The rack must already be detached from A.  This prevents B final entry
        # while A still physically owns the workstation footprint.
        if a_amr.carrying_rack is not None:
            return False
        if a_rack is not None and a_rack.carried_by is not None:
            return False

        exit_cell = other.post_place_exit_cell
        if exit_cell is None or exit_cell == other.target_cell:
            return False

        # Side-exit must be committed/reserved.  Either the AMR is already moving
        # to the exit cell or its current target is the side-exit cell.
        if a_amr.move_from == other.target_cell and a_amr.move_to == exit_cell:
            return True
        if a_amr.target_cell == exit_cell and a_amr.cell != exit_cell:
            return True
        return False

    def same_lane_a_task_blocks_b_final_entry(self, task: CommandTask) -> bool:
        """True when a B-side final entry should wait for same-lane A choreography.

        v23 policy: B may enter final before A reaches RETURN_HOME only after
        A's rack is detached and A's side-exit move is reserved.  Otherwise it
        follows the conservative v21/v22 rule.
        """
        if not SG_AB_PRE_TARGET_STAGING_ENABLED:
            return False
        if self.sg2_target_side(task.target_location) != "B":
            return False
        phase = self.same_lane_a_task_phase(task)
        if phase in {"RETURN_HOME", "DONE"}:
            return False
        if self.same_lane_a_exit_move_reserved(task):
            return False
        return True

    def pre_target_pre_approach_allowed(self, task: CommandTask, amr: AmrState) -> bool:
        """Allow B to advance from safe_wait to pre_approach before A clear.

        This is the v21 efficiency improvement.  B can move one step closer when
        A has started PLACING or later, while keeping A's side-exit/final zone
        free.
        """
        if not task.pre_target_wait_required:
            return True
        phase = self.same_lane_a_task_phase(task)
        return phase in {
            "PLACING",
            "POST_PLACE_SIDE_EXIT",
            "POST_PLACE_EXIT_HOLD",
            "POST_PLACE_BACK_EXIT",
            "POST_PLACE_TURN_180",
            "RETURN_HOME",
            "DONE",
        }

    def pre_target_approach_allowed(self, task: CommandTask, amr: AmrState) -> bool:
        """Allow B to advance from pre_approach to approach.

        Approach is closer to the B final target, so it waits until the A AMR has
        begun leaving the A target area.
        """
        if not task.pre_target_wait_required:
            return True
        phase = self.same_lane_a_task_phase(task)
        return phase in {
            "POST_PLACE_SIDE_EXIT",
            "POST_PLACE_EXIT_HOLD",
            "POST_PLACE_BACK_EXIT",
            "POST_PLACE_TURN_180",
            "RETURN_HOME",
            "DONE",
        }

    def pre_target_final_entry_allowed(self, task: CommandTask, amr: AmrState) -> bool:
        """Return True only when semantic A/B lane order allows B final entry.

        v23 rule: timeout never releases B to final.  Final entry is allowed as
        soon as same-lane A has detached its rack and reserved a side-exit move,
        or when A is RETURN_HOME/DONE.  Before that, B may only move through
        safe_wait/pre_approach/approach according to the partial-entry gates.
        """
        if not task.pre_target_wait_required:
            return True
        return not self.same_lane_a_task_blocks_b_final_entry(task)

    def route_pre_target_to_cell(self, task: CommandTask, amr: AmrState, now: float, next_cell: GridCell, next_label: str, reason: str):
        task.phase = "TO_PRE_TARGET_WAIT"
        task.phase_start = now
        amr.state = "TO_PRE_TARGET_WAIT"
        stage_label = str(next_label or "").strip().upper()
        if stage_label in {"PRE_APPROACH", "ENTRY"}:
            stage_label = "ENTRY"
        elif stage_label in {"APPROACH", "FINAL_READY"}:
            stage_label = "FINAL_READY"
        else:
            stage_label = stage_label or "STAGING"
        task.pre_target_stage = stage_label
        amr.target_cell = next_cell
        if stage_label == "ENTRY" and task.pre_target_pre_approach_xy is not None:
            amr.target_xy = task.pre_target_pre_approach_xy
        elif stage_label == "FINAL_READY" and task.pre_target_approach_xy is not None:
            amr.target_xy = task.pre_target_approach_xy
        else:
            amr.target_xy = grid_to_world(next_cell)
        amr.wait_steps = 0
        amr.no_path_steps = 0
        self.release_random_goals_conflicting_with(next_cell, owner_name=amr.name, reason=f"pre_target_{stage_label.lower()}_reserved")
        if PRE_TARGET_WAIT_LOG_ENABLED:
            print(
                f"B_STAGE_RELEASE | {amr.name} task={task.command_id} stage={stage_label} "
                f"from={amr.cell} next={next_cell} final={task.target_cell} reason={reason} "
                f"lane={self.sg2_target_lane_id(task.target_location)} a_phase={self.same_lane_a_task_phase(task)}"
            )
            print(
                f"PRE_TARGET RELEASE TO {stage_label} | {amr.name} task={task.command_id} "
                f"from={amr.cell} next={next_cell} final={task.target_cell} reason={reason} "
                f"a_phase={self.same_lane_a_task_phase(task)}"
            )

    def release_pre_target_wait_to_final(self, task: CommandTask, amr: AmrState, now: float, reason: str):
        """Release a B-side AMR to its final B target.

        v23: this can be called from the approach cell as soon as A side-exit is
        reserved, not only after A reaches RETURN_HOME.  It never happens because
        of wait timeout.
        """
        task.pre_target_released = True
        task.pre_target_stage = "FINAL"
        if EARLY_B_FINAL_RELEASE_LOG_ENABLED:
            print(
                f"EARLY_FINAL_CHECK | {amr.name} task={task.command_id} decision=ALLOW reason={reason} "
                f"lane={self.sg2_target_lane_id(task.target_location)} a_phase={self.same_lane_a_task_phase(task)} "
                f"a_exit_reserved={self.same_lane_a_exit_move_reserved(task)} from={amr.cell} final={task.target_cell}"
            )
        task.phase = "TO_TARGET"
        task.phase_start = now
        amr.state = "TO_TARGET"

        next_cell = task.target_cell
        next_xy = task.target_xy
        amr.target_cell = next_cell
        amr.target_xy = next_xy
        amr.wait_steps = 0
        amr.no_path_steps = 0
        self.release_random_goals_conflicting_with(next_cell, owner_name=amr.name, reason="pre_target_final_target_reserved")
        if PRE_TARGET_WAIT_LOG_ENABLED:
            print(
                f"B_STAGE_RELEASE | {amr.name} task={task.command_id} stage=FINAL "
                f"from={amr.cell} next={next_cell} final={task.target_cell} reason={reason} "
                f"lane={self.sg2_target_lane_id(task.target_location)} a_phase={self.same_lane_a_task_phase(task)} "
                f"a_exit_reserved={self.same_lane_a_exit_move_reserved(task)}"
            )
            print(
                f"PRE_TARGET RELEASE TO FINAL | {amr.name} task={task.command_id} "
                f"from={amr.cell} next={next_cell} final={task.target_cell} reason={reason} "
                f"a_phase={self.same_lane_a_task_phase(task)} "
                f"a_exit_reserved={self.same_lane_a_exit_move_reserved(task)}"
            )

    def start_return_home_after_post_place_exit(self, task: CommandTask, amr: AmrState, now: float):
        if task.return_cell is not None and task.return_cell != amr.cell:
            task.phase = "RETURN_HOME"
            task.phase_start = now
            amr.state = "RETURN_HOME"
            amr.target_cell = task.return_cell
            amr.target_xy = task.return_xy if task.return_xy is not None else grid_to_world(task.return_cell)
            amr.wait_steps = 0
            amr.no_path_steps = 0
            self.release_random_goals_conflicting_with(task.return_cell, owner_name=amr.name, reason="task_return_home_reserved_after_post_place_exit")
            print(f"RETURN_HOME START | {amr.name} task={task.command_id} from={amr.cell} return={task.return_cell}")
            self.publish_status(task, "RETURNING")
        else:
            amr.task_id = None
            amr.state = "IDLE"
            amr.target_cell = None
            amr.target_xy = None
            self.finish_task(task, True, "completed")

    def start_post_place_choreography_or_return(self, task: CommandTask, amr: AmrState, now: float):
        behavior = self.resolve_post_place_behavior(task)
        if behavior in ("", "AUTO", "RETURN_HOME", "NONE"):
            self.start_return_home_after_post_place_exit(task, amr, now)
            return

        exit_cell = self.choose_post_place_exit_cell(task, amr, behavior)
        if exit_cell is None:
            print(f"POST_PLACE EXIT WARNING | {amr.name} task={task.command_id} behavior={behavior} no usable exit cell")
            if POST_PLACE_FALLBACK_TO_RETURN_HOME:
                self.start_return_home_after_post_place_exit(task, amr, now)
            else:
                amr.task_id = None
                amr.state = "IDLE"
                amr.target_cell = None
                amr.target_xy = None
                self.finish_task(task, False, "post-place exit cell unavailable")
            return

        task.post_place_behavior = behavior
        task.post_place_exit_cell = exit_cell
        task.post_place_exit_xy = grid_to_world(exit_cell)

        if behavior == "SIDE_EXIT":
            task.phase = "POST_PLACE_SIDE_EXIT"
            task.phase_start = now
            amr.state = "POST_PLACE_SIDE_EXIT"
            amr.target_cell = exit_cell
            amr.target_xy = task.post_place_exit_xy
            amr.wait_steps = 0
            amr.no_path_steps = 0
            if POST_PLACE_EXIT_LOG_ENABLED:
                print(f"POST_PLACE SIDE_EXIT START | {amr.name} task={task.command_id} from={amr.cell} exit={exit_cell}")
            self.publish_status(task, "RETURNING")
            return

        if behavior in ("TURN_180_AND_BACK_EXIT", "TURN_180", "BACK_EXIT"):
            if behavior == "BACK_EXIT":
                task.phase = "POST_PLACE_BACK_EXIT"
                amr.state = "POST_PLACE_BACK_EXIT"
                amr.target_cell = exit_cell
                amr.target_xy = task.post_place_exit_xy
                task.phase_start = now
                if POST_PLACE_EXIT_LOG_ENABLED:
                    print(f"POST_PLACE BACK_EXIT START | {amr.name} task={task.command_id} from={amr.cell} exit={exit_cell}")
                self.publish_status(task, "RETURNING")
                return

            task.post_place_turn_start_heading = amr.heading
            ex, ey = exit_cell
            cx, cy = amr.cell
            desired = normalize_move(ex - cx, ey - cy)
            if desired == (0, 0):
                desired = (-amr.heading[0], -amr.heading[1]) if amr.heading != (0, 0) else (-1, 0)
            task.post_place_turn_target_heading = desired
            task.phase = "POST_PLACE_TURN_180"
            task.phase_start = now
            amr.state = "POST_PLACE_TURN_180"
            amr.target_cell = None
            amr.target_xy = None
            self.clear_stale_motion_reservation(amr)
            if POST_PLACE_EXIT_LOG_ENABLED:
                print(f"POST_PLACE TURN_180 START | {amr.name} task={task.command_id} cell={amr.cell} target_heading={desired} exit={exit_cell}")
            self.publish_status(task, "RETURNING")
            return

        # Unknown explicit behavior: use safe legacy return-home.
        print(f"POST_PLACE BEHAVIOR WARNING | {amr.name} task={task.command_id} unknown={behavior}; fallback RETURN_HOME")
        self.start_return_home_after_post_place_exit(task, amr, now)

    def update_task_phases(self, now: float, dt: float):
        for task in list(self.tasks.values()):
            amr = self.amrs.get(task.amr_name or "")
            rack = self.racks.get(task.rack_key)
            if amr is None or rack is None:
                self.finish_task(task, False, "missing amr or rack")
                continue

            if task.phase == "TO_RACK":
                if amr.cell == rack.cell and not amr.is_moving():
                    task.phase = "LIFTING"
                    task.phase_start = now
                    amr.state = "LIFTING"
                    self.clear_stale_motion_reservation(amr)
                    self.publish_status(task, "PICKING")

            elif task.phase == "LIFTING":
                alpha = min((now - task.phase_start) / LIFT_DURATION_SEC, 1.0)
                ax, ay = get_object_center_xy(amr.obj)

                if RACK_DISABLE_RIGID_BODY_WHILE_CARRIED and not rack.physics_locked:
                    hard_disable_physics_subtree(rack.obj.prim, disable_collision=True)
                    rack.physics_locked = True
                    print(f"RACK HARD ATTACHED | {rack.key} physics/collision removed for carry")

                # Hard root lock: rack root follows AMR root center exactly during lift.
                set_object_center_xy(rack.obj, ax, ay, rack.obj.base_z + LIFT_HEIGHT_M * alpha)
                if alpha >= 1.0:
                    task.rack_attach_dx = 0.0
                    task.rack_attach_dy = 0.0
                    rack.carried_by = amr.name
                    amr.carrying_rack = rack.key
                    if task.action_mode == "ROTATE_WORKSTATION":
                        task.rotate_start_yaw = get_root_yaw_rad(rack.obj.prim)
                        task.rotate_target_yaw = normalize_angle_rad(task.rotate_start_yaw + ROTATE_WORKSTATION_DELTA_RAD)
                        amr.state = "ROTATING"
                        self.clear_stale_motion_reservation(amr)
                        amr.target_cell = None
                        amr.target_xy = None
                        task.phase = "ROTATING"
                        task.phase_start = now
                        self.publish_status(task, "NAVIGATING")
                    else:
                        # Guard again at lift completion. If the drop target is still
                        # the same QR cell as pickup, choose a real carry destination.
                        # v25: explicit SG2 A/B destinations are locked so an A target
                        # is not rewritten to B after the AMR briefly stops at A.
                        if not self.explicit_drop_target_locked(task.target_location, task.rack_key, task.target_cell):
                            task.target_xy, task.target_cell = self.enforce_drop_target_not_pickup(
                                task.command_id, task.rack_key, task.target_xy, task.target_cell
                            )
                        if self.start_local_macro_entry_if_available(task, amr, now):
                            pass
                        elif self.start_local_macro_wait(task, amr, now, reason="macro_route_not_available_after_lift"):
                            pass
                        elif (
                            SG_AB_PRE_TARGET_STAGING_ENABLED
                            and task.pre_target_wait_required
                            and task.pre_target_wait_cell is not None
                            and task.pre_target_wait_cell != task.target_cell
                        ):
                            task.pre_target_stage = "SAFE_WAIT"
                            amr.state = "TO_PRE_TARGET_WAIT"
                            amr.target_cell = task.pre_target_wait_cell
                            amr.target_xy = task.pre_target_wait_xy if task.pre_target_wait_xy is not None else grid_to_world(task.pre_target_wait_cell)
                            self.release_random_goals_conflicting_with(task.pre_target_wait_cell, owner_name=amr.name, reason="pre_target_wait_reserved")
                            task.phase = "TO_PRE_TARGET_WAIT"
                            task.phase_start = now
                            if PRE_TARGET_WAIT_LOG_ENABLED:
                                print(
                                    f"PRE_TARGET WAIT START | {amr.name} task={task.command_id} "
                                    f"wait_cell={task.pre_target_wait_cell} final={task.target_cell}"
                                )
                        else:
                            amr.state = "TO_TARGET"
                            amr.target_cell = task.target_cell
                            amr.target_xy = task.target_xy
                            self.release_random_goals_conflicting_with(task.target_cell, owner_name=amr.name, reason="task_drop_target_reserved")
                            task.phase = "TO_TARGET"
                            task.phase_start = now
                        self.publish_status(task, "NAVIGATING")

            elif task.phase == "ROTATING":
                alpha = min((now - task.phase_start) / ROTATE_DURATION_SEC, 1.0)
                ax, ay = get_object_center_xy(amr.obj)
                set_object_center_xy(rack.obj, ax, ay, rack.obj.base_z + LIFT_HEIGHT_M)
                yaw_now = normalize_angle_rad(task.rotate_start_yaw + ROTATE_WORKSTATION_DELTA_RAD * alpha)
                set_yaw_if_possible(rack.obj.prim, yaw_now)
                if alpha >= 1.0:
                    set_yaw_if_possible(rack.obj.prim, task.rotate_target_yaw)
                    task.phase = "PLACING"
                    task.phase_start = now
                    amr.state = "PLACING"
                    self.clear_stale_motion_reservation(amr)
                    self.publish_status(task, "PLACING")

            elif task.phase == "LOCAL_ENTRY_WAIT":
                if not amr.is_moving():
                    if self.start_local_macro_entry_if_available(task, amr, now):
                        pass
                    else:
                        # Keep waiting.  Do not fall back to old pre-target logic in strict mode.
                        amr.wait_steps += 1
                        if SG_LOCAL_MACRO_LOG_ENABLED and amr.wait_steps in (10, 20, 40, 80, 120):
                            print(
                                f"LOCAL_MACRO ENTRY WAITING | {amr.name} task={task.command_id} "
                                f"wait={amr.wait_steps} side={self.sg2_target_side(task.target_location)} final={task.target_cell}"
                            )

            elif task.phase == "LOCAL_ENTRY":
                self.advance_local_macro_entry(task, amr, now)

            elif task.phase == "LOCAL_EXIT":
                self.advance_local_macro_exit(task, amr, now)

            elif task.phase == "TO_PRE_TARGET_WAIT":
                if task.pre_target_wait_cell is None:
                    if self.pre_target_final_entry_allowed(task, amr):
                        self.release_pre_target_wait_to_final(task, amr, now, reason="no_wait_cell")
                    continue

                # v21/v22/v23 partial-entry staging:
                #   safe_wait -> pre_approach while A is PLACING or later
                #   pre_approach -> approach while A is side-exiting or later
                #   approach -> final only when A is RETURN_HOME/DONE
                current = amr.cell
                not_moving = not amr.is_moving()

                if current == task.pre_target_wait_cell and not_moving:
                    if (
                        task.pre_target_pre_approach_cell is not None
                        and task.pre_target_pre_approach_cell != task.pre_target_wait_cell
                        and self.pre_target_pre_approach_allowed(task, amr)
                    ):
                        task.pre_target_partial_released = True
                        self.route_pre_target_to_cell(
                            task,
                            amr,
                            now,
                            task.pre_target_pre_approach_cell,
                            "ENTRY",
                            reason="a_placing_or_later",
                        )
                    elif (
                        task.pre_target_pre_approach_cell is None
                        and task.pre_target_approach_cell is not None
                        and task.pre_target_approach_cell != task.pre_target_wait_cell
                        and self.pre_target_approach_allowed(task, amr)
                    ):
                        task.pre_target_approach_released = True
                        self.route_pre_target_to_cell(
                            task,
                            amr,
                            now,
                            task.pre_target_approach_cell,
                            "FINAL_READY",
                            reason="a_side_exit_or_later",
                        )
                    elif self.pre_target_final_entry_allowed(task, amr):
                        self.release_pre_target_wait_to_final(task, amr, now, reason="early_B_final_release_or_lane_a_done")
                    else:
                        amr.wait_steps = 0
                        amr.no_path_steps = 0
                        if PRE_TARGET_WAIT_LOG_ENABLED and (
                            task.last_status_at <= 0.0
                            or (now - task.last_status_at) >= max(1.0, float(PRE_TARGET_WAIT_LOG_PERIOD))
                        ):
                            task.last_status_at = now
                            print(
                                f"B_STAGE_HOLD | {amr.name} task={task.command_id} "
                                f"stage=SAFE_WAIT cell={amr.cell} final={task.target_cell} "
                                f"lane={self.sg2_target_lane_id(task.target_location)} "
                                f"a_phase={self.same_lane_a_task_phase(task)} reason=waiting_for_A_placing"
                            )

                elif (
                    task.pre_target_pre_approach_cell is not None
                    and current == task.pre_target_pre_approach_cell
                    and not_moving
                ):
                    if (
                        task.pre_target_approach_cell is not None
                        and task.pre_target_approach_cell != task.pre_target_pre_approach_cell
                        and self.pre_target_approach_allowed(task, amr)
                    ):
                        task.pre_target_approach_released = True
                        self.route_pre_target_to_cell(
                            task,
                            amr,
                            now,
                            task.pre_target_approach_cell,
                            "FINAL_READY",
                            reason="a_side_exit_or_later",
                        )
                    elif task.pre_target_approach_cell is None and self.pre_target_final_entry_allowed(task, amr):
                        self.release_pre_target_wait_to_final(task, amr, now, reason="early_B_final_release_or_lane_a_done")
                    else:
                        amr.wait_steps = 0
                        amr.no_path_steps = 0
                        if PRE_TARGET_WAIT_LOG_ENABLED and (
                            task.last_status_at <= 0.0
                            or (now - task.last_status_at) >= max(1.0, float(PRE_TARGET_WAIT_LOG_PERIOD))
                        ):
                            task.last_status_at = now
                            print(
                                f"B_STAGE_HOLD | {amr.name} task={task.command_id} "
                                f"stage=ENTRY cell={amr.cell} final={task.target_cell} "
                                f"lane={self.sg2_target_lane_id(task.target_location)} "
                                f"a_phase={self.same_lane_a_task_phase(task)} reason=waiting_for_A_side_exit"
                            )

                elif (
                    task.pre_target_approach_cell is not None
                    and current == task.pre_target_approach_cell
                    and not_moving
                ):
                    if self.pre_target_final_entry_allowed(task, amr):
                        self.release_pre_target_wait_to_final(task, amr, now, reason="early_B_final_release_or_lane_a_done")
                    else:
                        amr.wait_steps = 0
                        amr.no_path_steps = 0
                        if PRE_TARGET_WAIT_LOG_ENABLED and (
                            task.last_status_at <= 0.0
                            or (now - task.last_status_at) >= max(1.0, float(PRE_TARGET_WAIT_LOG_PERIOD))
                        ):
                            task.last_status_at = now
                            print(
                                f"B_STAGE_HOLD | {amr.name} task={task.command_id} "
                                f"stage=FINAL_READY cell={amr.cell} final={task.target_cell} "
                                f"lane={self.sg2_target_lane_id(task.target_location)} "
                                f"a_phase={self.same_lane_a_task_phase(task)} reason=waiting_for_A_exit_reserved"
                            )
                else:
                    # Still travelling to the current staging point.
                    pass

            elif task.phase == "TO_TARGET":
                # v13: if the AMR was temporarily routed to an escape/staging waypoint,
                # reaching that waypoint restores the original drop target instead of placing.
                if amr.target_cell is not None and amr.target_cell != task.target_cell and amr.cell == amr.target_cell and not amr.is_moving():
                    print(f"ESCAPE WAYPOINT DONE | {amr.name} task={task.command_id} at={amr.cell} resume_target={task.target_cell}")
                    amr.target_cell = task.target_cell
                    amr.target_xy = task.target_xy
                    amr.wait_steps = 0
                    amr.no_path_steps = 0
                    continue

                if amr.cell == task.target_cell and not amr.is_moving():
                    task.phase = "PLACING"
                    task.phase_start = now
                    amr.state = "PLACING"
                    self.clear_stale_motion_reservation(amr)
                    self.publish_status(task, "PLACING")

            elif task.phase == "PLACING":
                alpha = min((now - task.phase_start) / PLACE_DURATION_SEC, 1.0)
                ax, ay = get_object_center_xy(amr.obj)
                set_object_center_xy(rack.obj, ax, ay, rack.obj.base_z + LIFT_HEIGHT_M * (1.0 - alpha))
                if alpha >= 1.0:
                    set_object_center_xy(rack.obj, task.target_xy[0], task.target_xy[1], rack.obj.base_z)
                    if abs(task.target_yaw) > 1e-6:
                        set_yaw_if_possible(rack.obj.prim, task.target_yaw)
                    rack.cell = task.target_cell
                    rack.carried_by = None
                    rack.assigned = False
                    # Keep rack physics disabled after placement for demo stability.
                    # The planner still treats placed racks as software obstacles.
                    if not RACK_KEEP_COLLISION_DISABLED_AFTER_PLACE:
                        set_collision_enabled_subtree(rack.obj.prim, True)
                    else:
                        hard_disable_physics_subtree(rack.obj.prim, disable_collision=True)

                    amr.carrying_rack = None
                    self.clear_stale_motion_reservation(amr)
                    self.mark_delivery_done(task, rack, amr, now, reason="rack_detached_at_target")

                    # v27 local macro route: leave the SG bay by reversing the entry
                    # macro if one was used.  This is intentionally deterministic and
                    # avoids re-planning inside the narrow SG A/B area.
                    if not self.start_local_macro_exit_if_available(task, amr, now):
                        # v17 post-place choreography fallback.
                        self.start_post_place_choreography_or_return(task, amr, now)

            elif task.phase == "POST_PLACE_TURN_180":
                alpha = min((now - task.phase_start) / max(POST_PLACE_TURN_DURATION_SEC, 1e-3), 1.0)
                # Discrete heading is switched at the end; visual yaw is held stable
                # during the timed phase to avoid fighting transform interpolation.
                if alpha >= 1.0:
                    target_heading = task.post_place_turn_target_heading
                    if target_heading == (0, 0):
                        target_heading = (-amr.heading[0], -amr.heading[1]) if amr.heading != (0, 0) else (-1, 0)
                    amr.heading = target_heading
                    set_amr_yaw_to_movement(amr)
                    if task.post_place_exit_cell is not None:
                        task.phase = "POST_PLACE_BACK_EXIT"
                        task.phase_start = now
                        amr.state = "POST_PLACE_BACK_EXIT"
                        amr.target_cell = task.post_place_exit_cell
                        amr.target_xy = task.post_place_exit_xy if task.post_place_exit_xy is not None else grid_to_world(task.post_place_exit_cell)
                        amr.wait_steps = 0
                        amr.no_path_steps = 0
                        if POST_PLACE_EXIT_LOG_ENABLED:
                            print(f"POST_PLACE BACK_EXIT START | {amr.name} task={task.command_id} from={amr.cell} exit={task.post_place_exit_cell}")
                    else:
                        self.start_return_home_after_post_place_exit(task, amr, now)

            elif task.phase in ("POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT"):
                if task.post_place_exit_cell is None:
                    self.start_return_home_after_post_place_exit(task, amr, now)
                elif amr.cell == task.post_place_exit_cell and not amr.is_moving():
                    if POST_PLACE_EXIT_LOG_ENABLED:
                        print(f"POST_PLACE EXIT DONE | {amr.name} task={task.command_id} behavior={task.post_place_behavior} cell={amr.cell}")
                    if SG_LOCAL_MACRO_DISABLE_A_EXIT_HOLD:
                        self.start_return_home_after_post_place_exit(task, amr, now)
                    elif not self.start_a_exit_hold_if_needed(task, amr, now):
                        self.start_return_home_after_post_place_exit(task, amr, now)

            elif task.phase == "POST_PLACE_EXIT_HOLD":
                if self.same_lane_b_needs_a_exit_hold(task):
                    amr.wait_steps = 0
                    amr.no_path_steps = 0
                    if A_EXIT_HOLD_LOG_ENABLED and (
                        task.last_status_at <= 0.0
                        or (now - task.last_status_at) >= max(1.0, float(PRE_TARGET_WAIT_LOG_PERIOD))
                    ):
                        task.last_status_at = now
                        b_task = self.same_lane_b_task(task)
                        print(
                            f"A_EXIT_HOLD WAIT | {amr.name} task={task.command_id} cell={amr.cell} "
                            f"lane={self.sg2_target_lane_id(task.target_location)} "
                            f"b_task={b_task.command_id if b_task else None} b_phase={b_task.phase if b_task else 'DONE'} "
                            f"b_stage={getattr(b_task, 'pre_target_stage', '') if b_task else ''}"
                        )
                else:
                    if A_EXIT_HOLD_LOG_ENABLED:
                        print(f"A_EXIT_HOLD DONE | {amr.name} task={task.command_id} cell={amr.cell} resume_return=True")
                    self.start_return_home_after_post_place_exit(task, amr, now)

            elif task.phase == "RETURN_HOME":
                if amr.cell == task.return_cell and not amr.is_moving():
                    amr.task_id = None
                    amr.state = "IDLE"
                    amr.target_cell = None
                    amr.target_xy = None
                    amr.wait_steps = 0
                    amr.no_path_steps = 0
                    print(f"RETURN_HOME DONE | {amr.name} task={task.command_id} cell={amr.cell}")
                    resume_task_id = task.resume_task_id
                    if task.internal and resume_task_id:
                        resume_task = self.tasks.get(resume_task_id)
                        if resume_task is not None:
                            print(f"RETURN_HOME RESUME DONE | {amr.name} clearance={task.command_id} completed_paused={resume_task_id}")
                            self.finish_task(resume_task, True, "completed_returned_home_after_lane_clearance")
                    self.finish_task(task, True, "completed_returned_home")

            elif task.phase == "RETURN_HOME_PAUSED":
                # Waiting for a preempting internal lane-clearance task to return this AMR home.
                pass

    def publish_status(self, task: CommandTask, status: str):
        if task.internal:
            return
        now = time.time()
        if now - task.last_status_at < STATUS_PERIOD_SEC and status not in ["PICKING", "PLACING", "RETURNING"]:
            return
        task.last_status_at = now
        amr = self.amrs.get(task.amr_name or "")
        dist = 0.0
        if amr is not None:
            if task.phase in ["LOCAL_ENTRY", "LOCAL_EXIT", "TO_TARGET", "PLACING"]:
                target = task.target_xy
            elif task.phase == "RETURN_HOME" and task.return_xy is not None:
                target = task.return_xy
            else:
                target = grid_to_world(self.racks[task.rack_key].cell)
            dist = distance_xy(get_xy(amr.obj.prim), target)
        safe_write_json(STATUS_DIR / f"{task.command_id}.json", {
            "command_id": task.command_id,
            "status": status,
            "distance_remaining": float(dist),
            "amr_name": task.amr_name,
            "rack_key": task.rack_key,
            "phase": task.phase,
            "pre_target_stage": getattr(task, "pre_target_stage", ""),
            "local_route_mode": getattr(task, "local_route_mode", ""),
            "local_entry_route": [list(c) for c in getattr(task, "local_entry_route", [])],
            "local_exit_route": [list(c) for c in getattr(task, "local_exit_route", [])],
            "delivery_done": bool(getattr(task, "delivery_done", False)),
            "delivery_done_at": float(getattr(task, "delivery_done_at", 0.0)),
            "task_done": bool(getattr(task, "task_done", False)),
            "task_done_at": float(getattr(task, "task_done_at", 0.0)),
            "updated_at": now,
        })

    def finish_task(self, task: CommandTask, success: bool, message: str):
        task.task_done = bool(success)
        task.task_done_at = time.time()
        if success:
            print(f"TASK_DONE | task={task.command_id} amr={task.amr_name} delivery_done={task.delivery_done} task_done_at={task.task_done_at:.3f} message={message}")
        if not task.internal:
            safe_write_json(RESULT_DIR / f"{task.command_id}.json", {
                "command_id": task.command_id,
                "success": bool(success),
                "status": "COMPLETED" if success else "FAILED",
                "message": message,
                "amr_name": task.amr_name,
                "rack_key": task.rack_key,
                "action_mode": task.action_mode,
                "return_cell": list(task.return_cell) if task.return_cell is not None else None,
                "local_route_mode": getattr(task, "local_route_mode", ""),
                "delivery_done": bool(getattr(task, "delivery_done", False)),
                "delivery_done_at": float(getattr(task, "delivery_done_at", 0.0)),
                "task_done": bool(getattr(task, "task_done", False)),
                "task_done_at": float(getattr(task, "task_done_at", 0.0)),
                "finished_at": time.time(),
            })
        if task.command_id in self.tasks:
            del self.tasks[task.command_id]
        print(f"TASK RESULT | {task.command_id} success={success} message={message}")

    # --------------------------------------------------------
    # Planning and motion
    # --------------------------------------------------------
    def rack_dynamic_four_way_zone_cells(self, center: GridCell, include_center: bool = True) -> Set[GridCell]:
        """Cells where diagonal movement is forbidden near live workstations.

        v41 policy: these cells are NOT obstacles and are NOT reservations.
        They only force 4-way movement when a move enters/leaves/crosses the zone.
        radius=1 gives center + surrounding 8 cells.
        """
        cells: Set[GridCell] = set()
        if not RACK_DYNAMIC_FOUR_WAY_ZONE_ENABLED or not RACK_DYNAMIC_SAFETY_ZONE_ENABLED:
            if include_center:
                cells.add(center)
            return cells
        r = max(0, int(RACK_DYNAMIC_FOUR_WAY_RADIUS_CELLS))
        cx, cy = center
        for dx in range(-r, r + 1):
            for dy in range(-r, r + 1):
                if not include_center and dx == 0 and dy == 0:
                    continue
                cells.add((cx + dx, cy + dy))
        return cells

    # Backward-compatible method name used by older debug helpers.
    # In v41 this returns four-way-only zone cells, not obstacle cells.
    def rack_dynamic_safety_cells(self, center: GridCell, include_center: bool = True) -> Set[GridCell]:
        return self.rack_dynamic_four_way_zone_cells(center, include_center=include_center)

    def rack_dynamic_safety_cells_for_task_exception(self, amr: AmrState, rack: RackState, allow_assigned_rack: bool) -> bool:
        if not allow_assigned_rack or not amr.task_id:
            return False
        task = self.tasks.get(amr.task_id)
        return bool(task and rack.key == task.rack_key and amr.state == "TO_RACK")

    def rack_live_near_zone_cells(self) -> Set[GridCell]:
        # v41: dynamic live four-way zone.  This follows both stationary racks
        # and racks currently carried by AMRs.  The returned cells are passable,
        # but diagonal moves through/around them are rejected by the planner/arbiter.
        cells: Set[GridCell] = set(self.rack_four_way_cells)
        if RACK_DYNAMIC_FOUR_WAY_ZONE_ENABLED and RACK_DYNAMIC_SAFETY_ZONE_ENABLED:
            for rack in self.racks.values():
                center = rack.cell
                if rack.carried_by:
                    carrier = self.amrs.get(rack.carried_by)
                    if carrier is not None:
                        center = carrier.cell
                cells.update(self.rack_dynamic_four_way_zone_cells(center, include_center=True))
        return cells

    def refresh_dynamic_four_way_global_cells(self):
        global GLOBAL_RACK_FOUR_WAY_CELLS
        GLOBAL_RACK_FOUR_WAY_CELLS = set(self.rack_live_near_zone_cells())

    def static_obstacles_for(self, amr: AmrState, allow_assigned_rack: bool) -> Set[GridCell]:
        obstacles: Set[GridCell] = set()

        # v41 dynamic rack policy.
        # Only the workstation center cell is a hard obstacle.  The surrounding
        # 8 cells remain passable, but diagonal movement inside/crossing that
        # neighborhood is forbidden through rack_live_near_zone_cells().
        # Exception: the assigned pickup workstation is excluded during TO_RACK so
        # the AMR can enter the center cell and lift it.
        for rack in self.racks.values():
            if rack.carried_by is not None:
                continue
            if self.rack_dynamic_safety_cells_for_task_exception(amr, rack, allow_assigned_rack):
                continue
            obstacles.add(rack.cell)
        return obstacles


    def congestion_priority_score(self, name: str) -> float:
        """Priority score for dense 5-AMR arbitration.

        Previous policy always put carrying AMRs first. That is safe, but with 5
        simultaneous tasks it can starve empty AMRs that need to reach a rack,
        producing a visual freeze of AMR_01~AMR_03. This score keeps carrying
        priority, but adds bounded aging so a robot that has waited for many
        ticks eventually gets a chance to move if the normal safety gates allow it.

        v22 adds a generic role score, not a lane-specific exception:
        loaded delivery/approach AMRs are planned before empty return-home AMRs,
        so Reservation Table A* can reserve the delivery corridor first.
        """
        amr = self.amrs[name]
        score = 0.0
        if amr.state != "RANDOM":
            score += 100.0
        if amr.carrying_rack:
            score += 45.0
        if GENERIC_CONFLICT_ZONE_YIELD_ENABLED:
            score += self.generic_role_priority_score(name)
        if CONGESTION_AGING_ENABLED:
            waited = min(float(getattr(amr, "wait_steps", 0)), float(CONGESTION_WAIT_PRIORITY_CAP))
            score += waited
            if amr.state == "TO_RACK" and waited >= CONGESTION_TO_RACK_EXTRA_BOOST_AFTER:
                score += float(CONGESTION_TO_RACK_EXTRA_BOOST)
        return score

    def task_for_amr_name(self, name: str) -> Optional[CommandTask]:
        amr = self.amrs.get(name)
        if amr is None or not amr.task_id:
            return None
        return self.tasks.get(amr.task_id)

    def is_empty_return_candidate(self, name: str) -> bool:
        amr = self.amrs.get(name)
        return bool(
            amr is not None
            and amr.state == "RETURN_HOME"
            and not amr.carrying_rack
        )

    def is_loaded_delivery_priority_candidate(self, name: str) -> bool:
        """Generic role test for delivery AMRs that should not be blocked by empty return.

        This is intentionally independent of a specific lane, target index, or AMR name.
        It is true for any loaded AMR currently moving toward a staging/approach/final
        delivery cell, including A and B targets.
        """
        amr = self.amrs.get(name)
        if amr is None or not amr.carrying_rack:
            return False
        if amr.state not in {"LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET"}:
            return False
        task = self.task_for_amr_name(name)
        if task is None:
            return True
        if task.phase not in {"LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "PLACING"}:
            return False
        return True

    def generic_role_priority_score(self, name: str) -> float:
        """Role-based priority used by both planning order and arbiter order.

        The rule is generic: loaded delivery > empty return.  No SG1/SG2/SG3
        exception, AMR name exception, or target-name exception is used.
        """
        amr = self.amrs.get(name)
        if amr is None:
            return 0.0
        score = 0.0
        if self.is_loaded_delivery_priority_candidate(name):
            score += LOADED_DELIVERY_ROLE_PRIORITY_BOOST
            task = self.task_for_amr_name(name)
            if task is not None and task.phase == "TO_TARGET":
                score += LOADED_B_FINAL_ROLE_PRIORITY_BOOST
        if self.is_empty_return_candidate(name):
            score -= EMPTY_RETURN_ROLE_PRIORITY_PENALTY
        return score

    def generic_conflict_zone_cells_for_loaded_delivery(
        self,
        name: str,
        proposals: Dict[str, GridCell],
        path2: Optional[Dict[str, Optional[GridCell]]] = None,
    ) -> Set[GridCell]:
        """Return near-future cells that an empty return AMR should not enter.

        The zone is derived from the loaded AMR's current proposal/second step/goal,
        not from a hard-coded lane.  This is a generic conflict-zone approximation
        layered on top of Reservation Table A*.
        """
        path2 = path2 or {}
        amr = self.amrs.get(name)
        if amr is None:
            return set()
        cells: Set[GridCell] = set()
        dst = proposals.get(name)
        if dst is not None:
            cells.add(dst)
        second = path2.get(name)
        if GENERIC_CONFLICT_ZONE_SECOND_STEP_ENABLED and second is not None:
            cells.add(second)
        if amr.target_cell is not None:
            # Include the final/active sub-goal so empty AMRs do not cut into the
            # immediate delivery funnel while the loaded AMR is approaching it.
            cells.add(amr.target_cell)
        return cells

    def empty_return_yield_to_loaded_delivery(
        self,
        name: str,
        src: GridCell,
        dst: GridCell,
        proposals: Dict[str, GridCell],
        path2: Optional[Dict[str, Optional[GridCell]]] = None,
    ) -> Optional[str]:
        """Generic yield rule: empty RETURN_HOME must not enter loaded delivery zones.

        The empty AMR is rejected only if its proposed move moves into or stays inside
        the loaded delivery AMR's near-future conflict zone.  If the empty AMR is
        already close but moving away, it is allowed to clear the area.
        """
        if not GENERIC_CONFLICT_ZONE_YIELD_ENABLED:
            return None
        if not self.is_empty_return_candidate(name):
            return None

        radius = max(0, int(GENERIC_CONFLICT_ZONE_RADIUS_CELLS))
        for other_name in proposals.keys():
            if other_name == name:
                continue
            if not self.is_loaded_delivery_priority_candidate(other_name):
                continue
            conflict_cells = self.generic_conflict_zone_cells_for_loaded_delivery(other_name, proposals, path2)
            if not conflict_cells:
                continue
            old_dist = min(cell_chebyshev_distance(src, c) for c in conflict_cells)
            new_dist = min(cell_chebyshev_distance(dst, c) for c in conflict_cells)

            # Yield only when entering/staying in the loaded delivery zone.  If the
            # return AMR is moving away from that zone, allow it so it can clear space.
            if new_dist <= radius and new_dist <= old_dist:
                if GENERIC_CONFLICT_ZONE_LOG_ENABLED:
                    amr = self.amrs.get(name)
                    should_log = True
                    if amr is not None and EMPTY_RETURN_YIELD_LOG_PERIOD > 0:
                        should_log = amr.wait_steps in (0, 1, 5, 10) or amr.wait_steps % EMPTY_RETURN_YIELD_LOG_PERIOD == 0
                    if should_log:
                        print(
                            f"GENERIC CONFLICT-ZONE YIELD | empty_return={name} {src}->{dst} "
                            f"yield_to={other_name} zones={sorted(conflict_cells)} "
                            f"old_dist={old_dist} new_dist={new_dist}"
                        )
                return f"generic_empty_return_yield_to_{other_name}"
        return None

    def is_manual_first_step_safe(self, name: str, dst: GridCell, allow_current_vacate: Optional[Set[GridCell]] = None) -> bool:
        """Conservative validator for a locally rewritten one-step proposal.

        This is not a replacement for global_move_arbiter().  It only prevents the
        lane-spread heuristic from proposing obviously invalid cells.  The arbiter
        still decides the final approved set with the existing collision rules.
        """
        allow_current_vacate = allow_current_vacate or set()
        amr = self.amrs[name]
        src = amr.cell
        move = normalize_move(dst[0] - src[0], dst[1] - src[1])
        if move == (0, 0):
            return False
        if cell_chebyshev_distance(src, dst) != 1:
            return False
        if QR_ONLY_NAVIGATION and self.valid_qr_cells and dst not in self.valid_qr_cells:
            return False
        if amr.carrying_rack and is_diagonal_move(move):
            return False
        if not amr.carrying_rack and self.must_use_four_way_near_rack(src, dst) and is_diagonal_move(move):
            return False

        # Exact current-cell occupancy is normally not allowed.  The only exception
        # here is when the cell belongs to another AMR in the same spread group and
        # that AMR is also being explicitly moved away by this heuristic; the normal
        # tail-release/arbiter checks will still make the final call.
        for other_name, other in self.amrs.items():
            if other_name == name:
                continue
            if other.cell == dst and dst not in allow_current_vacate:
                return False
            if other.is_moving() and other.move_to == dst:
                return False

        if amr.carrying_rack:
            obstacles = self.static_obstacles_for(amr, allow_assigned_rack=False)
            for c in self.planner.rack_occupied_cells(dst, move, amr.target_cell):
                if c in obstacles and c != amr.target_cell:
                    return False
                # Do not create a rack-footprint overlap with a stationary AMR.  Its
                # own source cell is allowed because the rack is moving with it.
                for other_name, other in self.amrs.items():
                    if other_name == name:
                        continue
                    if other.cell == c and c not in allow_current_vacate:
                        return False
                    if other.is_moving() and other.move_to == c:
                        return False
        return True

    def goal_biased_cardinal_candidates(self, name: str) -> List[GridCell]:
        amr = self.amrs[name]
        if amr.target_cell is None:
            return []
        x, y = amr.cell
        gx, gy = amr.target_cell
        primary: List[Move] = []
        if gx > x:
            primary.append((1, 0))
        elif gx < x:
            primary.append((-1, 0))
        if gy > y:
            primary.append((0, 1))
        elif gy < y:
            primary.append((0, -1))
        # Keep all four cardinal moves as fallback, but prefer goal-reducing moves.
        moves: List[Move] = []
        for m in primary + [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            if m not in moves:
                moves.append(m)
        return [(x + dx, y + dy) for dx, dy in moves]

    def is_90_turn_move(self, amr: AmrState, dst: GridCell) -> bool:
        move = normalize_move(dst[0] - amr.cell[0], dst[1] - amr.cell[1])
        if move == (0, 0) or amr.heading == (0, 0):
            return False
        return (amr.heading[0] * move[0] + amr.heading[1] * move[1]) == 0

    def bottleneck_turn_priority_score(self, name: str, dst: GridCell) -> float:
        if not BOTTLENECK_TURN_FIRST_ENABLED:
            return 0.0
        amr = self.amrs[name]
        waited = max(int(getattr(amr, "wait_steps", 0)), int(getattr(amr, "no_path_steps", 0)))
        predicted = self.predicted_bottleneck_for_amr(name, dst)
        if waited < BOTTLENECK_TURN_FIRST_WAIT_THRESHOLD and not predicted:
            return 0.0
        move = normalize_move(dst[0] - amr.cell[0], dst[1] - amr.cell[1])
        if move == (0, 0) or amr.heading == (0, 0):
            return 0.0
        dot = amr.heading[0] * move[0] + amr.heading[1] * move[1]
        if dot == 0:
            pre_bonus = PREEMPTIVE_TURN_PRIORITY_BONUS if predicted else 0.0
            return BOTTLENECK_TURN_PRIORITY_BONUS + pre_bonus + float(min(waited, 120))
        if move == amr.heading:
            return -BOTTLENECK_TURN_PRIORITY_BONUS * 0.25
        if dot < 0:
            return -BOTTLENECK_TURN_PRIORITY_BONUS * 0.50
        return 0.0

    def local_density_score(self, cell: GridCell, ignore_names: Optional[Set[str]] = None) -> int:
        ignore_names = ignore_names or set()
        score = 0
        for other_name, other in self.amrs.items():
            if other_name in ignore_names:
                continue
            if cell_chebyshev_distance(cell, other.cell) <= 1:
                score += 1
            if other.is_moving() and other.move_to is not None and cell_chebyshev_distance(cell, other.move_to) <= 1:
                score += 1
        for rack in self.racks.values():
            if rack.carried_by is None and cell_chebyshev_distance(cell, rack.cell) <= 1:
                score += 1
        return score

    def loaded_neighbor_count(self, name: str, radius: int = 2) -> int:
        amr = self.amrs[name]
        count = 0
        for other_name, other in self.amrs.items():
            if other_name == name:
                continue
            if not other.carrying_rack:
                continue
            if cell_chebyshev_distance(amr.cell, other.cell) <= radius:
                count += 1
            elif other.is_moving() and other.move_to is not None and cell_chebyshev_distance(amr.cell, other.move_to) <= radius:
                count += 1
        return count

    def same_column_loaded_group_size(self, name: str, y_window: int = 2) -> int:
        amr = self.amrs[name]
        x, y = amr.cell
        count = 0
        for other in self.amrs.values():
            if not other.carrying_rack:
                continue
            ox, oy = other.cell
            if ox == x and abs(oy - y) <= y_window:
                count += 1
        return count

    def predicted_bottleneck_for_amr(self, name: str, dst: Optional[GridCell] = None) -> bool:
        if not PREEMPTIVE_TURN_FIRST_ENABLED:
            return False
        amr = self.amrs[name]
        if amr.is_moving():
            return False
        if amr.state not in ["LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT", "POST_PLACE_EXIT_HOLD", "RETURN_HOME", "TO_RACK"]:
            return False
        if PREEMPTIVE_TURN_ONLY_CARRYING and not amr.carrying_rack:
            return False

        loaded_neighbors = self.loaded_neighbor_count(name, radius=2)
        if loaded_neighbors >= PREEMPTIVE_TURN_LOADED_NEIGHBOR_THRESHOLD:
            return True

        if amr.carrying_rack and self.same_column_loaded_group_size(name, y_window=2) >= PREEMPTIVE_TURN_SAME_COLUMN_GROUP_SIZE:
            return True

        density_cell = dst if dst is not None else amr.cell
        if self.local_density_score(density_cell, {name}) >= PREEMPTIVE_TURN_LOCAL_DENSITY_THRESHOLD:
            return True

        return False

    def turn_candidates_for(self, name: str) -> List[GridCell]:
        amr = self.amrs[name]
        hx, hy = amr.heading
        if (hx, hy) == (0, 0):
            return []
        x, y = amr.cell
        left = (-hy, hx)
        right = (hy, -hx)
        candidates = [(x + left[0], y + left[1]), (x + right[0], y + right[1])]
        if amr.target_cell is not None:
            # Prefer the turn that does not badly regress from the goal and that moves
            # into the less dense local area. This keeps the rule general while still
            # matching the observed SG2 jam where the middle AMR should rotate/yield
            # instead of driving straight one more cell.
            candidates.sort(key=lambda c: (
                self.local_density_score(c, {name}),
                cell_manhattan_distance(c, amr.target_cell),
                c[0],
                c[1],
            ))
        return candidates

    def apply_bottleneck_turn_first_overrides(self, proposals: Dict[str, GridCell], path2: Dict[str, Optional[GridCell]]):
        """Prefer a 90-degree turn over straight movement in a real bottleneck.

        This is broader than the specific AMR_01/02/03 lane-spread rule.  It only
        activates after an AMR has accumulated wait/no_path steps, and it only
        rewrites a one-step proposal if a safe 90-degree candidate exists.  The
        global arbiter still performs the final safety decision.
        """
        if not BOTTLENECK_TURN_FIRST_ENABLED:
            return

        changed: List[str] = []
        for name in sorted(proposals.keys()):
            amr = self.amrs[name]
            if amr.is_moving() or amr.state not in ["LOCAL_ENTRY_WAIT", "LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT", "POST_PLACE_EXIT_HOLD", "RETURN_HOME", "TO_RACK"]:
                continue
            waited = max(int(getattr(amr, "wait_steps", 0)), int(getattr(amr, "no_path_steps", 0)))
            dst = proposals.get(name)
            predicted = self.predicted_bottleneck_for_amr(name, dst)
            if waited < BOTTLENECK_TURN_FIRST_WAIT_THRESHOLD and not predicted:
                continue
            if dst is None or dst == amr.cell:
                continue
            move = normalize_move(dst[0] - amr.cell[0], dst[1] - amr.cell[1])
            if amr.heading == (0, 0):
                continue
            # Already turning: keep it.
            if (amr.heading[0] * move[0] + amr.heading[1] * move[1]) == 0:
                continue
            # Do not turn-first when the next straight step is already the final goal.
            if amr.target_cell is not None and dst == amr.target_cell:
                continue

            vacating_cells = {a.cell for a in self.amrs.values() if a.name in proposals}
            for cand in self.turn_candidates_for(name):
                if not self.is_manual_first_step_safe(name, cand, allow_current_vacate=vacating_cells):
                    continue
                if amr.target_cell is not None:
                    # Allow a small detour, but do not select a turn that explodes the
                    # distance to the actual task target.
                    now_d = cell_manhattan_distance(amr.cell, amr.target_cell)
                    cand_d = cell_manhattan_distance(cand, amr.target_cell)
                    max_regression = PREEMPTIVE_TURN_MAX_GOAL_REGRESSION if predicted else 2
                    if cand_d > now_d + max_regression:
                        continue
                proposals[name] = cand
                path2[name] = None
                changed.append(f"{name}:{amr.cell}->{cand}")
                break

        if changed:
            max_wait = max(max(self.amrs[n].wait_steps, self.amrs[n].no_path_steps) for n in proposals.keys())
            if max_wait % BOTTLENECK_TURN_FIRST_LOG_PERIOD == 0 or max_wait <= BOTTLENECK_TURN_FIRST_WAIT_THRESHOLD + 2:
                print("PREEMPTIVE/BOTTLENECK TURN FIRST | " + ", ".join(changed))

    def apply_loaded_lane_spread_overrides(self, proposals: Dict[str, GridCell], path2: Dict[str, Optional[GridCell]]):
        """Rewrite only the first step of a tight loaded queue.

        User-requested behavior for the observed 5-AMR SG2 jam:
        - AMR_01 / center blocker should not go straight one more cell into the lane.
          It should yield left/outward.
        - AMR_02 should continue straight toward the open side.
        - AMR_03 should turn toward its destination instead of waiting behind the
          middle blocker.

        The rule is deliberately narrow: it activates only when at least three
        carrying TO_TARGET AMRs are stopped on the same x-column in adjacent y cells.
        """
        if not LOADED_LANE_SPREAD_ENABLED:
            return

        candidates = []
        for name, amr in self.amrs.items():
            if name not in proposals:
                continue
            if amr.is_moving() or not amr.carrying_rack:
                continue
            if amr.state != "TO_TARGET":
                continue
            if (
                amr.wait_steps < LOADED_LANE_SPREAD_WAIT_THRESHOLD
                and amr.no_path_steps < LOADED_LANE_SPREAD_WAIT_THRESHOLD
                and not self.predicted_bottleneck_for_amr(name, proposals.get(name))
            ):
                continue
            candidates.append((name, amr.cell))

        if len(candidates) < LOADED_LANE_SPREAD_MIN_GROUP_SIZE:
            return

        by_x: Dict[int, List[Tuple[int, str]]] = {}
        for name, (x, y) in candidates:
            by_x.setdefault(x, []).append((y, name))

        for x, items in by_x.items():
            if len(items) < LOADED_LANE_SPREAD_MIN_GROUP_SIZE:
                continue
            items.sort()
            # Find the densest consecutive triple in this column.
            for i in range(len(items) - 2):
                triple = items[i:i + 3]
                ys = [v[0] for v in triple]
                if ys[2] - ys[0] > 2:
                    continue
                lower_name = triple[0][1]
                middle_name = triple[1][1]
                upper_name = triple[2][1]
                lower = self.amrs[lower_name]
                middle = self.amrs[middle_name]
                upper = self.amrs[upper_name]

                # If AMR_01/02/03 are exactly involved, follow the user's intended
                # choreography explicitly: AMR_01 yields left, AMR_02 goes straight
                # to the right/east side, AMR_03 turns/proceeds toward the right/east
                # side.  Otherwise apply the same center-yield/general spread rule.
                desired: Dict[str, List[GridCell]] = {}
                group_names = {lower_name, middle_name, upper_name}
                if {"AMR_01", "AMR_02", "AMR_03"}.issubset(group_names):
                    for n in ["AMR_01", "AMR_02", "AMR_03"]:
                        a = self.amrs[n]
                        ax, ay = a.cell
                        if n == "AMR_01":
                            desired[n] = [(ax - 1, ay), (ax + 1, ay)] + self.goal_biased_cardinal_candidates(n)
                        elif n == "AMR_02":
                            desired[n] = [(ax + 1, ay)] + self.goal_biased_cardinal_candidates(n)
                        elif n == "AMR_03":
                            desired[n] = [(ax + 1, ay)] + self.goal_biased_cardinal_candidates(n)
                else:
                    # Generic fallback: middle AMR yields outward/left if possible;
                    # lower and upper AMRs prefer the SG2/right side when their target
                    # is to the right, otherwise their normal goal-biased cardinal move.
                    mx, my = middle.cell
                    desired[middle_name] = [(mx - 1, my), (mx + 1, my)] + self.goal_biased_cardinal_candidates(middle_name)
                    for n in (lower_name, upper_name):
                        a = self.amrs[n]
                        ax, ay = a.cell
                        if a.target_cell and a.target_cell[0] > ax:
                            desired[n] = [(ax + 1, ay)] + self.goal_biased_cardinal_candidates(n)
                        else:
                            desired[n] = self.goal_biased_cardinal_candidates(n)

                vacating_cells = {self.amrs[n].cell for n in desired.keys()}
                changed: List[str] = []
                for n, cells in desired.items():
                    for dst in cells:
                        if self.is_manual_first_step_safe(n, dst, allow_current_vacate=vacating_cells):
                            if proposals.get(n) != dst:
                                proposals[n] = dst
                                path2[n] = None
                                changed.append(f"{n}:{self.amrs[n].cell}->{dst}")
                            break

                if changed:
                    max_wait = max(self.amrs[n].wait_steps for n in desired.keys())
                    if max_wait % LOADED_LANE_SPREAD_LOG_PERIOD == 0 or max_wait <= LOADED_LANE_SPREAD_WAIT_THRESHOLD + 2:
                        print("LOADED LANE SPREAD | " + ", ".join(changed))
                    return

    def endpoint_clear_for_escape(self, name: str, candidate: GridCell) -> bool:
        amr = self.amrs[name]
        if QR_ONLY_NAVIGATION and self.valid_qr_cells and candidate not in self.valid_qr_cells:
            return False
        if candidate == amr.cell:
            return False
        static_obstacles = self.static_obstacles_for(amr, allow_assigned_rack=False)
        if candidate in static_obstacles:
            return False
        move = normalize_move(candidate[0] - amr.cell[0], candidate[1] - amr.cell[1])
        if amr.carrying_rack and is_diagonal_move(move):
            return False
        # Check endpoint footprint with full side clearance even when candidate is the
        # temporary goal. This avoids the normal final-goal relaxation from allowing
        # an escape waypoint whose carried rack would overlap a stationary rack/AMR.
        footprint_move = move if move != (0, 0) else amr.heading
        for c in self.planner.rack_occupied_cells(candidate, footprint_move, None):
            if c in static_obstacles:
                return False
            for other_name, other in self.amrs.items():
                if other_name == name:
                    continue
                # If another AMR is actually moving away from its current cell, do not
                # treat that old cell as a permanent endpoint blocker; do block its move_to.
                if other.is_moving():
                    if other.move_to == c:
                        return False
                elif other.cell == c:
                    return False
        return True

    def choose_escape_waypoint_for_no_path(self, name: str) -> Optional[GridCell]:
        amr = self.amrs[name]
        if amr.target_cell is None:
            return None
        task = self.tasks.get(amr.task_id or "")
        if task is None:
            return None

        cx, cy = amr.cell
        source: List[GridCell] = []
        if self.valid_qr_cells:
            for c in self.valid_qr_cells:
                if 1 <= cell_manhattan_distance(amr.cell, c) <= NO_PATH_ESCAPE_RADIUS:
                    source.append(c)
        else:
            for x in range(cx - NO_PATH_ESCAPE_RADIUS, cx + NO_PATH_ESCAPE_RADIUS + 1):
                for y in range(cy - NO_PATH_ESCAPE_RADIUS, cy + NO_PATH_ESCAPE_RADIUS + 1):
                    c = (x, y)
                    if 1 <= cell_manhattan_distance(amr.cell, c) <= NO_PATH_ESCAPE_RADIUS:
                        source.append(c)

        reservation = ReservationTable()
        for other in self.amrs.values():
            reservation.reserve_cell(other.cell, self.tick, other.name)
            if other.is_moving() and other.move_from is not None and other.move_to is not None:
                reservation.reserve_cell(other.move_to, self.tick + 1, other.name)
                reservation.reserve_edge(other.move_from, other.move_to, self.tick, other.name)

        static_obstacles = self.static_obstacles_for(amr, allow_assigned_rack=False)
        now_goal_dist = cell_manhattan_distance(amr.cell, task.target_cell)
        candidates: List[Tuple[float, GridCell, int]] = []

        for cell in source:
            if cell == task.target_cell:
                continue
            if not self.endpoint_clear_for_escape(name, cell):
                continue
            req = PlanRequest(
                robot_id=name,
                start=amr.cell,
                goal=cell,
                heading=amr.heading,
                carrying_rack=bool(amr.carrying_rack),
                priority=3,
                waiting_steps=amr.wait_steps,
                allowed_goal_occupied=False,
            )
            result = self.planner.plan(req, reservation, static_obstacles, self.tick)
            if not result.success or len(result.path) < 2:
                continue
            # Prefer cells that reduce density and move outward/left when an SG2-bound
            # carrying AMR is jammed. This directly addresses the AMR_02 case where
            # moving further into the packed +x lane keeps the bottleneck closed.
            density = self.local_density_score(cell, {name})
            path_len = max(1, len(result.path) - 1)
            goal_dist = cell_manhattan_distance(cell, task.target_cell)
            regression = max(0, goal_dist - now_goal_dist)
            outward_bonus = -5.0 if cell[0] < amr.cell[0] else 0.0
            deeper_penalty = 8.0 if cell[0] > amr.cell[0] else 0.0
            same_lane_penalty = 3.0 if cell[1] == amr.cell[1] and cell[0] > amr.cell[0] else 0.0
            score = density * 18.0 + path_len * 3.0 + regression * 2.5 + deeper_penalty + same_lane_penalty + outward_bonus
            candidates.append((score, cell, path_len))

        if not candidates:
            return None
        candidates.sort(key=lambda x: (x[0], x[2], x[1][0], abs(x[1][1] - cy), x[1][1]))
        return candidates[0][1]

    def try_assign_escape_waypoint_for_no_path(self, name: str) -> bool:
        if not NO_PATH_ESCAPE_WAYPOINT_ENABLED:
            return False
        amr = self.amrs[name]
        if amr.state != "TO_TARGET" or not amr.carrying_rack:
            return False
        if amr.no_path_steps < NO_PATH_ESCAPE_THRESHOLD:
            return False
        task = self.tasks.get(amr.task_id or "")
        if task is None or task.phase != "TO_TARGET":
            return False
        # Do not stack escape waypoints. If the AMR is already going to a temporary
        # waypoint, wait until update_task_phases() restores the original target.
        if amr.target_cell != task.target_cell:
            return False

        escape = self.choose_escape_waypoint_for_no_path(name)
        if escape is None:
            if amr.no_path_steps % NO_PATH_ESCAPE_LOG_PERIOD == 0:
                print(f"ESCAPE WAYPOINT WAIT | {name} cell={amr.cell} target={task.target_cell} reason=no_safe_escape")
            return False

        amr.target_cell = escape
        amr.target_xy = grid_to_world(escape)
        amr.wait_steps = 0
        amr.no_path_steps = 0
        print(f"ESCAPE WAYPOINT SET | {name} task={task.command_id} from={amr.cell} escape={escape} final={task.target_cell}")
        return True


    def is_starvation_unlock_candidate(self, name: str) -> bool:
        """True when an AMR has a valid plan/proposal but repeatedly loses arbitration.

        wait_steps rising while no_path_steps stays zero means A* can find a path, but
        the global arbiter keeps rejecting the immediate move.  Give that AMR a short
        local priority window so it can clear the bottleneck instead of being starved
        behind nearby loaded AMRs.
        """
        if not STARVATION_UNLOCK_ENABLED:
            return False
        amr = self.amrs.get(name)
        if amr is None:
            return False
        if amr.is_moving():
            return False
        if amr.state not in ["LOCAL_ENTRY", "LOCAL_EXIT", "TO_PRE_TARGET_WAIT", "TO_TARGET", "POST_PLACE_SIDE_EXIT", "POST_PLACE_BACK_EXIT", "POST_PLACE_EXIT_HOLD", "RETURN_HOME", "TO_RACK"]:
            return False
        if int(getattr(amr, "wait_steps", 0)) < STARVATION_UNLOCK_WAIT_THRESHOLD:
            return False
        # no_path==0 is important: the planner has a route, only the arbiter is blocking it.
        if int(getattr(amr, "no_path_steps", 0)) != 0:
            return False
        return True

    def starvation_priority_score(self, name: str) -> float:
        if not self.is_starvation_unlock_candidate(name):
            return 0.0
        amr = self.amrs[name]
        return STARVATION_UNLOCK_PRIORITY_BONUS + float(min(int(amr.wait_steps), 300))

    def loaded_amr_spacing_conflict(self, name: str, src: GridCell, dst: GridCell, approved: Dict[str, GridCell], proposals: Dict[str, GridCell]) -> bool:
        """Avoid forming tight clusters of rack-carrying AMRs.

        Carrying workstations are visually wider than the grid-center point.  When two
        loaded AMRs finish a tick in adjacent cells, the next arbitration cycle often
        blocks both of them.  This guard prevents new adjacent loaded placements unless
        it is a straight same-direction convoy case or the move is part of an approved
        starvation unlock that increases separation.
        """
        if not LOADED_AMR_MIN_SPACING_ENABLED:
            return False
        amr = self.amrs.get(name)
        if amr is None or not amr.carrying_rack:
            return False

        move = normalize_move(dst[0] - src[0], dst[1] - src[1])
        if move == (0, 0):
            return False

        starved = self.is_starvation_unlock_candidate(name)

        for other_name, other in self.amrs.items():
            if other_name == name or not other.carrying_rack:
                continue

            # Predict the other AMR's next cell as well as possible in this tick.
            if other_name in approved:
                other_next = approved[other_name]
                other_src = other.cell
            elif other_name in proposals:
                other_next = proposals[other_name]
                other_src = other.cell
            elif other.is_moving() and other.move_to is not None:
                other_next = other.move_to
                other_src = other.move_from if other.move_from is not None else other.cell
            else:
                other_next = other.cell
                other_src = other.cell

            new_dist = cell_chebyshev_distance(dst, other_next)
            if new_dist >= LOADED_AMR_MIN_CHEBYSHEV_DISTANCE:
                continue

            old_dist = cell_chebyshev_distance(src, other_src)
            other_move = normalize_move(other_next[0] - other_src[0], other_next[1] - other_src[1])

            # v30: spacing is a soft traffic rule, not a hard wall.  If the
            # global cell/edge/footprint checks are already safe, do not block
            # same-direction flow or non-closing moves just because the planned
            # paths are adjacent.
            if LOADED_AMR_SPACING_SOFTENED_V30:
                if move == other_move and is_cardinal_move(move):
                    continue
                if new_dist >= old_dist:
                    continue

            # Keep the previously requested straight convoy behavior: loaded AMRs may
            # follow in-line when both are moving the same direction.  This exception
            # does not apply to perpendicular/L-shaped merges.
            if (
                LOADED_AMR_SPACING_ALLOW_STRAIGHT_CONVOY
                and move == other_move
                and is_cardinal_move(move)
                and self.vacated_cell_tail_release_allowed(name, src, dst, other_name, other_src, other_next)
            ):
                continue

            # v16 soft-spacing rule:
            # - Prevent creating a *new* tighter loaded cluster.
            # - If the AMRs are already too close, allow moves that keep or increase separation.
            #   A hard reject here trapped the system in a deadlock because escape moves were
            #   blocked by the same spacing guard that was meant to prevent clustering.
            if old_dist < LOADED_AMR_MIN_CHEBYSHEV_DISTANCE and new_dist >= old_dist:
                continue

            # Starvation unlock is slightly more permissive: if it increases separation, allow it.
            if starved and new_dist > old_dist:
                continue

            return True
        return False

    def format_reject_context(self, name: str, src: GridCell, dst: GridCell, reason: str) -> str:
        amr = self.amrs.get(name)
        if amr is None:
            return f"MOVE REJECT | {name} {src}->{dst} reason={reason}"
        return (
            f"MOVE REJECT | {name} {src}->{dst} reason={reason} "
            f"state={amr.state} carry={amr.carrying_rack} "
            f"wait={amr.wait_steps} no_path={amr.no_path_steps}"
        )

    def estimate_route_motion_cost(self, req: PlanRequest, path: List[GridCell]) -> float:
        """Lightweight route cost used only for v42 wait-vs-detour comparison.

        The actual hard safety decision remains in TimeAStar8 and global_move_arbiter().
        This estimate answers the fleet question:
          is it cheaper to keep waiting for the rejected first step,
          or to take a slightly longer safe first detour now?
        """
        if not path or len(path) < 2:
            return float("inf")

        cost = 0.0
        heading = req.heading
        turn_cost = COST_AWARE_DETOUR_TURN_COST_CARRY if req.carrying_rack else COST_AWARE_DETOUR_TURN_COST_EMPTY

        for i in range(1, len(path)):
            prev = path[i - 1]
            cur = path[i]
            move = normalize_move(cur[0] - prev[0], cur[1] - prev[1])
            if move == (0, 0):
                cost += WAIT_COST_CARRY if req.carrying_rack else WAIT_COST_EMPTY
                continue
            cost += 1.414 if is_diagonal_move(move) else 1.0
            if heading != (0, 0) and move != heading:
                cost += turn_cost
            heading = move

        return cost

    def estimate_wait_cost_for_rejected_move(self, name: str, reject_reason: str) -> float:
        amr = self.amrs[name]
        ticks = max(1, int(getattr(amr, "wait_steps", 0)) + 1)
        per_tick = COST_AWARE_WAIT_COST_PER_TICK_CARRY if amr.carrying_rack else COST_AWARE_WAIT_COST_PER_TICK_EMPTY
        cost = ticks * per_tick

        # Arbiter rejections such as current-cell conflict and footprint conflict
        # usually mean the release time is uncertain. Add a small penalty so an
        # available detour wins earlier instead of waiting indefinitely.
        if reject_reason and reject_reason not in {"same_cell_wait"}:
            cost += COST_AWARE_WAIT_REASON_PENALTY

        # If an AMR has already waited a long time, prefer any bounded safe detour.
        if ticks >= COST_AWARE_REROUTE_FORCE_AFTER_WAIT_STEPS:
            cost += 999.0
        return cost

    def detour_extra_cost_allowed(self, req: PlanRequest) -> float:
        return COST_AWARE_REROUTE_MAX_EXTRA_CELLS_CARRY if req.carrying_rack else COST_AWARE_REROUTE_MAX_EXTRA_CELLS_EMPTY

    def candidate_move_safe_against_approved(
        self,
        name: str,
        dst: GridCell,
        second: Optional[GridCell],
        approved: Dict[str, GridCell],
        approved_second: Optional[Dict[str, Optional[GridCell]]] = None,
    ) -> Tuple[bool, str]:
        """Run the same common one-step safety gates used by the global arbiter.

        This is used only by the v42 second-chance cost-aware reroute layer, after
        the first arbiter pass rejected the original first step.  Keeping this
        centralized at the global driving layer makes the behavior phase-agnostic:
        TO_RACK, LOCAL_ENTRY, TO_TARGET, LOCAL_EXIT and RETURN_HOME all pass here.
        """
        approved_second = approved_second or {}
        amr = self.amrs[name]
        src = amr.cell

        if dst == src:
            return False, "same_cell_wait"
        if QR_ONLY_NAVIGATION and self.valid_qr_cells and dst not in self.valid_qr_cells:
            return False, "dst_not_qr"

        move = normalize_move(dst[0] - src[0], dst[1] - src[1])
        if amr.carrying_rack and self.must_use_four_way_near_rack(src, dst) and is_diagonal_move(move):
            return False, "loaded_diagonal_or_near_rack_diagonal"

        proposals = dict(approved)
        proposals[name] = dst
        path2 = dict(approved_second)
        path2[name] = second

        yield_reason = self.empty_return_yield_to_loaded_delivery(name, src, dst, proposals, path2)
        if yield_reason is not None:
            return False, yield_reason
        if self.current_cell_conflict_unless_tail_release(name, src, dst, approved):
            return False, "current_cell_conflict_or_tail_release_denied"
        if dst in set(approved.values()):
            return False, "duplicate_target_with_approved"
        if self.edge_swap_conflict(name, src, dst, approved):
            return False, "edge_swap_conflict"
        if self.diagonal_cross_conflict(name, src, dst, approved):
            return False, "diagonal_cross_conflict"
        if self.loaded_amr_spacing_conflict(name, src, dst, approved, proposals):
            return False, "loaded_amr_min_spacing_conflict"
        if self.footprint_conflict(name, src, dst, approved):
            return False, "footprint_swept_conflict"
        if self.moving_segment_conflict(name, src, dst, approved):
            return False, "moving_segment_or_swept_conflict"

        # lookahead2 remains a soft probe in v41/v42. It may log/risk-mark but
        # does not reject the current one-cell detour.
        if LOOKAHEAD2_ACTIVE_ARBITEER:
            self.lookahead2_conflict(name, src, dst, second, approved, approved_second)

        return True, "safe"

    def try_cost_aware_global_reroute(
        self,
        name: str,
        req: PlanRequest,
        original_next: Optional[GridCell],
        reject_reason: str,
        static_obstacles: Set[GridCell],
        reservation: ReservationTable,
        approved: Dict[str, GridCell],
        approved_second: Dict[str, Optional[GridCell]],
    ) -> Tuple[Optional[GridCell], Optional[GridCell]]:
        """Second-chance wait-vs-detour planner for any driving phase.

        First pass:
          normal A* + reservation table + arbiter.
        If the arbiter rejects the chosen first step, this method asks:
          1) is waiting still cheaper?
          2) if not, can A* find a safe first detour when the rejected first
             cell and the first WAIT action are forbidden?
        """
        if not COST_AWARE_GLOBAL_REROUTE_ENABLED:
            return None, None

        amr = self.amrs.get(name)
        if amr is None or amr.target_cell is None or amr.is_moving():
            return None, None

        if amr.wait_steps < COST_AWARE_REROUTE_MIN_WAIT_STEPS and reject_reason != "same_cell_wait":
            return None, None

        avoid_first_cells: Set[GridCell] = set()
        if original_next is not None and original_next != amr.cell and original_next != req.goal:
            avoid_first_cells.add(original_next)

        retry_req = PlanRequest(
            robot_id=req.robot_id,
            start=req.start,
            goal=req.goal,
            heading=req.heading,
            carrying_rack=req.carrying_rack,
            priority=req.priority,
            waiting_steps=req.waiting_steps,
            allowed_goal_occupied=req.allowed_goal_occupied,
            allow_wait_first_step=False,
            avoid_first_cells=avoid_first_cells,
        )

        retry_result = self.planner.plan(retry_req, reservation, static_obstacles, self.tick)
        if not retry_result.success or len(retry_result.path) < 2:
            if COST_AWARE_REROUTE_LOG_ENABLED and amr.wait_steps in (COST_AWARE_REROUTE_MIN_WAIT_STEPS, 10, 20, 40, 80):
                print(
                    f"COST_DECISION | {name} decision=WAIT reason=no_detour "
                    f"reject={reject_reason} cell={amr.cell} target={amr.target_cell} wait={amr.wait_steps}"
                )
            return None, None

        alt_next = retry_result.path[1]
        alt_second = retry_result.path[2] if len(retry_result.path) >= 3 else None
        if alt_next == amr.cell or alt_next == original_next:
            return None, None

        direct_lower_bound = self.planner.heuristic(req.start, req.goal)
        detour_cost = self.estimate_route_motion_cost(retry_req, retry_result.path)
        detour_extra = max(0.0, detour_cost - direct_lower_bound)
        wait_cost = self.estimate_wait_cost_for_rejected_move(name, reject_reason)

        safe, safety_reason = self.candidate_move_safe_against_approved(name, alt_next, alt_second, approved, approved_second)
        if not safe:
            if COST_AWARE_REROUTE_LOG_ENABLED and (
                amr.wait_steps in (COST_AWARE_REROUTE_MIN_WAIT_STEPS, 10, 20, 40, 80)
                or (amr.wait_steps > 80 and amr.wait_steps % COST_AWARE_REROUTE_LOG_PERIOD == 0)
            ):
                print(
                    f"COST_DECISION | {name} decision=WAIT reason=detour_unsafe "
                    f"safety={safety_reason} reject={reject_reason} original_next={original_next} "
                    f"alt_next={alt_next} wait_cost={wait_cost:.2f} detour_extra={detour_extra:.2f}"
                )
            return None, None

        # Main decision: detour only when it is bounded and cheaper than continued wait.
        # Force-after-wait is handled by wait_cost += 999 above.
        max_extra = self.detour_extra_cost_allowed(req)
        if detour_extra <= max_extra and detour_extra <= wait_cost:
            if COST_AWARE_REROUTE_LOG_ENABLED:
                print(
                    f"COST_DECISION | {name} decision=REROUTE state={amr.state} "
                    f"carry={amr.carrying_rack} cell={amr.cell} target={amr.target_cell} "
                    f"reject={reject_reason} original_next={original_next} alt_next={alt_next} "
                    f"wait_cost={wait_cost:.2f} detour_cost={detour_cost:.2f} "
                    f"detour_extra={detour_extra:.2f} max_extra={max_extra:.2f} "
                    f"path={retry_result.path[:8]}"
                )
            return alt_next, alt_second

        if COST_AWARE_REROUTE_LOG_ENABLED and (
            amr.wait_steps in (COST_AWARE_REROUTE_MIN_WAIT_STEPS, 10, 20, 40, 80)
            or (amr.wait_steps > 80 and amr.wait_steps % COST_AWARE_REROUTE_LOG_PERIOD == 0)
        ):
            print(
                f"COST_DECISION | {name} decision=WAIT reason=wait_cheaper "
                f"state={amr.state} reject={reject_reason} original_next={original_next} "
                f"alt_next={alt_next} wait_cost={wait_cost:.2f} detour_extra={detour_extra:.2f} "
                f"max_extra={max_extra:.2f}"
            )
        return None, None

    def plan_and_approve_moves(self):
        # v41: keep the global four-way zone synchronized with moved/carried racks
        # before A* planning.
        self.refresh_dynamic_four_way_global_cells()
        if RANDOM_DRIVE_ENABLED and not STANDBY_UNTIL_COMMAND:
            self.resolve_random_clumps()
            self.resolve_duplicate_random_targets()
        elif self.tasks:
            self.resolve_duplicate_random_targets()
        requests: List[PlanRequest] = []
        request_by_robot: Dict[str, PlanRequest] = {}
        static_by_robot: Dict[str, Set[GridCell]] = {}

        for amr in self.amrs.values():
            if amr.is_moving() or amr.state in ["LIFTING", "ROTATING", "PLACING", "POST_PLACE_TURN_180"]:
                continue
            if amr.target_cell is None and amr.state == "RANDOM" and RANDOM_DRIVE_ENABLED and not STANDBY_UNTIL_COMMAND:
                self.assign_random_goal(amr)
            if amr.target_cell is None or amr.cell == amr.target_cell:
                if amr.state == "RANDOM" and RANDOM_DRIVE_ENABLED and not STANDBY_UNTIL_COMMAND:
                    self.assign_random_goal(amr)
                continue

            carrying = bool(amr.carrying_rack)
            allowed_goal_occupied = amr.state == "TO_RACK"
            req = PlanRequest(
                robot_id=amr.name,
                start=amr.cell,
                goal=amr.target_cell,
                heading=amr.heading,
                carrying_rack=carrying,
                priority=3 if carrying else 1,
                waiting_steps=amr.wait_steps,
                allowed_goal_occupied=allowed_goal_occupied,
            )
            requests.append(req)
            request_by_robot[amr.name] = req
            static_by_robot[amr.name] = self.static_obstacles_for(amr, allow_assigned_rack=allowed_goal_occupied)

        if not requests:
            return

        reservation = ReservationTable()
        # Current positions are hard-reserved.
        for other in self.amrs.values():
            reservation.reserve_cell(other.cell, self.tick, other.name)
            if other.is_moving():
                reservation.reserve_cell(other.move_to, self.tick + 1, other.name)
                reservation.reserve_edge(other.move_from, other.move_to, self.tick, other.name)

        ordered = sorted(requests, key=lambda r: (-self.congestion_priority_score(r.robot_id), r.robot_id))
        proposals: Dict[str, GridCell] = {}
        path2: Dict[str, Optional[GridCell]] = {}

        for req in ordered:
            result = self.planner.plan(req, reservation, static_by_robot.get(req.robot_id, set()), self.tick)
            if result.success and len(result.path) >= 2:
                next_cell = result.path[1]
                proposals[req.robot_id] = next_cell
                path2[req.robot_id] = result.path[2] if len(result.path) >= 3 else None

                # v19 Reservation Table A*:
                # Reserve the successful timed path immediately so lower-priority AMRs
                # plan around the future positions of higher-priority AMRs. This changes
                # behavior from "everyone plans independently, then the arbiter rejects"
                # to "later AMRs choose a different route or wait earlier".
                #
                # The reservation table is rebuilt every planning tick, so a path that
                # later gets rejected by the final arbiter cannot permanently pollute
                # the system. It only influences the current tick's lower-priority
                # proposals, which is exactly what prioritized reservation-table A* needs.
                if RESERVATION_TABLE_ASTAR_ENABLED:
                    heading_path = self.heading_path_from_cells(result.path, req.heading)
                    reservation.reserve_path(req.robot_id, result.timed_path, req.carrying_rack, heading_path)
                    if RESERVATION_TABLE_ASTAR_LOG_ENABLED:
                        amr_for_log = self.amrs[req.robot_id]
                        if amr_for_log.wait_steps in (0, 1, 5, 20, 40, 80) or (
                            RESERVATION_TABLE_ASTAR_LOG_PERIOD > 0
                            and amr_for_log.wait_steps > 0
                            and amr_for_log.wait_steps % RESERVATION_TABLE_ASTAR_LOG_PERIOD == 0
                        ):
                            preview = result.timed_path[: min(len(result.timed_path), 8)]
                            print(
                                f"RESERVATION_TABLE_ASTAR PLAN | {req.robot_id} "
                                f"state={amr_for_log.state} start={req.start} goal={req.goal} "
                                f"next={next_cell} path_len={len(result.path)} reserve_preview={preview}"
                            )

                self.amrs[req.robot_id].no_path_steps = 0
            else:
                self.amrs[req.robot_id].no_path_steps += 1
                self.amrs[req.robot_id].wait_steps += 1
                if self.amrs[req.robot_id].no_path_steps in (20, 50, 100) or (self.amrs[req.robot_id].no_path_steps > 100 and self.amrs[req.robot_id].no_path_steps % 50 == 0):
                    a = self.amrs[req.robot_id]
                    print(f"CONGESTION NO_PATH | {req.robot_id} state={a.state} cell={a.cell} target={a.target_cell} carrying={a.carrying_rack} wait={a.wait_steps} no_path={a.no_path_steps}")
                # v13: carrying AMR no_path recovery.  Do not keep a loaded AMR parked
                # in the dense lane forever; move it to a safe staging/escape QR cell,
                # then restore the original drop target after the waypoint is reached.
                self.try_assign_escape_waypoint_for_no_path(req.robot_id)
                # For RANDOM mode, avoid standing forever by changing goal, not by unsafe forced move.
                if self.amrs[req.robot_id].state == "RANDOM" and RANDOM_DRIVE_ENABLED and not STANDBY_UNTIL_COMMAND and self.amrs[req.robot_id].no_path_steps >= 3:
                    self.assign_random_goal(self.amrs[req.robot_id])

        self.apply_bottleneck_turn_first_overrides(proposals, path2)
        self.apply_loaded_lane_spread_overrides(proposals, path2)

        approved = self.global_move_arbiter(proposals, path2)

        rejected_names = set(proposals.keys()) - set(approved.keys())

        # v42 cost-aware global reroute:
        # The first arbiter pass may reject the first step selected by A*. Before
        # forcing the AMR to wait again, do a second-chance replan that blocks only
        # that rejected first step and compares wait_cost vs detour_cost.  This is
        # intentionally placed at the common global driving layer, so it applies to
        # every driving phase instead of being limited to SG local entry.
        approved_second: Dict[str, Optional[GridCell]] = {n: path2.get(n) for n in approved.keys()}
        rescued_by_reroute: Set[str] = set()
        for name in sorted(rejected_names, key=lambda n: (-self.congestion_priority_score(n), n)):
            req = request_by_robot.get(name)
            if req is None:
                continue
            amr = self.amrs[name]
            reject_reason = getattr(self, "last_move_reject_reasons", {}).get(name, "")
            alt_next, alt_second = self.try_cost_aware_global_reroute(
                name=name,
                req=req,
                original_next=proposals.get(name),
                reject_reason=reject_reason,
                static_obstacles=static_by_robot.get(name, set()),
                reservation=reservation,
                approved=approved,
                approved_second=approved_second,
            )
            if alt_next is not None:
                proposals[name] = alt_next
                path2[name] = alt_second
                approved[name] = alt_next
                approved_second[name] = alt_second
                rescued_by_reroute.add(name)

        rejected_names = rejected_names - rescued_by_reroute
        for name in rejected_names:
            amr = self.amrs[name]
            amr.wait_steps += 1
            if amr.wait_steps in (40, 80, 120) or (amr.wait_steps > 120 and amr.wait_steps % 60 == 0):
                print(f"CONGESTION WAIT | {name} state={amr.state} cell={amr.cell} target={amr.target_cell} carrying={amr.carrying_rack} wait={amr.wait_steps} no_path={amr.no_path_steps}")
            if amr.state == "RANDOM" and RANDOM_DRIVE_ENABLED and not STANDBY_UNTIL_COMMAND and amr.wait_steps >= REJECTED_MOVE_GOAL_REASSIGN_STEPS:
                self.assign_dispersed_random_goal(amr, reason="rejected_by_lookahead_or_arbiter")

        for name, next_cell in approved.items():
            amr = self.amrs[name]
            if next_cell == amr.cell:
                amr.wait_steps += 1
                continue
            self.start_cell_move(amr, next_cell)

        self.tick += 1

    def heading_path_from_cells(self, path: List[GridCell], initial_heading: Move) -> List[Move]:
        if not path:
            return []
        headings = [initial_heading]
        for i in range(1, len(path)):
            dx = path[i][0] - path[i - 1][0]
            dy = path[i][1] - path[i - 1][1]
            headings.append(headings[-1] if (dx, dy) == (0, 0) else normalize_move(dx, dy))
        return headings

    def time_aware_swept_conflict(self, src: GridCell, dst: GridCell, other_src: GridCell, other_dst: GridCell, clearance: float) -> bool:
        """Check collision at equal time samples, not by raw segment overlap.

        This is the difference between "same road" and "same place at the same
        time".  Two AMRs may use the same cell/segment at different ticks; the
        hard blockers remain same-tick destination conflict, edge swap, and
        current-cell conflict.
        """
        src_w = grid_to_world(src)
        dst_w = grid_to_world(dst)
        other_src_w = grid_to_world(other_src)
        other_dst_w = grid_to_world(other_dst)
        scaled_clearance = max(0.05, clearance * TIME_AWARE_SEGMENT_CLEARANCE_SCALE)
        for u in (0.25, 0.50, 0.75, 1.00):
            p = (src_w[0] * (1.0 - u) + dst_w[0] * u, src_w[1] * (1.0 - u) + dst_w[1] * u)
            q = (other_src_w[0] * (1.0 - u) + other_dst_w[0] * u, other_src_w[1] * (1.0 - u) + other_dst_w[1] * u)
            if distance_xy(p, q) < scaled_clearance:
                return True
        return False

    def moving_segment_conflict(self, name: str, src: GridCell, dst: GridCell, approved: Optional[Dict[str, GridCell]] = None) -> bool:
        """Reject only real swept-motion conflicts.

        V21 tail-release fix:
        - Stationary AMRs are handled by current_cell_conflict_unless_tail_release();
          do not use a large segment-radius check against stationary AMRs because it
          creates artificial 1.5~2 cell gaps and makes AMRs stop around LIFTING/PLACING robots.
        - Approved moves in this same planning tick are treated as moving segments, so
          a follower can enter the leader's vacated tail cell when tail-release rules allow it.
        - AMRs already in an in-progress move are also treated as moving segments and can
          be followed into their vacated cell if the rule is safe.
        """
        approved = approved or {}
        src_w = grid_to_world(src)
        dst_w = grid_to_world(dst)
        radius = self.footprint_radius(self.amrs[name])
        move = normalize_move(dst[0] - src[0], dst[1] - src[1])

        for other_name, other in self.amrs.items():
            if other_name == name:
                continue

            if other_name in approved:
                other_src = other.cell
                other_dst = approved[other_name]
            elif other.is_moving() and other.move_from is not None and other.move_to is not None:
                other_src = other.move_from
                other_dst = other.move_to
            else:
                # Stationary AMR: exact current-cell conflict is handled earlier.
                # Do not apply swept-radius checks around a stationary/lifting AMR.
                continue

            other_src_w = grid_to_world(other_src)
            other_dst_w = grid_to_world(other_dst)
            other_radius = self.footprint_radius(other)
            clearance = radius + other_radius + DYNAMIC_SWEPT_COLLISION_MARGIN_M

            if self.vacated_cell_tail_release_allowed(name, src, dst, other_name, other_src, other_dst):
                continue

            other_move = normalize_move(other_dst[0] - other_src[0], other_dst[1] - other_src[1])

            # v30: allow same road/segment usage when the timing is different.
            # Same-direction convoy is already covered by tail-release; parallel
            # or sequential segment overlap should not be rejected just because
            # the geometric lines are close.
            if TIME_AWARE_SEGMENT_CHECK_ENABLED:
                if move == other_move and is_cardinal_move(move):
                    pass
                elif self.time_aware_swept_conflict(src, dst, other_src, other_dst, clearance):
                    return True
            else:
                if segment_distance(src_w, dst_w, other_src_w, other_dst_w) < clearance:
                    return True

            if DIAGONAL_CARDINAL_CONFLICT_ENABLED and self.diagonal_cardinal_conflict(src, dst, other_src, other_dst, move, other_move):
                return True

        return False

    def diagonal_cardinal_conflict(
        self,
        src: GridCell,
        dst: GridCell,
        other_src: GridCell,
        other_dst: GridCell,
        move: Move,
        other_move: Move,
    ) -> bool:
        """Extra grid-topology guard for diagonal-vs-cardinal visual collisions.

        A line-segment test alone can miss visually large imported AMR bodies when one robot
        cuts diagonally through a 2x2 block while another moves cardinally along one edge of
        the same block. This rejects mixed diagonal/cardinal moves sharing the same local 2x2
        neighborhood or adjacent swept cells.
        """
        this_diag = is_diagonal_move(move)
        other_diag = is_diagonal_move(other_move)
        this_card = is_cardinal_move(move)
        other_card = is_cardinal_move(other_move)

        if not ((this_diag and other_card) or (this_card and other_diag)):
            return False

        def swept_cells(a: GridCell, b: GridCell, m: Move) -> Set[GridCell]:
            cells = {a, b}
            if is_diagonal_move(m):
                cells.add((a[0] + m[0], a[1]))
                cells.add((a[0], a[1] + m[1]))
            return cells

        s1 = swept_cells(src, dst, move)
        s2 = swept_cells(other_src, other_dst, other_move)

        # Same endpoint, adjacent corner, or edge of diagonal square is unsafe for visual AMR bodies.
        if s1 & s2:
            return True

        # If all swept cells are within one Chebyshev step, treat it as the same local crossing zone.
        for c1 in s1:
            for c2 in s2:
                if cell_chebyshev_distance(c1, c2) <= 1:
                    return True

        return False

    def proposal_role_priority_score(self, name: str, dst: GridCell) -> float:
        """v30 proposal-based traffic priority.

        Only AMRs with an actual one-step proposal reach this function.  Waiting
        states with target=None no longer get artificial priority just because
        wait_steps is large.
        """
        amr = self.amrs.get(name)
        if amr is None:
            return 0.0
        task = self.task_for_amr_name(name)
        score = 0.0
        if amr.state == "LOCAL_EXIT":
            score += 260.0  # clear the SG bay first
        if amr.carrying_rack and amr.state in {"LOCAL_ENTRY", "TO_TARGET", "TO_PRE_TARGET_WAIT"}:
            score += 230.0
        if amr.state == "LOCAL_ENTRY":
            score += 180.0
        if task is not None and self.sg2_target_side(task.target_location) == "B" and amr.state in {"LOCAL_ENTRY", "LOCAL_EXIT"}:
            score += 35.0  # B route is short; finish and clear it
        if amr.carrying_rack:
            score += 80.0
        if amr.state == "TO_RACK":
            score += 35.0
        if amr.state == "RETURN_HOME" and not amr.carrying_rack:
            score -= 90.0
        score += min(float(getattr(amr, "wait_steps", 0)), 80.0) * 0.35
        return score

    def global_move_arbiter(self, proposals: Dict[str, GridCell], path2: Optional[Dict[str, Optional[GridCell]]] = None) -> Dict[str, GridCell]:
        approved: Dict[str, GridCell] = {}
        approved_second: Dict[str, Optional[GridCell]] = {}
        target_to_robot: Dict[GridCell, str] = {}
        reject_reasons: Dict[str, str] = {}
        path2 = path2 or {}

        def reject(name: str, reason: str) -> None:
            reject_reasons[name] = reason

        # Deterministic priority: starvation-unlock AMRs first, then turn-first,
        # congestion aging and task/carrying priority.  Tail-release dependencies can
        # still move a leader before a follower when the follower wants the leader's cell.
        base_order = sorted(
            proposals.keys(),
            key=lambda n: (
                -self.proposal_role_priority_score(n, proposals[n]),
                -self.starvation_priority_score(n),
                -self.bottleneck_turn_priority_score(n, proposals[n]),
                -self.congestion_priority_score(n),
                n,
            ),
        )
        ordered_names = self.order_for_tail_release(base_order, proposals)

        starved_names = [n for n in ordered_names if self.is_starvation_unlock_candidate(n)]
        if starved_names:
            msg = []
            for n in starved_names:
                a = self.amrs[n]
                msg.append(f"{n}@{a.cell}-> {proposals.get(n)} wait={a.wait_steps}")
            # Log sparsely to avoid flooding Script Editor.
            if any(self.amrs[n].wait_steps % STARVATION_UNLOCK_LOG_PERIOD == 0 for n in starved_names):
                print("STARVATION UNLOCK PRIORITY | " + "; ".join(msg))

        for name in ordered_names:
            amr = self.amrs[name]
            src = amr.cell
            dst = proposals[name]
            if dst == src:
                reject(name, "same_cell_wait")
                continue
            if QR_ONLY_NAVIGATION and self.valid_qr_cells and dst not in self.valid_qr_cells:
                reject(name, "dst_not_qr")
                continue
            move = normalize_move(dst[0] - src[0], dst[1] - src[1])
            if amr.carrying_rack and self.must_use_four_way_near_rack(src, dst) and is_diagonal_move(move):
                reject(name, "loaded_diagonal_or_near_rack_diagonal")
                continue
            yield_reason = self.empty_return_yield_to_loaded_delivery(name, src, dst, proposals, path2)
            if yield_reason is not None:
                reject(name, yield_reason)
                continue
            if self.current_cell_conflict_unless_tail_release(name, src, dst, approved):
                reject(name, "current_cell_conflict_or_tail_release_denied")
                continue
            if dst in target_to_robot:
                reject(name, f"duplicate_target_with_{target_to_robot[dst]}")
                continue
            if self.edge_swap_conflict(name, src, dst, approved):
                reject(name, "edge_swap_conflict")
                continue
            if self.diagonal_cross_conflict(name, src, dst, approved):
                reject(name, "diagonal_cross_conflict")
                continue
            if self.loaded_amr_spacing_conflict(name, src, dst, approved, proposals):
                reject(name, "loaded_amr_min_spacing_conflict")
                continue
            if self.footprint_conflict(name, src, dst, approved):
                reject(name, "footprint_swept_conflict")
                continue
            if self.moving_segment_conflict(name, src, dst, approved):
                reject(name, "moving_segment_or_swept_conflict")
                continue
            # Mode C soft lookahead policy:
            # The immediate next-cell safety checks above are hard blockers.
            # The second planned cell is only a caution/replanning hint, so it must not
            # reject the current one-cell move. This prevents unnecessary waiting when
            # the next cell is safe but the cell after that is currently blocked.
            if LOOKAHEAD2_ACTIVE_ARBITEER:
                self.lookahead2_conflict(name, src, dst, path2.get(name), approved, approved_second)
            target_to_robot[dst] = name
            approved[name] = dst
            approved_second[name] = path2.get(name)

        self.last_move_reject_reasons = reject_reasons
        if ARB_REJECT_REASON_LOG_ENABLED:
            for name, reason in reject_reasons.items():
                amr = self.amrs.get(name)
                if amr is None:
                    continue
                if (
                    self.is_starvation_unlock_candidate(name)
                    or amr.wait_steps in (10, 20, 40, 80, 120)
                    or (amr.wait_steps > 120 and amr.wait_steps % ARB_REJECT_REASON_LOG_PERIOD == 0)
                ):
                    print(self.format_reject_context(name, amr.cell, proposals.get(name, amr.cell), reason))
        return approved

    def lookahead2_conflict(
        self,
        name: str,
        src: GridCell,
        dst: GridCell,
        second: Optional[GridCell],
        approved: Dict[str, GridCell],
        approved_second: Dict[str, Optional[GridCell]],
    ) -> bool:
        if second is None or second == dst:
            return False

        amr = self.amrs[name]
        move2 = normalize_move(second[0] - dst[0], second[1] - dst[1])

        # Soft lookahead policy:
        # The checks below intentionally do not block the current move. The hard
        # safety decision already happened for dst in global_move_arbiter() and in A*.
        # This method is kept as a centralized second-cell risk probe for debugging,
        # future speed control, or replanning hints.
        if QR_ONLY_NAVIGATION and self.valid_qr_cells and second not in self.valid_qr_cells:
            return True
        if self.hard_amr_cell_conflict(name, second):
            return True

        # Carrying AMR policy: Mode C two-step approval.
        # A* already checked the immediate next-cell footprint. Here we additionally
        # check the second planned cell with the same carried-rack 4-neighbor footprint.
        # If the second cell is the final goal, rack_occupied_cells() returns only the
        # goal center cell, so no lookahead beyond the final destination is required.
        if amr.carrying_rack:
            if self.must_use_four_way_near_rack(dst, second) and is_diagonal_move(move2):
                return True
            if not self.carrying_footprint_clear_for_second_step(name, second, move2):
                return True
        else:
            # Non-carrying AMRs are allowed to move diagonally and pass under stationary
            # racks/workstations. Keep only AMR-to-AMR safety checks here.
            pass

        # Avoid entering a near-future occupied or reserved visual zone.
        for other_name, other_dst in approved.items():
            other = self.amrs[other_name]
            other_src = other.cell
            other_second = approved_second.get(other_name)

            if second == other_dst or second == other_src:
                return True
            if cell_chebyshev_distance(second, other_dst) < LOOKAHEAD2_MIN_CLEARANCE_CELLS:
                return True
            if other_second is not None:
                if second == other_second:
                    return True
                # Two-step edge swap: this AMR's next->second conflicts with other next->other_second.
                if dst == other_second and second == other_dst:
                    return True
                if self.diagonal_cardinal_conflict(dst, second, other_dst, other_second, move2, normalize_move(other_second[0] - other_dst[0], other_second[1] - other_dst[1])):
                    return True
                if segment_distance(grid_to_world(dst), grid_to_world(second), grid_to_world(other_dst), grid_to_world(other_second)) < (self.footprint_radius(self.amrs[name]) + self.footprint_radius(other) + DYNAMIC_SWEPT_COLLISION_MARGIN_M):
                    return True

        # Also avoid planning second step through currently moving AMR segments.
        for other_name, other in self.amrs.items():
            if other_name == name:
                continue
            if other.is_moving() and other.move_from is not None and other.move_to is not None:
                if segment_distance(grid_to_world(dst), grid_to_world(second), grid_to_world(other.move_from), grid_to_world(other.move_to)) < (self.footprint_radius(self.amrs[name]) + self.footprint_radius(other) + DYNAMIC_SWEPT_COLLISION_MARGIN_M):
                    return True
        return False

    def hard_amr_cell_conflict(self, name: str, cell: GridCell) -> bool:
        """Return True when a cell is physically occupied by another AMR now or by
        another AMR that is actually moving into the cell. Stale move_to values from
        non-moving LIFTING/PLACING/ROTATING states are intentionally ignored.
        """
        for other_name, other in self.amrs.items():
            if other_name == name:
                continue
            if other.cell == cell:
                return True
            if other.is_moving() and other.move_to == cell:
                return True
        return False

    def carrying_footprint_clear_for_second_step(self, name: str, center: GridCell, move: Move) -> bool:
        """Check carried-rack footprint for the second planned cell in Mode C.

        Center cell must be QR-valid and free from rack obstacles. Adjacent footprint
        cells are physical clearance cells: they may be non-QR cells, but they must not
        overlap stationary rack obstacles or AMR hard-occupied cells. At the final goal,
        rack_occupied_cells() returns only the goal center cell, preventing the old
        failure where the planner required a non-existent cell beyond the destination.
        """
        amr = self.amrs[name]
        goal = amr.target_cell
        static_obstacles = self.static_obstacles_for(amr, allow_assigned_rack=False)
        occupied_cells = self.planner.rack_occupied_cells(center, move, goal)

        for c in occupied_cells:
            if c == center:
                if QR_ONLY_NAVIGATION and self.valid_qr_cells and c not in self.valid_qr_cells:
                    return False
                if c in static_obstacles and c != goal:
                    return False
            else:
                if c in static_obstacles:
                    return False
            if self.hard_amr_cell_conflict(name, c):
                return False
        return True

    def must_use_four_way_near_rack(self, src: GridCell, dst: GridCell) -> bool:
        zone_cells = self.rack_live_near_zone_cells()
        if not zone_cells:
            return False
        move = normalize_move(dst[0] - src[0], dst[1] - src[1])
        if move == (0, 0):
            return False
        if not is_diagonal_move(move):
            return False
        c1 = (src[0] + move[0], src[1])
        c2 = (src[0], src[1] + move[1])
        return (
            src in zone_cells
            or dst in zone_cells
            or c1 in zone_cells
            or c2 in zone_cells
        )

    def edge_swap_conflict(self, name: str, src: GridCell, dst: GridCell, approved: Dict[str, GridCell]) -> bool:
        for other_name, other_dst in approved.items():
            other_src = self.amrs[other_name].cell
            if other_src == dst and other_dst == src:
                return True
        return False

    def diagonal_cross_conflict(self, name: str, src: GridCell, dst: GridCell, approved: Dict[str, GridCell]) -> bool:
        move = (dst[0] - src[0], dst[1] - src[1])
        if abs(move[0]) != 1 or abs(move[1]) != 1:
            return False
        for other_name, other_dst in approved.items():
            other_src = self.amrs[other_name].cell
            if self.vacated_cell_tail_release_allowed(name, src, dst, other_name, other_src, other_dst):
                continue
            om = (other_dst[0] - other_src[0], other_dst[1] - other_src[1])
            # Crossing diagonals of the same square.
            if abs(om[0]) == 1 and abs(om[1]) == 1:
                if src == (other_dst[0], other_src[1]) and dst == (other_src[0], other_dst[1]):
                    return True

            # v11: mixed diagonal/cardinal conflict in the same local crossing zone.
            if DIAGONAL_CARDINAL_CONFLICT_ENABLED and self.diagonal_cardinal_conflict(src, dst, other_src, other_dst, move, om):
                return True
        return False

    def order_for_tail_release(self, base_order: List[str], proposals: Dict[str, GridCell]) -> List[str]:
        """Topologically order one-step proposals so a cell owner is approved
        before a follower enters that owner's currently occupied cell.

        Example straight convoy A-B-C-D:
            AMR_2 at B proposes B->C
            AMR_1 at A proposes A->B
        AMR_2 must be evaluated first; then AMR_1 can be approved into the
        tail cell B that AMR_2 is vacating in the same tick.

        Example turn release:
            AMR_1 at A proposes A->B
            AMR_2 at D proposes D->A
        AMR_1 is evaluated first; then AMR_2 can enter A after it is vacated.
        """
        if not ALLOW_VACATED_CELL_TAIL_RELEASE:
            return base_order

        base_index = {name: i for i, name in enumerate(base_order)}
        by_current = {amr.cell: name for name, amr in self.amrs.items()}
        deps: Dict[str, Set[str]] = {name: set() for name in base_order}

        for name in base_order:
            src = self.amrs[name].cell
            dst = proposals.get(name)
            if dst is None or dst == src:
                continue
            owner = by_current.get(dst)
            if owner is None or owner == name or owner not in proposals:
                continue
            owner_dst = proposals.get(owner)
            if owner_dst is None or owner_dst == self.amrs[owner].cell:
                continue
            # Edge swap is not tail release; keep it blocked by the normal edge-swap guard.
            if owner_dst == src:
                continue
            if self.vacated_cell_tail_release_allowed(name, src, dst, owner, self.amrs[owner].cell, owner_dst):
                deps[name].add(owner)

        ordered: List[str] = []
        visiting: Set[str] = set()
        visited: Set[str] = set()

        def visit(n: str):
            if n in visited:
                return
            if n in visiting:
                return
            visiting.add(n)
            for dep in sorted(deps.get(n, set()), key=lambda x: base_index.get(x, 9999)):
                visit(dep)
            visiting.remove(n)
            visited.add(n)
            ordered.append(n)

        for n in base_order:
            visit(n)
        return ordered

    def current_cell_conflict_unless_tail_release(self, name: str, src: GridCell, dst: GridCell, approved: Dict[str, GridCell]) -> bool:
        """Current AMR cells are hard blocks except for a verified tail release.

        V21 extension:
        1) If the occupant was already approved in this same tick to leave dst, a follower
           may enter dst if tail-release safety passes.
        2) If the occupant is already physically moving away from dst, a follower may also
           enter dst on the next decision tick if tail-release safety passes.
        3) LIFTING/PLACING/ROTATING stationary AMRs remain hard blocks only at their
           actual current cell; stale future move_to is ignored elsewhere.
        """
        for other_name, other in self.amrs.items():
            if other_name == name:
                continue
            if other.cell != dst:
                continue

            # Case 1: the owner has already been approved to leave this cell in this tick.
            other_dst = approved.get(other_name)
            if other_dst is not None:
                if other_dst == other.cell or other_dst == src:
                    return True
                return not self.vacated_cell_tail_release_allowed(name, src, dst, other_name, other.cell, other_dst)

            # Case 2: the owner is already in a physical move away from this cell.
            if other.is_moving() and other.move_from is not None and other.move_to is not None:
                if other.move_from == dst and other.move_to != src:
                    return not self.vacated_cell_tail_release_allowed(name, src, dst, other_name, other.move_from, other.move_to)

            return True
        return False

    def vacated_cell_tail_release_allowed(self, name: str, src: GridCell, dst: GridCell, other_name: str, other_src: GridCell, other_dst: GridCell) -> bool:
        """Allow a trailing AMR to enter a cell that another AMR is vacating in
        the same tick.

        This covers two user-requested cases:
        1) Straight convoy: A->B while B->C in the same direction.
        2) Turn/tail release: D->A while A->B, after A is vacated.

        The rule never allows edge swaps, never allows diagonal tail-release, and
        keeps loaded perpendicular tail-release conservative.  Straight loaded
        convoy can be enabled for demo density because both AMRs move with the
        same velocity along the same line.
        """
        if not ALLOW_VACATED_CELL_TAIL_RELEASE:
            return False
        if dst != other_src:
            return False
        if other_dst == src:
            return False

        move = normalize_move(dst[0] - src[0], dst[1] - src[1])
        other_move = normalize_move(other_dst[0] - other_src[0], other_dst[1] - other_src[1])
        if move == (0, 0) or other_move == (0, 0):
            return False
        # Tail-release must be grid-cardinal.  Diagonal entry into a vacated cell
        # can visually clip the leaving AMR or rack at the corner.
        if is_diagonal_move(move) or is_diagonal_move(other_move):
            return False

        same_direction = move == other_move
        this_amr = self.amrs[name]
        other_amr = self.amrs[other_name]

        if same_direction and ALLOW_SAME_DIRECTION_CONVOY_FOLLOWING:
            if this_amr.carrying_rack and other_amr.carrying_rack and not ALLOW_LOADED_STRAIGHT_TIGHT_CONVOY:
                return False
            return True

        # Non-straight / perpendicular tail release.
        # v25 collision fix: if either side is carrying a rack, do not allow
        # same-tick entry into the vacated cell. In an L-shaped move the loaded
        # rack sweeps a wider corner area, so the follower must wait until the
        # loaded AMR actually completes the move.
        if this_amr.carrying_rack or other_amr.carrying_rack:
            if not ALLOW_LOADED_PERPENDICULAR_TAIL_RELEASE:
                return False

        # Empty AMR L-turn tail-release is still allowed because the footprint is
        # much smaller and the user-requested ABC/D flow remains useful.
        return bool(ALLOW_EMPTY_TURN_TAIL_RELEASE)

    def same_direction_convoy_following_allowed(self, name: str, src: GridCell, dst: GridCell, other_name: str, other_src: GridCell, other_dst: GridCell) -> bool:
        """Backward-compatible wrapper for older call sites."""
        move = normalize_move(dst[0] - src[0], dst[1] - src[1])
        other_move = normalize_move(other_dst[0] - other_src[0], other_dst[1] - other_src[1])
        return move == other_move and self.vacated_cell_tail_release_allowed(name, src, dst, other_name, other_src, other_dst)

    def footprint_conflict(self, name: str, src: GridCell, dst: GridCell, approved: Dict[str, GridCell]) -> bool:
        src_w = grid_to_world(src)
        dst_w = grid_to_world(dst)
        radius = self.footprint_radius(self.amrs[name])
        for other_name, other_dst in approved.items():
            other_src = self.amrs[other_name].cell
            other_src_w = grid_to_world(other_src)
            other_dst_w = grid_to_world(other_dst)
            other_radius = self.footprint_radius(self.amrs[other_name])
            if self.vacated_cell_tail_release_allowed(name, src, dst, other_name, other_src, other_dst):
                continue

            clearance = radius + other_radius
            if TIME_AWARE_SEGMENT_CHECK_ENABLED:
                if self.time_aware_swept_conflict(src, dst, other_src, other_dst, clearance):
                    return True
            else:
                min_dist = segment_distance(src_w, dst_w, other_src_w, other_dst_w)
                if min_dist < clearance:
                    return True
        return False

    def footprint_radius(self, amr: AmrState) -> float:
        base = RACK_SIZE_M if amr.carrying_rack else AMR_SIZE_M
        return base * 0.5 + SAFETY_MARGIN_M

    def start_cell_move(self, amr: AmrState, next_cell: GridCell):
        amr.move_from = amr.cell
        amr.move_to = next_cell
        amr.move_elapsed = 0.0
        dx = next_cell[0] - amr.cell[0]
        dy = next_cell[1] - amr.cell[1]
        if max(abs(dx), abs(dy)) > 1:
            print(f"MOVE REJECTED | {amr.name} non_adjacent_move from={amr.cell} to={next_cell}")
            amr.move_from = None
            amr.move_to = None
            amr.move_elapsed = 0.0
            amr.wait_steps += 1
            return
        if dx != 0 or dy != 0:
            amr.heading = normalize_move(dx, dy)
            set_amr_yaw_to_movement(amr)

    def update_motion(self, dt: float):
        for amr in self.amrs.values():
            if not amr.is_moving():
                continue
            src_w = grid_to_world(amr.move_from)
            dst_w = grid_to_world(amr.move_to)
            dist = max(distance_xy(src_w, dst_w), 1e-6)
            speed = AMR_CARRY_SPEED_MPS if amr.carrying_rack else AMR_SPEED_MPS
            duration = dist / speed
            amr.move_elapsed += dt
            alpha = min(amr.move_elapsed / duration, 1.0)
            x = src_w[0] * (1.0 - alpha) + dst_w[0] * alpha
            y = src_w[1] * (1.0 - alpha) + dst_w[1] * alpha
            set_object_center_xy(amr.obj, x, y, amr.obj.base_z)
            set_amr_yaw_to_movement(amr)

            if amr.carrying_rack:
                rack = self.racks.get(amr.carrying_rack)
                if rack:
                    # Hard transform lock: rack root follows AMR root every frame.
                    # Re-disable physics defensively because Live/PhysX can recompose APIs from referenced layers.
                    if not rack.physics_locked:
                        hard_disable_physics_subtree(rack.obj.prim, disable_collision=True)
                        rack.physics_locked = True
                    set_object_center_xy(rack.obj, x, y, rack.obj.base_z + LIFT_HEIGHT_M)
                    rack.cell = amr.move_to if alpha >= 1.0 else amr.cell

            if alpha >= 1.0:
                amr.cell = amr.move_to
                amr.move_from = None
                amr.move_to = None
                amr.move_elapsed = 0.0
                amr.wait_steps = 0
                # Keep the discrete planner cell deterministic.
                # QR-camera localization can read a forward/neighbor QR after a move and
                # overwrite amr.cell with a non-adjacent cell, which makes the next
                # scripted move visually jump over two cells. For this scripted demo
                # controller, cell state follows the commanded grid motion.
                amr.current_qr_id = cell_to_floor_qr_id_from_map(amr.cell, self.qr_cell_world_map)
                amr.localization_source = "SCRIPTED_GRID_MOTION"
                if amr.state == "RANDOM" and amr.target_cell == amr.cell and RANDOM_DRIVE_ENABLED and not STANDBY_UNTIL_COMMAND:
                    self.assign_random_goal(amr)
                elif amr.state == "RANDOM" and (not RANDOM_DRIVE_ENABLED or STANDBY_UNTIL_COMMAND) and amr.target_cell == amr.cell:
                    amr.state = "IDLE"
                    amr.target_cell = None
                    amr.target_xy = None

    # --------------------------------------------------------
    # Collision check and logging
    # --------------------------------------------------------
    def detect_collisions(self):
        # Current-cell collision.
        occupied: Dict[GridCell, str] = {}
        for amr in self.amrs.values():
            if amr.cell in occupied:
                self.log_collision("CELL", f"{occupied[amr.cell]} and {amr.name} at {amr.cell}")
            else:
                occupied[amr.cell] = amr.name

        # Approximate world footprint collision.
        names = list(self.amrs.keys())
        for i in range(len(names)):
            a = self.amrs[names[i]]
            aw = get_object_center_xy(a.obj)
            ar = self.footprint_radius(a)
            for j in range(i + 1, len(names)):
                b = self.amrs[names[j]]
                bw = get_object_center_xy(b.obj)
                br = self.footprint_radius(b)
                if distance_xy(aw, bw) < ar + br:
                    self.log_collision("FOOTPRINT", f"{a.name} and {b.name}")

    def log_collision(self, typ: str, msg: str):
        self.collision_counts[typ] = self.collision_counts.get(typ, 0) + 1
        total = sum(self.collision_counts.values())
        print(f"COLLISION DETECTED | type={typ} total={total} | {msg}")

    def print_summary(self):
        active_tasks = len(self.tasks)
        moving = sum(1 for a in self.amrs.values() if a.is_moving())
        carrying = sum(1 for a in self.amrs.values() if a.carrying_rack)
        print(
            f"LIVE_TRUE8 | tick={self.tick} moving={moving} active_tasks={active_tasks} "
            f"carrying={carrying} collisions={self.collision_counts} "
            f"qr={[a.current_qr_id or a.localization_source for a in self.amrs.values()]}"
        )


# ============================================================
# Geometry helper for swept footprint
# ============================================================
def segment_distance(a0, a1, b0, b1) -> float:
    # 2D line segment minimum distance.
    if segments_intersect(a0, a1, b0, b1):
        return 0.0
    return min(
        point_segment_distance(a0, b0, b1),
        point_segment_distance(a1, b0, b1),
        point_segment_distance(b0, a0, a1),
        point_segment_distance(b1, a0, a1),
    )


def point_segment_distance(p, a, b) -> float:
    px, py = p
    ax, ay = a
    bx, by = b
    vx = bx - ax
    vy = by - ay
    wx = px - ax
    wy = py - ay
    denom = vx * vx + vy * vy
    if denom <= 1e-9:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, (wx * vx + wy * vy) / denom))
    qx = ax + t * vx
    qy = ay + t * vy
    return math.hypot(px - qx, py - qy)


def segments_intersect(a, b, c, d) -> bool:
    def ccw(p1, p2, p3):
        return (p3[1] - p1[1]) * (p2[0] - p1[0]) > (p2[1] - p1[1]) * (p3[0] - p1[0])
    return ccw(a, c, d) != ccw(b, c, d) and ccw(a, b, c) != ccw(a, b, d)


# ============================================================
# Start / replace old controller
# ============================================================
def start_controller():
    global _LIVE_TRUE8_CONTROLLER
    try:
        old = globals().get("_LIVE_TRUE8_CONTROLLER")
        if old is not None and getattr(old, "_subscription", None) is not None:
            old._subscription = None
            print("Previous controller subscription released")
    except Exception as e:
        print("Previous controller cleanup warning:", e)
    _LIVE_TRUE8_CONTROLLER = ExistingStageTrue8Controller()
    return _LIVE_TRUE8_CONTROLLER


start_controller()
