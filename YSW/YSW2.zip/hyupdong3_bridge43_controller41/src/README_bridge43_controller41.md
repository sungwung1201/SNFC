# 협동3 최종 사용 조합

## 포함 파일

이 압축 파일은 사용자가 실제로 쓰려는 조합 기준이다.

```text
Bridge: v43 guarded actions
Controller: v41 true spots / dynamic rack / fourway zone
```

## 원본 버전 파일

```text
src/fleet_manager_bridge_node_gpu_v43_guarded_actions.py
src/amr_live_existing_stage_true8_qr_camera_controller_gpu_wayC_qr_safegate_tailrelease_v41_true_spots_dynamic_rack_fourway_zone.py
```

## 바로 실행용 파일명

Controller는 IsaacSim에서 기존 실행명으로 바로 쓸 수 있게 아래 이름으로도 복사해두었다.

```text
src/amr_live_existing_stage_true8_qr_camera_controller_gpu.py
```

Bridge는 run_bridge_gpu.sh가 v43 파일명을 실행하도록 맞춘 경우 아래 파일을 사용한다.

```text
src/fleet_manager_bridge_node_gpu_v43_guarded_actions.py
```

## 프로젝트 폴더에 적용

```bash
cd ~/isaaclab_ws/isaac_aruco/amr

cp ~/Downloads/hyupdong3_bridge43_controller41/src/amr_live_existing_stage_true8_qr_camera_controller_gpu.py    ./amr_live_existing_stage_true8_qr_camera_controller_gpu.py

cp ~/Downloads/hyupdong3_bridge43_controller41/src/fleet_manager_bridge_node_gpu_v43_guarded_actions.py    ./fleet_manager_bridge_node_gpu_v43_guarded_actions.py

python3 -m py_compile fleet_manager_bridge_node_gpu_v43_guarded_actions.py && echo "BRIDGE OK"
python3 -m py_compile amr_live_existing_stage_true8_qr_camera_controller_gpu.py && echo "CONTROLLER OK"
```

## IsaacSim 실행

```python
exec(open('/home/rokey/isaaclab_ws/isaac_aruco/amr/amr_live_existing_stage_true8_qr_camera_controller_gpu.py', encoding='utf-8').read())
```

## Bridge 실행

```bash
cd ~/isaaclab_ws/isaac_aruco/amr
./run_bridge_gpu.sh
```
